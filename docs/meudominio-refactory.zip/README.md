# Meu Dominio - Backend

## Executar a aplicação

```bash
# development mode
$ npm run dev

# production mode
$ npm run start
```

## Executar testes

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Criar um novo migration

```bash
./node_modules/.bin/typeorm migration:create -d src/migrations -n {nome}
```
