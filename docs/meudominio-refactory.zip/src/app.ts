import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from './common/CommonModule';
import { AlocacaoModule } from './modules/alocacao/AlocacaoModule';
import { DominioModule } from './modules/dominio/DominioModule';
import { EmpregadoModule } from './modules/empregado/EmpregadoModule';
import { GrupoGoviModule } from './modules/grupogovi/GrupoGoviModule';
import { LoginModule } from './modules/login/LoginModule';
import { ServicoModule } from './modules/servico/ServicoModule';
import { SistemaModule } from './modules/sistema/SistemaModule';
import { SubDominioModule } from './modules/subdominio/SubDominioModule';
import { UsuarioModule } from './modules/usuario/UsuarioModule';
import config from './config';

@Module({
  imports: [
    // Módulo do Banco de Dados
    TypeOrmModule.forRoot({
      database: config.database.name,
      entities: [__dirname + '/**/*Entity{.ts,.js}'],
      host: config.database.host,
      logging: config.ambiente === 'LOCAL',
      migrations: [__dirname + '/**/migrations/*{.js,.ts}'],
      migrationsRun: true,
      migrationsTableName: 'migrations',
      password: config.database.password,
      port: config.database.port,
      synchronize: false,
      type: 'postgres',
      username: config.database.username,
    }),
    // Módulos da Aplicação
    CommonModule,
    LoginModule,
    EmpregadoModule,
    UsuarioModule,
    ServicoModule,
    GrupoGoviModule,
    DominioModule,
    SubDominioModule,
    SistemaModule,
    AlocacaoModule,
  ],
  controllers: [],
  providers: [],
})
export class ApplicationModule {}
