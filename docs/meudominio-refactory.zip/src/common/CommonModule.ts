import { Module } from '@nestjs/common';
import { CacheAdapterFactory } from './cache/CacheAdapterFactory';
import { CacheAdapter } from './cache/CacheAdapterRedis';
import { BooleanPipe } from './pipes/BooleanPipe';
import { FloatPipe } from './pipes/FloatPipe';
import { IntegerPipe } from './pipes/IntegerPipe';
import { SortPipe } from './pipes/SortPipe';
import { SecurityContext } from './security/SecurityContext';

const CacheAdapterProvider = {
  provide: CacheAdapter,
  useFactory: () => {
    new CacheAdapterFactory().getInstance();
  },
};

@Module({
  controllers: [],
  exports: [SecurityContext, IntegerPipe, FloatPipe, SortPipe, BooleanPipe, CacheAdapterProvider],
  imports: [],
  providers: [SecurityContext, IntegerPipe, FloatPipe, SortPipe, BooleanPipe, CacheAdapterProvider],
})
export class CommonModule {}
