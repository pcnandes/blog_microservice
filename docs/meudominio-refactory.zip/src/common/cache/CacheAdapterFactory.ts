import { CacheAdapter } from './CacheAdapterRedis';
import { ClientOpts, createClient } from 'redis';
import config from '../../config';

let singleton = null;

export class CacheAdapterFactory {
  public getInstance(): CacheAdapter {
    if (!singleton) {
      singleton = new CacheAdapter(createClient(config.redis as ClientOpts));
    }
    return singleton;
  }
}
