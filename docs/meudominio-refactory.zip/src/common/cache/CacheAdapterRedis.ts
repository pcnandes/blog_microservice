import { RedisClient } from 'redis';

function deserialize<T>(plain: any, type?: new (...args) => T): any {
  if (!plain) {
    return plain;
  }
  if (!type) {
    return plain;
  }
  if (Array.isArray(plain)) {
    return plain.map(item => new type(plain));
  }
  return new type(plain);
}

export class CacheAdapter {
  constructor(protected readonly client: RedisClient) {}

  public async put(key: string, value: any, timeout?: number): Promise<any> {
    return new Promise((resolve, reject) => {
      this.client.set(key, JSON.stringify(value), 'EX', timeout || 0, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });
    });
  }

  public async get<T>(key: string, type?: new (...args) => T): Promise<T> {
    return new Promise((resolve, reject) => {
      this.client.get(key, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(deserialize(JSON.parse(reply), type));
        }
      });
    });
  }

  public async del(...keys: string[]): Promise<number> {
    return new Promise((resolve, reject) => {
      this.client.del(keys, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });
    });
  }

  public async hput(group: string, key: string, value: any, timeout?: number): Promise<number> {
    return new Promise((resolve, reject) => {
      this.client.hset(group, key, JSON.stringify(value), (err, reply) => {
        if (err) {
          reject(err);
        } else {
          if (timeout) {
            this.client.expire(group, timeout);
          }
          resolve(reply);
        }
      });
    });
  }

  public async hget<T>(group: string, key: string, type?: new (...args) => T): Promise<T> {
    return new Promise((resolve, reject) => {
      this.client.hget(group, key, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(deserialize(JSON.parse(reply), type));
        }
      });
    });
  }

  public async hdel(group: string, ...keys: string[]): Promise<number> {
    return new Promise((resolve, reject) => {
      this.client.hdel(group, keys, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });
    });
  }

  public async hkeys(group: string): Promise<string[]> {
    return new Promise((resolve, reject) => {
      this.client.hkeys(group, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });
    });
  }

  public async keys(pattern: string = '*'): Promise<string[]> {
    return new Promise((resolve, reject) => {
      this.client.keys(pattern, (err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve(reply);
        }
      });
    });
  }

  public async clear(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.client.flushall((err, reply) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }
}
