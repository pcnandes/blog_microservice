import { Logger } from '@nestjs/common';
import { CacheAdapterFactory } from './CacheAdapterFactory';

type CacheArgKeyFunc = (...args: any[]) => string;
type CacheArgSubFunc = (...args: any[]) => string | string[];

export function CacheRemove(key?: string | CacheArgKeyFunc, sub?: string | string[] | CacheArgSubFunc): any {
  return (target: any, propertyKey: string, descriptor: any) => {
    const method = descriptor.value;
    descriptor.value = async function(...args: any[]) {
      const adapter = new CacheAdapterFactory().getInstance();
      const result = await method.apply(this, args);
      const cacheKey = typeof key === 'function' ? key(...args) : key;
      let cacheSub = typeof sub === 'function' ? sub(...args) : sub;
      if (cacheSub) {
        cacheSub = Array.isArray(cacheSub) ? cacheSub : [cacheSub];
        adapter.hdel(cacheKey, ...cacheSub);
      } else {
        adapter.del(...cacheKey);
      }
      Logger.debug(`REMOVE CACHE ${cacheKey}/${cacheSub || '*'}`);
      return result;
    };
    return descriptor;
  };
}
