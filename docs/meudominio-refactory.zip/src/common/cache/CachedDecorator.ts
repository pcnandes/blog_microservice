import { CacheAdapterFactory } from './CacheAdapterFactory';
import { Logger } from '@nestjs/common';
import { ClassType } from 'class-transformer/ClassTransformer';

type CacheArgStringFunc = (...args: any[]) => string;

export function CacheTimeout(maximo: number = 0, now: Date = new Date()): number {
  const secondsPerDay = 60 * 60 * 24;
  const timeOfRefresh = 60 * 60 * 5;
  const time = Math.floor((now.getTime() - now.setHours(0, 0, 0, 0)) / 1000);
  const diff = timeOfRefresh - time;
  return Math.min(diff <= 0 ? secondsPerDay + diff : diff, maximo || secondsPerDay);
}

export function Cached<T>(key: string | CacheArgStringFunc, sub?: string | CacheArgStringFunc, type?: ClassType<T>, exp?: number): any {
  return (target: any, propertyKey: string, descriptor: any) => {
    const method = descriptor.value;
    descriptor.value = async function(...args: any[]) {
      const adapter = new CacheAdapterFactory().getInstance();
      const cacheKey = typeof key === 'function' ? key(...args) : key;
      const cacheSub = typeof sub === 'function' ? sub(...args) : sub;
      const cached = cacheSub ? await adapter.hget(cacheKey, cacheSub, type) : await adapter.get(cacheKey, type);
      if (cached) {
        return cached;
      }
      const cacheExp = CacheTimeout(exp);
      const result = await method.apply(this, args);
      Logger.debug(`CACHING ${cacheKey}/${cacheSub || ''}`);
      if (cacheSub) {
        adapter.hput(cacheKey, cacheSub, result, cacheExp);
      } else {
        adapter.put(cacheKey, result, cacheExp);
      }
      return result;
    };
    return descriptor;
  };
}
