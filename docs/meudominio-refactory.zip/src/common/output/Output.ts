import { Response } from 'express';
import { Page } from '../repository/Page';

export interface Output {
  ofPage(response: Response, data: Page<any>, args?: any);
  ofList(response: Response, data: any[], args?: any);
}
