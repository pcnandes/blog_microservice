import { Output } from './Output';
import { Response } from 'express';
import { Page } from '../repository/Page';
import { Parser } from 'json2csv';
import moment from 'moment';

export class OutputCSV implements Output {
  ofPage(response: Response, data: Page<any>, unwind?: any) {
    const datahora = moment().format('YYYYMMDDTHHmmss');
    response.set({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment;filename=meudominio_${datahora}.csv`,
      'Page-ItemsPerPage': data.pageSize,
      'Page-TotalPages': data.totalPages,
      'Page-TotalElements': data.totalElements,
      'Page-Number': data.pageNumber,
    });
    response.send(this.parse(data.content, unwind));
    response.end();
  }

  ofList(response: Response, data: any[], unwind?: any) {
    const datahora = moment().format('YYYYMMDDTHHmmss');
    response.set({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment;filename=meudominio_${datahora}.csv`,
    });
    response.send(this.parse(data, unwind));
    response.end();
  }

  protected parse(data: any[], unwind?: any) {
    const parser = new Parser({ flatten: true, unwind, eol: '\n' });
    return parser.parse(data);
  }
}
