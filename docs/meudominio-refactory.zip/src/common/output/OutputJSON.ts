import { Output } from './Output';
import { Response } from 'express';
import { Page } from '../repository/Page';

export class OutputJSON implements Output {
  ofPage(response: Response, data: Page<any>) {
    response.json(data);
    response.end();
  }

  ofList(response: Response, data: any[]) {
    response.json(data);
    response.end();
  }
}
