import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';

@Injectable()
export class BooleanPipe implements PipeTransform<string, boolean> {
  transform(value: any, metadata?: ArgumentMetadata): boolean {
    return BooleanPipe.parse(value);
  }

  public static parse(value: any): boolean {
    if (typeof value === 'boolean') {
      return value;
    }
    if (typeof value === 'string') {
      return value === '' || JSON.parse(String(value).toLowerCase());
    }
    return undefined;
  }
}
