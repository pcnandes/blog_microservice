import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';

@Injectable()
export class FloatPipe implements PipeTransform<string, number> {
  transform(value: any, metadata?: ArgumentMetadata): number {
    return FloatPipe.parse(value);
  }

  public static parse(value: any): number {
    if (typeof value === 'number') {
      return value;
    }
    if (typeof value === 'string' && value.match(/^[-+]{0,1}[0-9]+(\.[0-9]+){0,1}$/)) {
      return parseFloat(value);
    }
    return undefined;
  }
}
