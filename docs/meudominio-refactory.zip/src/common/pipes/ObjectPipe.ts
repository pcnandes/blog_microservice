import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { validate } from 'class-validator';

@Injectable()
export class ObjectPipe<T> implements PipeTransform<any, Promise<T>> {
  async transform(value: any, metadata?: ArgumentMetadata): Promise<T> {
    if (!value) {
      return null;
    }
    const obj = new metadata.metatype(value);
    const errors = await validate(obj);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
    return obj;
  }
}
