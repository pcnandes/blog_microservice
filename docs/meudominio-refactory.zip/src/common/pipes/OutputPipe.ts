import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { Output } from '../output/Output';
import { OutputCSV } from '../output/OutputCSV';
import { OutputJSON } from '../output/OutputJSON';

@Injectable()
export class OutputPipe implements PipeTransform<string, Output> {
  transform(value: any, metadata?: ArgumentMetadata): Output {
    if (!value) {
      return new OutputJSON();
    }
    if (typeof value === 'string') {
      switch (value.toUpperCase()) {
        case 'CSV':
          return new OutputCSV();
        case 'JSON':
          return new OutputJSON();
      }
    }
    throw new Error(`Formato inválido: ${value}`);
  }
}
