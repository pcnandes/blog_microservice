import { IntegerPipe } from './IntegerPipe';
import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { validate } from 'class-validator';
import { Pageable } from '../repository/Pageable';
import { SortPipe } from './SortPipe';

@Injectable()
export class PageablePipe<T> implements PipeTransform<any, Promise<Pageable>> {
  async transform(value: any, metadata?: ArgumentMetadata): Promise<Pageable> {
    if (!value) {
      return null;
    }
    const obj = new Pageable({
      pageNumber: IntegerPipe.parse(value.page),
      pageSize: IntegerPipe.parse(value.size),
      sort: value.sort ? SortPipe.parse(value.sort) : undefined,
    });
    const errors = await validate(obj);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
    return obj;
  }
}
