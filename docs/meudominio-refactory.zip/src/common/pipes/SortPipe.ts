import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { Order } from '../query/Order';
import { Sort } from '../query/Sort';

@Injectable()
export class SortPipe implements PipeTransform<any, Sort> {
  transform(value: any, metadata?: ArgumentMetadata): Sort {
    return SortPipe.parse(value);
  }

  public static parse(value: any): Sort {
    if (!value || typeof value !== 'string') {
      return undefined;
    }
    const order = value.split(/[-,]/).map(prop => {
      const attr = prop.replace(/[<>]/, '');
      return prop.endsWith('<') ? Order.desc(attr) : Order.asc(attr);
    });
    return Sort.by(...order);
  }
}
