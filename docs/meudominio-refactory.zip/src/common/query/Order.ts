import { Example } from '../utils/Types';

export class Order {
  public readonly property: string;
  public readonly descending: boolean;

  constructor(example?: Example<Order>) {
    this.property = example?.property;
    this.descending = typeof example?.descending === 'boolean' ? example?.descending : false;
  }

  public static by(property: string | Order): Order {
    return new Order(typeof property === 'string' ? { property } : property);
  }

  public static asc(property: string): Order {
    return new Order({ property });
  }

  public static desc(property: string): Order {
    return new Order({ property, descending: true });
  }
}
