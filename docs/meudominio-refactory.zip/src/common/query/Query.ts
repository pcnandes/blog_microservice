import { Logger } from '@nestjs/common';
import { difference } from 'lodash';
import { EntityMetadata, ObjectLiteral, SelectQueryBuilder } from 'typeorm';
import { ObjectUtils } from '../utils/ObjectUtils';
import { SelectParser } from './SelectParser';
import { Sort } from './Sort';
import { Where, WhereGroup } from './Where';

export class Query<T> {
  private readonly hiddenProps: Set<string> = new Set();
  private readonly selectProps: Set<string> = new Set();
  private readonly relationNames: Set<string> = new Set();
  private readonly where: Where = new Where();
  private readonly sort?: Sort = new Sort();
  private limit?: number;
  private offset?: number;

  constructor(private readonly builder: SelectQueryBuilder<T>, private readonly metadata: EntityMetadata) {}

  public addSelect(select: string): Query<T> {
    this.selectRecursive(select, this.builder.alias, this.metadata);
    return this;
  }

  public addJoin(path: string): Query<T> {
    const parts = path.split('.');
    let meta = this.metadata;
    let alias = this.builder.alias;
    let idx = 0;
    while (idx < parts.length) {
      const relations = this.extractRelations(meta);
      const prop = parts[idx];
      if (relations[prop]) {
        meta = relations[prop];
        const pk = this.extractPrimaryKey(meta);
        this.putSelect(`${this.builder.alias}.${parts.slice(0, idx + 1).join('.')}.${pk}`, true);
        if (!this.relationNames.has(`${alias}.${prop}`)) {
          this.builder.leftJoin(`${alias}.${prop}`, `${alias}_${prop}`);
          this.relationNames.add(`${alias}.${prop}`);
        }
        alias = `${alias}_${prop}`;
      } else {
        Logger.warn(`Join não encontrado: ${parts.slice(0, idx + 1).join('.')}`);
        return;
      }
      idx++;
    }
    return this;
  }

  public andWhereInIds(ids: (string | number)[]): Query<T> {
    this.where.andWhereInIds(ids);
    return this;
  }

  public orWhereInIds(ids: (string | number)[]): Query<T> {
    this.where.orWhereInIds(ids);
    return this;
  }

  public andWhere(clause: string | WhereGroup | Where, params?: ObjectLiteral): Query<T> {
    this.where.andWhere(clause, params);
    return this;
  }

  public orWhere(clause: string | WhereGroup | Where, params?: ObjectLiteral): Query<T> {
    this.where.orWhere(clause, params);
    return this;
  }

  public addOrderBy(sort: Sort): Query<T> {
    if (!sort) {
      return this;
    }
    sort.by.forEach(by => {
      this.sort.and(by);
      this.putSelect(`${this.builder.alias}.${by.property}`, true);
    });
    return this;
  }

  public take(amount: number): Query<T> {
    this.limit = amount;
    return this;
  }

  public skip(amount: number): Query<T> {
    this.offset = amount;
    return this;
  }

  public getSql(): string {
    this.prepare();
    return this.builder.getSql();
  }

  public toJSON(): any {
    return {
      sql: this.getSql(),
      arg: this.where.getParameters(),
    };
  }

  public async getManyAndCount(): Promise<[T[], number]> {
    this.prepare();
    const [items, count] = await this.builder.getManyAndCount();
    const props = this.requiredProps;
    return [items.map(item => this.removeHiddenProps(item, props)), count];
  }

  public async getMany(): Promise<T[]> {
    this.prepare();
    const items = await this.builder.getMany();
    const props = this.requiredProps;
    return items.map(item => this.removeHiddenProps(item, props));
  }

  public async getOne(): Promise<T> {
    this.prepare();
    return this.removeHiddenProps(await this.builder.getOne(), this.requiredProps);
  }

  private removeHiddenProps(entity: T, keep: string[]): any {
    ObjectUtils.removeProperties(entity, keep);
    return entity;
  }

  private get requiredProps(): string[] {
    return difference([...this.selectProps], [...this.hiddenProps]).map(prop =>
      prop
        .split('.')
        .slice(1)
        .join('.'),
    );
  }

  private prepare() {
    this.prepareSort();
    this.prepareJoin();
    this.prepareSelect();
    this.prepareWhere();
    this.prepareLimit();
    this.prepareOffset();
  }

  private prepareSelect() {
    this.builder.select(
      [...this.selectProps].map(item => {
        const parts = item.split('.');
        const path = parts.slice(0, -1);
        const attr = parts.pop();
        return path.join('_') + '.' + attr;
      }),
    );
  }

  private prepareWhere() {
    if (!this.where.isEmpty) {
      this.builder.where(this.where.getBrackets());
    }
  }

  private prepareJoin() {
    this.where.getJoins().forEach(join => {
      this.addJoin(join);
    });
  }

  private prepareLimit() {
    if (typeof this.limit === 'number') {
      this.builder.take(this.limit);
    }
  }

  private prepareOffset() {
    if (typeof this.offset === 'number') {
      this.builder.skip(this.offset);
    }
  }

  private prepareSort() {
    this.builder.orderBy();
    this.sort.by.forEach(by => {
      const parts = [this.builder.alias, ...by.property.split('.')];
      const path = parts.slice(0, -1);
      const attr = parts.pop();
      this.builder.addOrderBy(path.join('_') + '.' + attr, by.descending ? 'DESC' : 'ASC', 'NULLS LAST');
    });
  }

  private putSelect(column: string, hidden: boolean = false) {
    if (!this.selectProps.has(column)) {
      this.selectProps.add(column);
      if (hidden) {
        this.hiddenProps.add(column);
      }
    } else if (!hidden && this.hiddenProps.has(column)) {
      this.hiddenProps.delete(column);
    }
  }

  private selectRecursive(select: string, path: string, meta: EntityMetadata) {
    const availableProps = this.extractProperties(meta);
    const availableJoins = this.extractRelations(meta);
    const join = path.includes('.')
      ? path
          .split('.')
          .slice(1)
          .join('.') + '.'
      : '';
    const splitted = SelectParser.parse(select);
    splitted.forEach(prop => {
      const [, key, sub] = prop.match(/^([a-z0-9_]+)\.(.+)$/i) || [null, prop];
      if (key === '*') {
        this.selectRecursive(availableProps.join('-'), path, meta);
      } else if (sub && availableJoins[key]) {
        this.selectRecursive(sub[0] === '(' ? sub.slice(1, -1) : sub, `${path}.${key}`, availableJoins[key]);
        this.addJoin(`${join}${key}`);
      } else if (availableProps.includes(key)) {
        this.putSelect(`${path}.${key}`, false);
      } else {
        Logger.warn(`Propriedade não encontrada: ${meta.name}.${key}`);
      }
    });
    const pk = this.extractPrimaryKey(meta);
    if (pk) {
      this.putSelect(`${path}.${pk}`, true);
    }
  }

  private extractPrimaryKey(meta: EntityMetadata): string {
    return meta.primaryColumns[0]?.propertyName;
  }

  private extractProperties(meta: EntityMetadata): string[] {
    return meta.columns.filter(col => col.target === meta.target).map(col => col.propertyName);
  }

  private extractRelations(meta: EntityMetadata): any {
    return meta.relations.reduce((obj, rel) => {
      obj[rel.propertyName] = rel.entityMetadata.name === meta.name ? rel.inverseEntityMetadata : rel.entityMetadata;
      return obj;
    }, {});
  }
}
