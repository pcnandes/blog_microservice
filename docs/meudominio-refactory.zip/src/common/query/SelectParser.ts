export class SelectParser {
  public static parse(select: string): string[] {
    if (!select) {
      return [];
    }
    const resultado = [];
    let inicio = 0;
    while (inicio < select.length) {
      let termino = SelectParser.obterPosicaoTerminoAtributo(select, inicio);
      if (select[termino] === '.') {
        termino = SelectParser.obterPosicaoTerminoSubItems(select, termino + 1);
      }
      resultado.push(select.substring(inicio, termino));
      if (termino < select.length && select[termino] !== '-') {
        throw new Error();
      }
      inicio = termino + 1;
    }
    return resultado;
  }

  private static obterPosicaoTerminoAtributo(texto: string, posicao: number): number {
    if (!texto[posicao].match(/[a-z*]/i)) {
      throw new Error(`Erro ao interpretar atributos: ${texto.slice(0, posicao)}[${texto[posicao]}]${texto.slice(posicao + 1)}`);
    }
    if (texto[posicao] === '*') {
      return posicao + 1;
    }
    while (posicao < texto.length && texto[posicao].match(/[a-z0-9_]/i)) {
      posicao++;
    }
    return posicao;
  }

  private static obterPosicaoTerminoSubItems(texto: string, posicao: number): number {
    if (texto[posicao] !== '(') {
      return SelectParser.obterPosicaoTerminoAtributo(texto, posicao);
    }
    let parenteses = 1;
    posicao++;
    while (posicao < texto.length && parenteses > 0) {
      if (texto[posicao] === '(') {
        parenteses++;
      } else if (texto[posicao] === ')') {
        parenteses--;
      }
      posicao++;
    }
    if (parenteses > 0) {
      throw new Error(`Erro ao interpretar atributos: ${texto.slice(0, posicao)}[${texto[posicao]}]${texto.slice(posicao + 1)}`);
    }
    return posicao;
  }
}
