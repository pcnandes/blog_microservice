import { Allow } from 'class-validator';
import { Order } from './Order';

export class Sort {
  @Allow()
  public readonly by: Order[];

  constructor(example: Partial<Sort> = {}) {
    this.by = example.by ? [...example.by] : [];
  }

  public and(by: string | Order | Sort): Sort {
    if (typeof by === 'string') {
      this.by.push(Order.by(by));
    } else if (by instanceof Sort) {
      this.by.push(...by.by);
    } else if (by instanceof Order) {
      this.by.push(by);
    }
    return this;
  }

  public get empty(): boolean {
    return this.by.length === 0;
  }

  public get sql(): string {
    if (this.empty) {
      throw new Error('Ordenação vazia');
    }
    return this.by.map(by => `"${by.property}" ${by.descending ? 'DESC' : 'ASC'} NULLS LAST`).join(', ');
  }

  public static by(...by: string[] | Order[]): Sort {
    const order = [];
    by.forEach(prop => {
      order.push(Order.by(prop));
    });
    return new Sort({ by: order });
  }
}
