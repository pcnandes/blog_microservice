import { Brackets, ObjectLiteral } from 'typeorm';

export type WhereGroup = (where: Where) => void;

export enum WhereOperator {
  AND = 'and',
  OR = 'or',
}

export class Where {
  private readonly operator: WhereOperator;
  private readonly ids?: (string | number)[];
  private readonly clause?: string;
  private readonly params?: ObjectLiteral;
  private readonly children: Where[] = [];
  private readonly joins: string[] = [];

  constructor(operator: WhereOperator = WhereOperator.AND, clause?: string | (string | number)[], params?: ObjectLiteral) {
    this.operator = operator || WhereOperator.AND;
    this.clause = typeof clause === 'string' ? clause : undefined;
    this.ids = Array.isArray(clause) ? clause : undefined;
    this.params = params;
  }

  public get isEmpty(): boolean {
    return !this.clause && !this.ids?.length && !this.children.some(child => !child.isEmpty);
  }

  public get isFinal(): boolean {
    return !!this.clause || this.ids?.length > 0;
  }

  public get hasChildren(): boolean {
    return this.children.length > 0;
  }

  public addJoin(path: string): Where {
    this.joins.push(path);
    return this;
  }

  public andWhereInIds(ids: (string | number)[]): Where {
    this.children.push(new Where(WhereOperator.AND, ids));
    return this;
  }

  public orWhereInIds(ids: (string | number)[]): Where {
    this.children.push(new Where(WhereOperator.OR, ids));
    return this;
  }

  public andWhere(clause: string | WhereGroup | Where, params?: ObjectLiteral): Where {
    return this.addWhere(WhereOperator.AND, clause, params);
  }

  public orWhere(clause: string | WhereGroup | Where, params?: ObjectLiteral): Where {
    return this.addWhere(WhereOperator.OR, clause, params);
  }

  private addWhere(operator: WhereOperator, clause: string | WhereGroup | Where, params?: ObjectLiteral): Where {
    if (typeof clause === 'string') {
      this.children.push(new Where(operator, clause, params));
    } else if (clause instanceof Where) {
      this.children.push(clause);
    } else {
      const child = new Where(operator);
      this.children.push(child);
      clause(child);
    }
    return this;
  }

  public toString(): string {
    return this.toStringRecursive().replace(/^(AND|OR)\s/g, '');
  }

  public toStringRecursive(): string {
    if (this.isEmpty) {
      return '';
    }
    const op = this.operator.toUpperCase();
    if (this.children.length > 0) {
      return (
        op +
        ' (' +
        this.children
          .map(child => `${child.toStringRecursive()}`)
          .join(' ')
          .replace(/^(AND|OR)\s/g, '') +
        ')'
      );
    }
    if (this.ids?.length > 0) {
      return `${op} [PK] IN (${this.ids.join(',')})`;
    }
    return `${op} ${this.clause}`;
  }

  public getParameters(): any {
    const obj = this.children.reduce((acc, child) => Object.assign(acc, child.getParameters()), {});
    if (this.params) {
      Object.assign(obj, this.params);
    }
    return obj;
  }

  public getBrackets(): Brackets {
    if (this.isEmpty) {
      return null;
    }
    if (this.children.length > 0) {
      this.getBracketsGroups();
    }
    if (this.ids) {
      return this.getBracketsID();
    }
    return this.getBracketsClause();
  }

  private getBracketsID(): Brackets {
    return new Brackets(where => {
      where[`${this.operator}WhereInIds`](this.ids);
    });
  }

  private getBracketsClause(): Brackets {
    return new Brackets(where => {
      where[`${this.operator}Where`](this.clause as string, this.params);
    });
  }

  private getBracketsGroups(): Brackets {
    return new Brackets(where => {
      this.children.forEach(child => {
        where[`${this.operator}Where`](child.getBrackets(), this.params);
      });
    });
  }

  public getJoins(): string[] {
    const all = this.children.reduce((acc, sub) => acc.concat(sub.getJoins()), this.joins);
    return [...new Set(all)];
  }
}
