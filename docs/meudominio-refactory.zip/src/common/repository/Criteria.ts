import { Where } from '../query/Where';

export interface Criteria {
  toWhere(): Where;
}
