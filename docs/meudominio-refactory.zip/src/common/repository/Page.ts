import { ApiProperty } from '@nestjs/swagger';

export class Page<T> {
  @ApiProperty()
  public readonly pageNumber: number;
  @ApiProperty()
  public readonly pageSize: number;
  @ApiProperty()
  public readonly totalElements: number;
  @ApiProperty()
  public readonly content: T[];

  constructor(example?: Partial<Page<T>>) {
    this.pageNumber = example?.pageNumber;
    this.pageSize = example?.pageSize || example?.totalElements;
    this.totalElements = example?.totalElements;
    this.content = example?.content;
  }

  @ApiProperty()
  public get totalPages(): number {
    return this.pageSize ? Math.ceil((this.totalElements * 1.0) / this.pageSize) : 1;
  }

  public toJSON() {
    return {
      ...this,
      totalPages: this.totalPages,
    };
  }

  public static of<T>(content: T[], totalElements: number, pageNumber: number, pageSize: number): Page<T> {
    return new Page({ content, pageNumber, pageSize, totalElements });
  }
}
