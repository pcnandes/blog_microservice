import { IsNumber, Min } from 'class-validator';
import { Sort } from '../query/Sort';
import { Example } from '../utils/Types';
export class Pageable {
  @IsNumber()
  @Min(1)
  public readonly pageNumber: number;
  @IsNumber()
  @Min(0)
  public readonly pageSize: number;
  public readonly sort: Sort;

  constructor(example?: Example<Pageable>) {
    this.pageNumber = typeof example?.pageNumber === 'number' ? example.pageNumber : 1;
    this.pageSize = typeof example?.pageSize === 'number' ? example.pageSize : 10;
    this.sort = example?.sort;
  }

  public get pageOffset() {
    return (this.pageNumber - 1) * this.pageSize;
  }
}
