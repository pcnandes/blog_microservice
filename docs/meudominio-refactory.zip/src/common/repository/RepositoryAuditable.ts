import { BadRequestException, NotFoundException } from '@nestjs/common';
import { get } from 'lodash';
import { In, IsNull, Repository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';
import { SecurityContext } from '../security/SecurityContext';
import { Historico } from '../../modules/historico/HistoricoEntity';
import { RepositoryCRUD } from './RepositoryCRUD';

const VERSAO = 'versao';

export class RepositoryAuditable<T> extends RepositoryCRUD<T> {
  protected repositoryHistorico: Repository<Historico>;

  constructor(repository: BaseRepository<T>, protected readonly security: SecurityContext) {
    super(repository);
    if (!this.persistentProperties.includes(VERSAO)) {
      throw new Error(`Entidade auditável ${repository.metadata.name} não possui atributo versao`);
    }
    this.repositoryHistorico = this.repository.manager.getRepository(Historico);
  }

  public async insert(entity: QueryDeepPartialEntity<T>): Promise<string> {
    return (await this.insertAll(entity))[0] as string;
  }

  public async insertAll(...entity: QueryDeepPartialEntity<T>[]): Promise<string[]> {
    if (entity.length === 0) {
      return [];
    }
    entity = entity.map(item => this.extractPersistentProperties(item));
    entity.forEach(item => (item[VERSAO] = 1));
    const ids = (await super.insertAll(...entity)) as string[];
    await this.registrarHistoricos(
      ids,
      ids.map(() => null),
      entity,
    );
    return ids;
  }

  public async update(entity: QueryDeepPartialEntity<T>): Promise<void> {
    return this.updateAll(entity);
  }

  public async updateAll(...entity: QueryDeepPartialEntity<T>[]): Promise<void> {
    if (entity.length === 0) {
      return;
    }
    entity = this.sortByPrimary(entity.map(item => this.extractPersistentProperties(item)));
    const ids = entity.map(item => item[this.primaryKeyProperty]);
    const before = this.sortByPrimary(await this.findManyById(ids, this.persistentProperties.join('-')));
    entity.forEach((item, idx) => {
      if (get(before[idx], this.primaryKeyProperty) !== item[this.primaryKeyProperty]) {
        throw new NotFoundException();
      }
    });
    await this.registrarHistoricos(ids, before, entity);
    const changes = entity.filter((item, idx) => item[VERSAO] > before[idx][VERSAO]);
    return super.updateAll(...changes);
  }

  public async delete(id: string): Promise<void> {
    return this.deleteAll(id);
  }

  public async deleteAll(...ids: string[]): Promise<void> {
    if (ids.length === 0) {
      return;
    }
    ids = ids.sort();
    const before = this.sortByPrimary(await this.findManyById(ids, this.persistentProperties.join('-')));
    ids.forEach((id, idx) => {
      if (get(before[idx], this.primaryKeyProperty) !== id) {
        throw new NotFoundException();
      }
    });
    await this.registrarHistoricos(
      ids,
      before,
      ids.map(() => null),
    );
    return super.deleteAll(...ids);
  }

  protected async registrarHistoricos(ids: string[], before?: QueryDeepPartialEntity<T>[], after?: QueryDeepPartialEntity<T>[]) {
    const historicos = [];
    ids.forEach((id, pos) => {
      const objBefore = before[pos];
      const objAfter = after[pos];
      const historico = this.construirHistorico(id, objBefore, objAfter);
      if (historico) {
        historicos.push(historico);
      }
    });
    if (historicos.length > 0) {
      await this.repositoryHistorico.update(
        { id: In(historicos.map(hist => hist.id)), proximo: IsNull(), entidade: this.repository.metadata.name },
        { proximo: this.security.getRequestTime() },
      );
      await this.repositoryHistorico.insert(historicos);
    }
  }

  protected construirHistorico(id: string, before?: QueryDeepPartialEntity<T>, after?: QueryDeepPartialEntity<T>): Historico {
    const atributos = this.extrairAtributosModificados(before, after);
    if (after && atributos.length === 0) {
      return null;
    }
    this.verificarVersao(before, after);
    const modificados = {};
    if (before) {
      atributos.forEach(prop => {
        modificados[prop] = get(before, prop, null);
      });
    }
    const registro = { ...(after || before) };
    delete registro[this.primaryKeyProperty];
    const historico = new Historico({
      id,
      data: this.security.getRequestTime(),
      autor: this.security.getRequestUser().empregado,
      operacao: !before ? 'I' : !after ? 'D' : 'U',
      atributos,
      modificados,
      entidade: this.repository.metadata.name,
      registro,
    });
    return historico;
  }

  protected extrairAtributosModificados(before?: QueryDeepPartialEntity<T>, after?: QueryDeepPartialEntity<T>): string[] {
    if (!after) {
      return [];
    }
    return this.persistentProperties
      .filter(prop => ![VERSAO, this.primaryKeyProperty].includes(prop) && get(before, prop) !== get(after, prop))
      .map(prop => prop.split('.')[0]);
  }

  protected verificarVersao(before?: QueryDeepPartialEntity<T>, after?: QueryDeepPartialEntity<T>) {
    if (before && after && before[VERSAO] !== after[VERSAO]) {
      throw new BadRequestException('Você não está com a versão mais atual do registro');
    }
    if (after) {
      after[VERSAO] = get(before, VERSAO, 0) + 1;
    }
  }

  protected sortByPrimary(items: QueryDeepPartialEntity<T>[]): QueryDeepPartialEntity<T>[] {
    return items.sort((a, b) => {
      const ka = a[this.primaryKeyProperty];
      const kb = b[this.primaryKeyProperty];
      if (ka < kb) {
        return -1;
      }
      if (ka === kb) {
        return 0;
      }
      return 1;
    });
  }
}
