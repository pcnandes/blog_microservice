import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { ColumnMetadata } from 'typeorm/metadata/ColumnMetadata';
import { Query } from '../query/Query';
import { Sort } from '../query/Sort';
import { WhereGroup } from '../query/Where';
import { Criteria } from './Criteria';
import { Page } from './Page';
import { Pageable } from './Pageable';

export class RepositoryBase<T> {
  protected readonly primaryKeyColumn: ColumnMetadata;

  constructor(protected readonly repository: BaseRepository<T>) {
    this.primaryKeyColumn = this.repository.metadata.primaryColumns[0];
  }

  public async findOne(select: string = '*', criteria?: Criteria | WhereGroup): Promise<T> {
    return this.createQuery(select, criteria).getOne();
  }

  public async findOneById(id: string | number, select: string = '*'): Promise<T> {
    if (id === null || id === undefined) {
      return null;
    }
    return this.createQuery(select)
      .andWhereInIds([id])
      .getOne();
  }

  public async findManyById(ids: string[] | number[], select: string = '*', sort?: Sort): Promise<T[]> {
    if (!ids?.length) {
      return [];
    }
    return this.createQuery(select)
      .andWhereInIds(ids)
      .addOrderBy(sort)
      .getMany();
  }

  public async findPage(pageable: Pageable, select: string = '*', criteria?: Criteria | WhereGroup): Promise<Page<T>> {
    if (!pageable.pageSize) {
      const items = await this.createQuery(select, criteria, pageable.sort).getMany();
      return Page.of(items, items.length, pageable.pageNumber, pageable.pageSize);
    } else {
      const [items, count] = await this.createQueryWithPageable(pageable, select, criteria).getManyAndCount();
      return Page.of(items, count, pageable.pageNumber, pageable.pageSize);
    }
  }

  public async findAll(select: string = '*', criteria?: Criteria | WhereGroup, sort: Sort = null): Promise<T[]> {
    return this.createQuery(select, criteria, sort).getMany();
  }

  protected get primaryKeyProperty(): string {
    return (this.primaryKeyColumn || {}).propertyName;
  }

  protected createQuery(select: string = '*', criteria?: Criteria | WhereGroup, sort?: Sort): Query<T> {
    const alias = this.repository.metadata.name.toLowerCase().replace('_', '');
    const query = new Query<T>(this.repository.createQueryBuilder(alias), this.repository.metadata);
    query.addSelect(select);
    query.addOrderBy(sort);
    if (criteria) {
      if (typeof criteria === 'function') {
        query.andWhere(criteria);
      } else {
        query.andWhere(criteria.toWhere());
      }
    }
    return query;
  }

  protected createQueryWithPageable(pageable: Pageable, select: string = '*', criteria?: Criteria | WhereGroup): Query<T> {
    return this.createQuery(select, criteria, pageable.sort)
      .take(pageable.pageSize)
      .skip(pageable.pageOffset);
  }
}
