import { ObjectUtils } from '../utils/ObjectUtils';
import { cloneDeep, get } from 'lodash';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';
import { RepositoryBase } from './RepositoryBase';

export class RepositoryCRUD<T> extends RepositoryBase<T> {
  protected readonly persistentProperties: string[];

  constructor(repository: BaseRepository<T>) {
    super(repository);

    const meta = this.repository.metadata;
    const columns = meta.columns.filter(col => col.target === meta.target).map(col => col.propertyName);
    const relations = meta.relations
      .filter(
        rel =>
          rel.isOwning &&
          !meta.columns.some(col => col.propertyName !== rel.propertyName && col.databaseName === get(rel.joinColumns[0], 'databaseName')),
      )
      .map(
        rel =>
          rel.propertyName +
          '.' +
          rel.inverseEntityMetadata.columns
            .filter(col => col.isPrimary)
            .map(col => col.propertyName)
            .pop(),
      );
    this.persistentProperties = [...columns, ...relations];
  }

  public async insert(entity: QueryDeepPartialEntity<T>): Promise<string | number> {
    const { identifiers } = await this.repository.insert(this.extractPersistentProperties(entity));
    return identifiers[0][this.primaryKeyProperty];
  }

  public async insertAll(...entity: QueryDeepPartialEntity<T>[]): Promise<string[] | number[]> {
    if (entity.length === 0) {
      return [];
    }
    const { identifiers } = await this.repository.insert(entity.map(item => this.extractPersistentProperties(item)));
    return identifiers.map(item => item[this.primaryKeyProperty]);
  }

  public async update(entity: QueryDeepPartialEntity<T>): Promise<void> {
    await this.repository.update(entity[this.primaryKeyProperty], this.extractPersistentProperties(entity));
  }

  public async updateAll(...entity: QueryDeepPartialEntity<T>[]): Promise<void> {
    if (entity.length === 0) {
      return;
    }
    await entity.forEach(item => {
      this.repository.update(item[this.primaryKeyProperty], this.extractPersistentProperties(item));
    });
  }

  public async delete(id: string | number): Promise<void> {
    await this.repository.delete(id);
  }

  public async deleteAll(...id: string[] | number[]): Promise<void> {
    if (id.length === 0) {
      return;
    }
    await this.repository.delete(id);
  }

  protected extractPersistentProperties(entity: QueryDeepPartialEntity<T>): QueryDeepPartialEntity<T> {
    return ObjectUtils.removeProperties(cloneDeep(entity), this.persistentProperties);
  }
}
