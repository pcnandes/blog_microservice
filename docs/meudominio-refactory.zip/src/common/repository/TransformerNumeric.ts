/**
 * Transformadores de valores para mapear no TypeORM
 *
 * https://github.com/typeorm/typeorm/issues/873
 */

// Transformador para tipos numéricos (decimal, numeric)
export const TransformerNumeric = {
  to: (data: number): number => data,
  from: (data: string): number => parseFloat(data),
};
