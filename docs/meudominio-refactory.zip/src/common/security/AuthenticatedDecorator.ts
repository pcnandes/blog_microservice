import { ForbiddenException } from '@nestjs/common';
import { SecurityContext } from './SecurityContext';

export const Authenticated = () => (target: any, propertyKey: string | symbol, descriptor: PropertyDescriptor): PropertyDescriptor => {
  const method = descriptor.value;
  descriptor.value = async function(...args: any[]) {
    const usuario = SecurityContext.getLoggedUser();
    if (!usuario?.isEmpregado) {
      throw new ForbiddenException('Usuário autenticado não é um empregado');
    }
    return await method.apply(this, args);
  };
  return descriptor;
};
