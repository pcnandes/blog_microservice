import { ForbiddenException } from '@nestjs/common';
import { Operacao } from '../../modules/permissao/Operacao';
import { SecurityContext } from './SecurityContext';

export const HasPermission = (...operacoes: Operacao[]) => (
  target: any,
  propertyKey: string | symbol,
  descriptor: PropertyDescriptor,
): PropertyDescriptor => {
  const method = descriptor.value;
  descriptor.value = async function(...args: any[]) {
    const usuario = SecurityContext.getLoggedUser();
    if (!usuario?.isEmpregado) {
      throw new ForbiddenException('Usuário autenticado não é um empregado');
    }
    if (operacoes && operacoes.length > 0 && !usuario.possuiPermissao(null, ...operacoes)) {
      throw new ForbiddenException('Usuário não está autorizado a realizar esta operação');
    }
    return await method.apply(this, args);
  };
  return descriptor;
};
