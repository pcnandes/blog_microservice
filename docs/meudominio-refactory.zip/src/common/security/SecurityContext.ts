import { getNamespace } from 'node-request-context';
import { Usuario } from './../../modules/usuario/UsuarioEntity';

export class SecurityContext {
  public static readonly NAMESPACE_NAME = 'br.gov.serpro.meudominio.security';
  public static readonly PROP_USER = 'user';
  public static readonly PROP_TIME = 'time';

  public getRequestTime(): Date {
    return getNamespace(SecurityContext.NAMESPACE_NAME).get(SecurityContext.PROP_TIME);
  }

  public getRequestUser(): Usuario {
    return SecurityContext.getLoggedUser();
  }

  public static getLoggedUser(): Usuario {
    return getNamespace(SecurityContext.NAMESPACE_NAME).get(SecurityContext.PROP_USER);
  }
}
