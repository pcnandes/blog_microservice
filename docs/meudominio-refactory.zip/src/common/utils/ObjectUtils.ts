import { set } from 'lodash';

export class ObjectUtils {
  public static removePropertiesUndefined(obj: any) {
    Object.keys(obj).forEach(key => {
      if (obj[key] === undefined) {
        delete obj[key];
      }
    });
  }

  public static removeProperties(obj: any, keep: string[]): any {
    const props = keep.reduce((acc, key) => set(acc, key, true), {});
    ObjectUtils.removePropertiesRecursive(obj, props);
    return obj;
  }

  private static removePropertiesRecursive(obj: any, keep: any) {
    if (!obj) {
      return;
    }
    const keys = Object.keys(obj);
    keys.forEach(key => {
      if (!keep.hasOwnProperty(key)) {
        delete obj[key];
      } else if (typeof keep[key] !== 'boolean') {
        const prop = Array.isArray(obj[key]) ? obj[key] : [obj[key]];
        prop.forEach(item => {
          ObjectUtils.removePropertiesRecursive(item, keep[key]);
        });
      }
    });
  }
}
