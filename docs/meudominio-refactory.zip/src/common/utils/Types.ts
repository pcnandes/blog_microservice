export type Example<T> = {
  [P in keyof T]?: any;
};
