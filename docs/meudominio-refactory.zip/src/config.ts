export default {
  ambiente: process.env.AMBIENTE || 'LOCAL',
  server: {
    port: +(process.env.BACKEND_PORT || 9000),
  },
  alm: process.env.ALM_URL || 'https://desenvalm.serpro',
  ldap: {
    endpoint: process.env.LDAP_API_URL || 'https://api.ldap.serpro',
    username: process.env.LDAP_API_USER || 'apimeudominio',
    password: process.env.LDAP_API_PASS || 'KpBQkux7MZJhiDlX6pg2',
  },
  storage: {
    endpoint: process.env.OBJECT_STORAGE_ENDPOINT || 'https://storagegw.estaleiro.serpro.gov.br',
    accessKeyId: process.env.OBJECT_STORAGE_ACCESS_KEY_ID || 'be7f15b3a17c460783b47f91ed655bf3',
    secretAccessKey: process.env.OBJECT_STORAGE_SECRET_ACCESS_KEY || 'e79b2f89e7664391a4bf5ae9e491cc05',
    bucketFotos: 'empregado-foto',
  },
  auth: {
    clientId: process.env.KCLOAK_CLIENT_ID || 'd_meudominio',
    bearerOnly: true,
    serverUrl: process.env.KCLOAK_URL || 'https://d-keycloak.estaleiro.serpro.gov.br/auth',
    secret: process.env.KCLOAK_SECRET || '18293752-46c2-42ff-934e-78cb5ecb831c',
    realm: 'serpro',
    realmPublicKey:
      process.env.KCLOAK_PUBLIC_KEY ||
      'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhSDQ8eFdWP97vCUKywZo2hV/sh+yF6E+gs7YXDfPRDCVwNwHlmZ2OxKH/tG9/25/J3iynpd29CIiAToi0P3gKFAwxaulhHFW7UmbrQfno/YB11Jutg+X2SLcImeYgXIOmOAWgWPmOD4YVvx5HIOWqv9y6MXtT1tXQ2sB0PZa3w4n00Gcw6D/p5xRtwmJHvXX8v0OLduMe2Inu2/n/fze70jHV4n5fDic9REvlQ1TnPr8MuftRr+M53fYxFcAM9yDbz0+JyfsfOquhqFYwmRyDTu2YDiS0w1CkKUfBEZN9TXdbRtm1sXXLiwoRfi6JeaYPg2kACSE7NhUT1Nb4pf5HQIDAQAB',
    scope: 'openid',
  },
  database: {
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASS || 'postgres',
    name: process.env.DB_NAME || 'meudominio',
    port: +(process.env.DB_PORT || 5432),
    host: process.env.DB_HOST || 'localhost',
  },
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASS,
  },
};
