import 'reflect-metadata';

import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { initializeTransactionalContext, patchTypeORMRepositoryWithBaseRepository } from 'typeorm-transactional-cls-hooked';
import { ApplicationModule } from './app';
import config from './config';

const bodyParser = require('body-parser');

const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const Keycloak = require('keycloak-connect');
const moment = require('moment');

const keycloak = new Keycloak({}, config.auth);

async function bootstrap() {
  initializeTransactionalContext();
  patchTypeORMRepositoryWithBaseRepository();
  const app = await NestFactory.create(ApplicationModule, {
    logger: console,
  });
  app.setGlobalPrefix('api/core');
  /*app.useGlobalPipes(
    new ValidationPipe({
      forbidUnknownValues: true,
      whitelist: true,
      transform: true,
    }),
  );*/
  app.use(helmet());
  const serverTimestamp = moment().format('YYYYMMDDHHmmss');
  const serverHeaderKey = 'Server-Timestamp';
  app.use(cors({ exposedHeaders: [serverHeaderKey] }));
  app.use((req, res, next) => {
    res.setHeader(serverHeaderKey, serverTimestamp);
    next();
  });
  app.use(compression());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(bodyParser.json());
  app.use(keycloak.middleware());
  app.use(/^\/api\/core\/(?!docs).+$/, keycloak.protect());
  const options = new DocumentBuilder()
    .setTitle('MeuDominio.SERPRO')
    .setDescription('API REST do Portal MeuDominio.SERPRO')
    .setVersion('2.0')
    .setExternalDoc('Documentação Completa', 'https://meudominio.pages.serpro/documentacao/api')
    .setContact('Vitor Rodrigo Rosan', null, 'vitor.rosan@serpro.gov.br')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('/api/core/docs', app, document);
  await app.listen(process.env.BACKEND_PORT || 9000);
}
bootstrap();
