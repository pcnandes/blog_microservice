import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaEmpregado1564684402576 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE CAST (character varying AS date) WITH INOUT AS IMPLICIT;
      CREATE CAST (character varying AS timestamp) WITH INOUT AS IMPLICIT;
      DROP TABLE IF EXISTS empregado;
      CREATE TABLE empregado (
        cpf CHARACTER(11) NOT NULL,
        matricula INTEGER NOT NULL,
        nome CHARACTER VARYING(255),
        lotacao CHARACTER VARYING(100),
        teletrabalhador BOOLEAN,
        funcao_confianca CHARACTER VARYING(50),
        cargo CHARACTER VARYING(50),
        data_desligamento DATE,
        jornada SMALLINT,
        ramal CHARACTER VARYING(100),
        email CHARACTER VARYING(254),
        foto CHARACTER VARYING(100),
        especializacao CHARACTER VARYING,
        classe CHARACTER VARYING,
        estabelecimento CHARACTER VARYING,
        regional CHARACTER VARYING,
        data_carga TIMESTAMP WITHOUT TIME ZONE
      );
      ALTER TABLE ONLY empregado ADD CONSTRAINT empregado_pk PRIMARY KEY (cpf);
      CREATE INDEX idx_empregado_matricula ON empregado(matricula);
      COMMENT ON COLUMN empregado.data_carga IS 'Data/Hora em que o registro foi atualizado';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS empregado;
    `);
  }
}
