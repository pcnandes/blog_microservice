import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaServico1564684446564 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS integer[]);`);
    await queryRunner.query(`CREATE CAST (character varying AS integer[]) WITH INOUT AS IMPLICIT;`);
    await queryRunner.query(`
      DROP TABLE IF EXISTS servico;
      CREATE TABLE servico (
        codigo INTEGER NOT NULL,
        padrao BOOLEAN,
        ug CHARACTER VARYING,
        cliente CHARACTER VARYING,
        mnemonico CHARACTER VARYING,
        titulo CHARACTER VARYING,
        data_desativacao DATE,
        gestor_tecnico integer,
        gestor_negocio integer,
        gestor_servico integer,
        data_carga TIMESTAMP WITHOUT TIME ZONE
      );
      ALTER TABLE ONLY servico ADD CONSTRAINT servico_pk PRIMARY KEY (codigo);
      COMMENT ON COLUMN servico.data_carga IS 'Data/Hora em que o registro foi atualizado';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS servico;
      DROP CAST IF EXISTS (character varying AS integer[]);
    `);
  }
}
