import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaUsuario1564684487094 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS character varying[]);`);
    await queryRunner.query(`CREATE CAST (character varying AS character varying[]) WITH INOUT AS IMPLICIT;`);
    await queryRunner.query(`DROP TABLE IF EXISTS usuario;`);
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`);
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS uuid);`);
    await queryRunner.query(`CREATE CAST (character varying AS uuid) WITH INOUT AS IMPLICIT;`);
    await queryRunner.query(`
      CREATE TABLE usuario (
        id UUID NOT NULL DEFAULT uuid_generate_v4(),
        username CHARACTER VARYING(20),
        perfis CHARACTER VARYING[],
        versao INTEGER
      );
      ALTER TABLE ONLY usuario ADD CONSTRAINT usuario_pk PRIMARY KEY (id);
      CREATE UNIQUE INDEX usuario_uk ON usuario(username);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP EXTENSION IF EXISTS "uuid-ossp";`);
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS uuid);`);
    await queryRunner.query(`DROP TABLE IF EXISTS usuario;`);
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS character varying[]);`);
  }
}
