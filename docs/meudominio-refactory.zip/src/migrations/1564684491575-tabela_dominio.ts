import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaDominio1564684491575 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS dominio;`);
    await queryRunner.query(`
      CREATE TABLE dominio (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        codigo CHARACTER(4) NOT NULL,
        nome CHARACTER VARYING(256),
        gestor_dominio CHARACTER(11),
        gestor_negocio CHARACTER(11),
        descricao TEXT,
        ug_negocio CHARACTER VARYING(5),
        ug_dominio CHARACTER VARYING(5),
        situacao CHARACTER VARYING(100),
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY dominio ADD CONSTRAINT dominio_pk PRIMARY KEY (id);
      CREATE UNIQUE INDEX dominio_uk ON dominio(codigo);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS dominio;`);
  }
}
