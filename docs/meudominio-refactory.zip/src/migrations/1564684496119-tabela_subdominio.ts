import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaSubdominio1564684496119 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS subdominio;`);
    await queryRunner.query(`
      CREATE TABLE subdominio (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        dominio UUID NOT NULL,
        codigo CHARACTER(8) NOT NULL,
        nome CHARACTER VARYING(256),
        descricao TEXT,
        situacao CHARACTER VARYING(100),
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY subdominio ADD CONSTRAINT subdominio_pk PRIMARY KEY (id);
      ALTER TABLE ONLY subdominio ADD CONSTRAINT subdominio_fk FOREIGN KEY (dominio) REFERENCES dominio(id);
      CREATE UNIQUE INDEX subdominio_uk ON subdominio(dominio,codigo);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS subdominio;`);
  }
}
