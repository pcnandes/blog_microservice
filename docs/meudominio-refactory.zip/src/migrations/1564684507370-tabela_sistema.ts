import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaSistema1564684507370 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS integer[]);`);
    await queryRunner.query(`CREATE CAST (character varying AS integer[]) WITH INOUT AS IMPLICIT;`);
    await queryRunner.query(`DROP TABLE IF EXISTS sistema;`);
    await queryRunner.query(`
      CREATE TABLE sistema (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        identificador CHARACTER VARYING(20),
        sigla CHARACTER VARYING(100),
        situacao CHARACTER VARYING(100),
        nome CHARACTER VARYING(256),
        descricao TEXT,
        subdominio UUID,
        producao BOOLEAN,
        linha_negocio CHARACTER VARYING(50),
        codigo_servico_principal INTEGER,
        codigo_servico_adicional INTEGER[],
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY sistema ADD CONSTRAINT sistema_pk PRIMARY KEY (id);
      ALTER TABLE ONLY sistema ADD CONSTRAINT sistema_fk_dominio FOREIGN KEY (subdominio) REFERENCES subdominio(id);
      CREATE UNIQUE INDEX sistema_uk ON sistema(identificador);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS sistema;`);
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS integer[]);`);
  }
}
