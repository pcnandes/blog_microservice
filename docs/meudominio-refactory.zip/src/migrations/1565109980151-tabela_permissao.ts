import { MigrationInterface, QueryRunner } from 'typeorm';

export class DominioPermissao1565109980151 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS permissao;`);
    await queryRunner.query(`
      CREATE TABLE permissao (
        pk UUID DEFAULT uuid_generate_v4() NOT NULL,
        recurso UUID NOT NULL,
        usuario CHARACTER(11) NOT NULL,
        operacoes CHARACTER VARYING[] NOT NULL,
        versao INTEGER
      );
      ALTER TABLE ONLY permissao ADD CONSTRAINT permissao_pk PRIMARY KEY (pk);
      CREATE UNIQUE INDEX permissao_ur ON permissao(usuario, recurso);
      CREATE UNIQUE INDEX permissao_ru ON permissao(recurso, usuario);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS permissao;`);
  }
}
