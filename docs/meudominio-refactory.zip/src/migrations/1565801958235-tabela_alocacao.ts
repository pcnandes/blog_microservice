import { MigrationInterface, QueryRunner } from 'typeorm';

export class Alocacao1565801958235 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_historico;`);
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao;`);
    await queryRunner.query(`
      CREATE TABLE alocacao (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        empregado CHARACTER(11) NOT NULL,
        sistema UUID NOT NULL,
        percentual NUMERIC(5,2) NOT NULL DEFAULT 100.0,
        construcao NUMERIC(5,2) NOT NULL DEFAULT 0,
        sustentacao NUMERIC(5,2) NOT NULL DEFAULT 0,
        produto NUMERIC(5,2) NOT NULL DEFAULT 0,
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY alocacao ADD CONSTRAINT alocacao_pk PRIMARY KEY (id);
      ALTER TABLE ONLY alocacao ADD CONSTRAINT alocacao_fk FOREIGN KEY (sistema) REFERENCES sistema(id);
      CREATE UNIQUE INDEX alocacao_uk_sis ON alocacao(sistema,empregado);
      CREATE UNIQUE INDEX alocacao_uk_emp ON alocacao(empregado,sistema);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao;`);
  }
}
