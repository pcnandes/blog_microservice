import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaServicoDistribuido1566237629758 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS servico_distribuido CASCADE;`);
    await queryRunner.query(`
      CREATE TABLE servico_distribuido (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        servico INTEGER,
        sistema UUID,
        percentual NUMERIC(5,2),
        versao INTEGER
      );
      ALTER TABLE ONLY servico_distribuido ADD CONSTRAINT servico_distribuido_pk PRIMARY KEY (id);
      ALTER TABLE ONLY servico_distribuido ADD CONSTRAINT servico_distribuido_fk FOREIGN KEY (sistema) REFERENCES sistema(id) ON DELETE CASCADE;
      CREATE INDEX servico_distribuido_ix_sis ON servico_distribuido(sistema,servico);
      CREATE INDEX servico_distribuido_ix_srv ON servico_distribuido(servico,sistema);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS servico_distribuido;`);
  }
}
