import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaHistorico1568056026090 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS json);`);
    await queryRunner.query(`CREATE CAST (character varying AS json) WITH INOUT AS IMPLICIT;`);
    await queryRunner.query(`DROP TABLE IF EXISTS historico;`);
    await queryRunner.query(`
      CREATE TABLE historico (
        pk UUID DEFAULT uuid_generate_v4() NOT NULL,
        id CHARACTER VARYING(150) NOT NULL,
        autor CHARACTER VARYING(20),
        data TIMESTAMP WITHOUT TIME ZONE NOT NULL,
        operacao CHARACTER(1),
        entidade CHARACTER VARYING(50),
        atributos CHARACTER VARYING[],
        registro JSON,
        modificados JSON,
        proximo TIMESTAMP WITHOUT TIME ZONE
      );
      ALTER TABLE ONLY historico ADD CONSTRAINT historico_pk PRIMARY KEY (pk);
      CREATE INDEX idx_historico_eic ON historico(entidade,id,data);
      CREATE INDEX idx_historico_cei ON historico(data,entidade,id);
      CREATE INDEX idx_historico_eip ON historico(entidade,id,proximo);
      CREATE INDEX idx_historico_ade ON historico(autor,data,entidade);
      COMMENT ON COLUMN historico.atributos IS 'Lista dos atributos que foram alterados';
      COMMENT ON COLUMN historico.entidade IS 'Nome da entidade';
      COMMENT ON COLUMN historico.id IS 'Chave primária da entidade alterada';
      COMMENT ON COLUMN historico.data IS 'Data/Hora da alteração';
      COMMENT ON COLUMN historico.operacao IS 'I=Insert, U=Update, D=Delete';
      COMMENT ON COLUMN historico.registro IS 'Fotografia completa do registro (exceto a chave primária)';
      COMMENT ON COLUMN historico.proximo IS 'Data/Hora da próxima alteração';
      COMMENT ON COLUMN historico.modificados IS 'JSON com o valor anterior dos atributos que foram alterados';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP CAST IF EXISTS (character varying AS json);`);
    await queryRunner.query(`DROP TABLE IF EXISTS historico;`);
  }
}
