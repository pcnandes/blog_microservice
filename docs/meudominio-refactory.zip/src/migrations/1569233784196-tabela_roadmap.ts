import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaRoadmap1569233784196 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`DROP TABLE IF EXISTS roadmap;`);
        await queryRunner.query(`
        CREATE TABLE roadmap (
            id UUID DEFAULT uuid_generate_v4() NOT NULL,
            id_iteracao CHARACTER VARYING(100) NOT NULL,
            dominio UUID NOT NULL,
            autor CHARACTER(11) NOT NULL,
            data TIMESTAMP WITHOUT TIME ZONE NOT NULL,
            descricao CHARACTER VARYING(100),
            resumo_crc_registro bigint,
            registro JSON NOT NULL
        );
        ALTER TABLE ONLY roadmap ADD CONSTRAINT roadmap_pk PRIMARY KEY (id);
        ALTER TABLE ONLY roadmap ADD CONSTRAINT dominio_fk FOREIGN KEY (dominio) REFERENCES dominio(id);
        CREATE INDEX idx_roadmap_dominio ON roadmap(dominio);
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<any> {
        await queryRunner.query(`DROP TABLE IF EXISTS roadmap;`);
    }

}
