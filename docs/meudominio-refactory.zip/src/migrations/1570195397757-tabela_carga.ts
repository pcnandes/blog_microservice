import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaCarga1570195397757 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS carga;`);
    await queryRunner.query(`
      CREATE TABLE carga (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        informacao CHARACTER VARYING,
        data_execucao TIMESTAMP WITHOUT TIME ZONE,
        data_referencia TIMESTAMP WITHOUT TIME ZONE,
        registros_incluidos INTEGER NOT NULL DEFAULT 0,
        registros_alterados INTEGER NOT NULL DEFAULT 0,
        registros_removidos INTEGER NOT NULL  DEFAULT 0
      );
      ALTER TABLE ONLY carga ADD CONSTRAINT carga_pk PRIMARY KEY (id);
      CREATE INDEX idx_carga_di ON carga(data_execucao, informacao);
      CREATE INDEX idx_carga_id ON carga(informacao, data_execucao);
      COMMENT ON TABLE carga IS 'Informações sobre a execução de uma carga';
      COMMENT ON COLUMN carga.data_referencia IS 'Data/Hora em que o dado foi coletado no sistema de origem';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS carga;`);
  }
}
