import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlocacaoRateio1571054911560 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`ALTER TABLE alocacao DROP COLUMN IF EXISTS rateio;`);
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_rateio;`);
    await queryRunner.query(`
      CREATE TABLE alocacao_rateio (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        empregado CHARACTER(11) NOT NULL,
        rateio CHARACTER VARYING[] NOT NULL,
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY alocacao_rateio ADD CONSTRAINT alocacao_rateio_pk PRIMARY KEY (id);
      CREATE UNIQUE INDEX alocacao_rateio_ux ON alocacao_rateio(empregado);
    `);
    await queryRunner.query(`ALTER TABLE alocacao ADD COLUMN rateio UUID;`);
    await queryRunner.query(`ALTER TABLE ONLY alocacao ADD CONSTRAINT alocacao_rateio_fk FOREIGN KEY (rateio) REFERENCES alocacao_rateio(id) ON DELETE CASCADE`);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`ALTER TABLE alocacao DROP COLUMN IF EXISTS rateio;`);
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_rateio;`);
  }
}
