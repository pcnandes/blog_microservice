import {MigrationInterface, QueryRunner} from 'typeorm';

export class AlocacaoBaseline1571076692333 implements MigrationInterface {

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_snapshot;`);
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_baseline;`);

    await queryRunner.query(`
      CREATE TABLE alocacao_baseline (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        -- anomes
        periodo INTEGER NOT NULL,
        data TIMESTAMP WITHOUT TIME ZONE NOT NULL
        -- autor CHARACTER(11),
        -- descricao CHARACTER VARYING(256)
      );
      ALTER TABLE ONLY alocacao_baseline ADD CONSTRAINT alocacao_baseline_pk PRIMARY KEY (id);
    `);

    await queryRunner.query(`
      CREATE TABLE alocacao_snapshot (
        pk UUID DEFAULT uuid_generate_v4() NOT NULL,
        -- fk da alocacao-baseline
        baseline UUID NOT NULL,
        -- id da alocacao
        id UUID,
        empregado JSON NOT NULL,
        sistema JSON,
        percentual NUMERIC(5,2),
        construcao NUMERIC(5,2),
        sustentacao NUMERIC(5,2),
        produto NUMERIC(5,2),
        rateio boolean
      );
      ALTER TABLE ONLY alocacao_snapshot ADD CONSTRAINT alocacao_snapshot_pk PRIMARY KEY (pk);
      ALTER TABLE ONLY alocacao_snapshot
        ADD CONSTRAINT alocacao_snapshot_fk FOREIGN KEY (baseline)
          REFERENCES alocacao_baseline(id) ON DELETE CASCADE;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_snapshot;`);
    await queryRunner.query(`DROP TABLE IF EXISTS alocacao_baseline;`);
  }

}
