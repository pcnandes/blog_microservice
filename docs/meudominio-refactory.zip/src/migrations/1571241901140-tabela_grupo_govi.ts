import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaGrupoGovi1571241901140 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS grupo_govi;
      CREATE TABLE grupo_govi (
        id INTEGER NOT NULL,
        sigla CHARACTER VARYING(100) NOT NULL,
        nivel SMALLINT,
        ug CHARACTER VARYING(10),
        situacao CHARACTER VARYING(10),
        codigo_servico INTEGER,
        dominio CHARACTER(4),
        subdominio CHARACTER(8),
        data_carga TIMESTAMP WITHOUT TIME ZONE
      );
      ALTER TABLE ONLY grupo_govi ADD CONSTRAINT grupo_govi_pk PRIMARY KEY (id);
      CREATE INDEX idx_grupo_govi_sigla ON grupo_govi(sigla);
      CREATE INDEX idx_grupo_govi_dominio ON grupo_govi(dominio, subdominio, codigo_servico);
      COMMENT ON COLUMN grupo_govi.data_carga IS 'Data/Hora em que o registro foi atualizado';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS grupo_govi;`);
  }
}
