import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaAfastamento1571323237547 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS afastamento;
      CREATE TABLE afastamento (
        id INTEGER NOT NULL,
        empregado CHARACTER(11) NOT NULL,
        motivo CHARACTER VARYING(200),
        data_inicio DATE,
        data_termino DATE,
        data_cancelamento DATE,
        data_carga TIMESTAMP WITHOUT TIME ZONE
      );
      ALTER TABLE ONLY afastamento ADD CONSTRAINT afastamento_pk PRIMARY KEY (id);
      CREATE INDEX idx_afastamento_empregado ON afastamento(empregado, data_inicio);
      CREATE INDEX idx_afastamento_inicio ON afastamento(data_inicio, empregado);
      COMMENT ON COLUMN afastamento.data_carga IS 'Data/Hora em que o registro foi atualizado';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS afastamento;`);
  }
}
