import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewAlocacao1571323237550 implements MigrationInterface {
  public static VIEW = `
      DROP VIEW IF EXISTS vw_empregado_alocacao;
      CREATE OR REPLACE VIEW vw_empregado_alocacao AS
      SELECT empr.cpf
        ,COALESCE(SUM(aloc.percentual),0) AS percentual
        ,COUNT(DISTINCT aloc.sistema) AS sistemas
				,COALESCE(SUM(aloc.percentual * 0.01 * aloc.construcao),0)::NUMERIC(5,2) AS construcao
        ,COALESCE(SUM(aloc.percentual * 0.01 * aloc.sustentacao),0)::NUMERIC(5,2) AS sustentacao
        ,COALESCE(SUM(aloc.percentual * 0.01 * aloc.produto),0)::NUMERIC(5,2) AS produto
        ,COALESCE(MIN(CASE WHEN aloc.rateio IS NOT NULL THEN 'R' ELSE 'S' END),'R') AS rateio
      FROM empregado empr
        LEFT JOIN alocacao aloc ON empr.cpf=aloc.empregado
      GROUP BY empr.cpf;
      COMMENT ON VIEW vw_empregado_alocacao IS 'View com a alocação total por empregado';
    `;

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(ViewAlocacao1571323237550.VIEW);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_alocacao;`);
  }
}
