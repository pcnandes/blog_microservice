import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewInconsistencias1571323237551 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_inconsistencia;`);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_inconsistencia AS
      WITH sistema_servico AS (
        SELECT dom.id AS dominio
          ,sub.id AS subdominio
          ,sis.id AS sistema
          ,UNNEST(ARRAY[sis.codigo_servico_principal] || COALESCE(sis.codigo_servico_adicional,ARRAY[]::integer[])) AS codigo
        FROM sistema sis
          INNER JOIN subdominio sub ON sub.id=sis.subdominio
          INNER JOIN dominio dom ON dom.id=sub.dominio
      )
      ,percentual_custo AS (
        SELECT servico, SUM(COALESCE(percentual,100)) AS percentual
        FROM servico_distribuido
        GROUP BY servico
      )
      ,inconsistencias AS (
        SELECT a.dominio, a.subdominio, a.sistema
          ,'SERVICO_MULTIPLOS_SISTEMAS' AS descricao
          ,ARRAY_TO_STRING(ARRAY_AGG(DISTINCT BTRIM(LPAD(a.codigo::text,5,'0'))),',') AS detalhes
        FROM sistema_servico a
          INNER JOIN sistema_servico b ON a.codigo=b.codigo AND a.sistema<>b.sistema
          LEFT JOIN servico_distribuido c ON c.servico=a.codigo AND c.sistema=a.sistema
          LEFT JOIN percentual_custo p ON p.servico=a.codigo
        WHERE c.percentual IS NULL OR p.percentual IS DISTINCT FROM 100.0
        GROUP BY a.dominio, a.subdominio, a.sistema

        UNION ALL

        SELECT dom.id AS dominio
          ,sub.id AS subdominio
          ,sis.id AS sistema
          ,'SERVICO_PRINCIPAL_INATIVO' AS descricao
          ,BTRIM(LPAD(srv.codigo::text,5,'0')) AS detalhes
        FROM sistema sis
          INNER JOIN subdominio sub ON sub.id=sis.subdominio
          INNER JOIN dominio dom ON dom.id=sub.dominio
          INNER JOIN servico srv ON srv.codigo=sis.codigo_servico_principal
        WHERE srv.data_desativacao IS NOT NULL
      )
      SELECT ROW_NUMBER() OVER(ORDER BY dominio, subdominio, sistema, descricao) AS id
        ,*
      FROM inconsistencias;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_inconsistencia;`);
  }
}
