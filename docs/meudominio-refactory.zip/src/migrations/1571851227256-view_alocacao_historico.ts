import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewAlocacaoAlocacao1571851227256 implements MigrationInterface {
  public static VIEW = `
      DROP VIEW IF EXISTS vw_alocacao_historico;
      CREATE OR REPLACE VIEW vw_alocacao_historico AS
      -- todas as alocações registradas para um determinado empregado
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.registro#>>'{empregado,cpf}' as empregado
        ,null::text as operacao
        ,array_to_json(array_agg(json_build_object(
          'operacao', hist.operacao,
          'percentual', hist.registro->'percentual',
          'construcao', hist.registro->'construcao',
          'sustentacao', hist.registro->'sustentacao',
          'produto', hist.registro->'produto',
          'sistema', sis.registro->>'identificador',
          'subdominio', sub.registro->>'codigo'
        ) order by sub.registro->>'codigo', sis.registro->>'identificador')) as registro
        ,1 as prioridade
      from historico hist
        left join historico sis on sis.id=(hist.registro#>>'{sistema,id}')::uuid and sis.entidade='Sistema' and hist.data >= sis.data and hist.data < coalesce(sis.proximo, '3000-01-01')
        left join historico sub on sub.id=(sis.registro#>>'{subdominio,id}')::uuid and sub.entidade='SubDominio' and sis.data >= sub.data and sis.data < coalesce(sub.proximo, '3000-01-01')
      where hist.entidade='Alocacao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{empregado,cpf}'
      union all
      -- todos os rateios feitos para um empregado
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.registro#>>'{empregado,cpf}' as empregado
        ,hist.operacao
        ,hist.registro->'rateio' as registro
        ,2 as prioridade
      from historico hist
      where hist.entidade='AlocacaoRateio';
    `;

  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(ViewAlocacaoAlocacao1571851227256.VIEW);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_alocacao_historico;`);
  }
}
