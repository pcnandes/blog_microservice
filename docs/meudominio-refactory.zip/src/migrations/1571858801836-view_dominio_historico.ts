import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewDominioHistorico1571858801836 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_dominio_historico;`);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_dominio_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.id as dominio
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'codigo', registro->'codigo',
          'nome', registro->'nome',
          'descricao', registro->'descricao',
          'situacao', registro->'situacao',
          'ugNegocio', registro->'ugNegocio',
          'ugDominio', registro->'ugDominio',
          'gestorDominio', gd.nome,
          'gestorNegocio', gn.nome
        ) as registro
        ,1 as prioridade
      from historico hist
        left join empregado autor on autor.cpf=hist.autor
        left join empregado gd on gd.cpf=registro#>>'{gestorDominio,cpf}'
        left join empregado gn on gn.cpf=registro#>>'{gestorNegocio,cpf}'
      where hist.entidade='Dominio'
      union all
      -- inclusões e exclusões de subdomínios
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{dominio,id}') as dominio
        ,hist.operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'codigo', registro->'codigo',
          'nome', registro->'nome'
        ) order by registro->>'codigo')) as registro
        ,2 as prioridade
      from historico hist
      where hist.entidade='SubDominio' and hist.operacao in ('I','D')
      group by hist.data, hist.autor, hist.entidade, hist.operacao, (hist.registro#>>'{dominio,id}')
      -- alteração de permissões
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro->>'recurso') as dominio
        ,'U' as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
					'operacao',hist.operacao,
					'empregado',empr.nome,
					'permissoes',hist.registro->'operacoes'
        ) order by empr.nome)) as registro
        ,3 as prioridade
      from historico hist
        left join empregado empr on empr.cpf=hist.registro#>>'{empregado,cpf}'
      where hist.entidade='Permissao'
      group by hist.data, hist.autor, hist.entidade, (hist.registro->>'recurso');
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_dominio_historico;`);
  }
}
