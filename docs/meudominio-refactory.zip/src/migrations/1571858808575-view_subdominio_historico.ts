import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewSubDominioHistorico1571858808575 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_subdominio_historico;`);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_subdominio_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.id as subdominio
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'codigo', registro->'codigo',
          'nome', registro->'nome',
          'descricao', registro->'descricao',
          'situacao', registro->'situacao'
        ) as registro
        ,1 as prioridade
      from historico hist
      where hist.entidade='SubDominio'
      union all
      -- inclusões, exclusões de sistemas
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{subdominio,id}') as subdominio
        ,hist.operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'identificador', registro->'identificador',
          'nome', registro->'nome'
        ) order by registro->>'identificador')) as registro
        ,2 as prioridade
      from historico hist
      where hist.entidade='Sistema'
        and hist.operacao in ('I','D')
      group by hist.data, hist.autor, hist.entidade, hist.operacao, hist.registro#>>'{subdominio,id}'
      -- sistemas que sairam do subdominio
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.modificados#>>'{subdominio,id}') as subdominio
        ,'S' as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'identificador', registro->'identificador',
          'nome', registro->'nome'
        ) order by registro->>'identificador')) as registro
        ,3 as prioridade
      from historico hist
      where hist.entidade='Sistema'
        and hist.operacao='U' and 'subdominio'=any(hist.atributos)
      group by hist.data, hist.autor, hist.entidade, hist.operacao, hist.modificados#>>'{subdominio,id}'
      -- sistemas que entraram para o subdominio
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{subdominio,id}') as subdominio
        ,'E' as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'identificador', registro->'identificador',
          'nome', registro->'nome'
        ) order by registro->>'identificador')) as registro
        ,4 as prioridade
      from historico hist
      where hist.entidade='Sistema'
        and hist.operacao='U' and 'subdominio'=any(hist.atributos)
      group by hist.data, hist.autor, hist.entidade, hist.operacao, hist.registro#>>'{subdominio,id}';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_subdominio_historico;`);
  }
}
