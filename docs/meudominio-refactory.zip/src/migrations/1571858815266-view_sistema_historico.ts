import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewSistemaHistorico1571858815266 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_sistema_historico;`);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_sistema_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.id as sistema
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'subdominio', sub.codigo,
          'identificador', registro->'identificador',
          'sigla', registro->'sigla',
          'nome', registro->'nome',
          'descricao', registro->'descricao',
          'situacao', registro->'situacao',
          'linhaNegocio', registro->'linhaNegocio',
          'codigoServicoPrincipal', registro->'codigoServicoPrincipal',
          'codigoServicoAdicional', registro->'codigoServicoAdicional',
          'producao', registro->'producao'
        ) as registro
        ,1 as prioridade
      from historico hist
        left join subdominio sub on sub.id=(registro#>>'{subdominio,id}')::uuid
      where hist.entidade='Sistema'
      -- alocacao
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{sistema,id}') as sistema
        ,null::varchar as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'operacao', hist.operacao,
          'empregado', empr.nome,
          'percentual', hist.registro->>'percentual',
          'construcao', hist.registro->>'construcao',
          'sustentacao', hist.registro->>'sustentacao',
          'produto', hist.registro->>'produto'
        ) order by empr.nome)) as registro
        ,2 as prioridade
      from historico hist
        left join empregado empr on empr.cpf=hist.registro#>>'{empregado,cpf}'
      where hist.entidade='Alocacao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{sistema,id}';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_sistema_historico;`);
  }
}
