import { MigrationInterface, QueryRunner } from 'typeorm';

export class ViewUsuarioHistorico1571858826235 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_usuario_historico;`);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_usuario_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,registro->>'username' as usuario
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'perfis', registro->'perfis'
        ) as registro
        ,1 as prioridade
      from historico hist
      where hist.entidade='Usuario'
      -- alteração de permissões
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.registro#>>'{empregado, cpf}' as usuario
        ,'U' as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'op',hist.operacao,
          'recurso',dom.registro->>'nome',
          'operacoes',hist.registro->'operacoes'
        ) order by dom.registro->>'nome')) as registro
        ,2 as prioridade
      from historico hist
        left join historico dom on dom.id=(hist.registro->>'recurso') and dom.entidade='Dominio' and hist.data >= dom.data and hist.data < coalesce(dom.proximo, '3000-01-01')
      where hist.entidade='Permissao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{empregado, cpf}';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP VIEW IF EXISTS vw_usuario_historico;`);
  }
}
