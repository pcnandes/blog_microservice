import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaEmpregadoRemoveFoto1572886502968 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
          ALTER TABLE empregado
          DROP COLUMN foto;
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
        ALTER TABLE empregado
        ADD COLUMN foto CHARACTER VARYING(100);
        `);
  }
}
