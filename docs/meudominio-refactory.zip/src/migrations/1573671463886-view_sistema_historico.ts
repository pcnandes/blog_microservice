import {MigrationInterface, QueryRunner} from 'typeorm';

export class ViewSistemaHistorico1573671463886 implements MigrationInterface {

public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_sistema_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.id as sistema
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'subdominio', sub.registro -> 'codigo',
          'identificador', hist.registro->'identificador',
          'sigla', hist.registro->'sigla',
          'nome', hist.registro->'nome',
          'descricao', hist.registro->'descricao',
          'situacao', hist.registro->'situacao',
          'linhaNegocio', hist.registro->'linhaNegocio',
          'codigoServicoPrincipal', hist.registro->'codigoServicoPrincipal',
          'codigoServicoAdicional', hist.registro->'codigoServicoAdicional',
          'producao', hist.registro->'producao'
        ) as registro
        ,1 as prioridade
      from historico hist
        left join historico sub on sub.id=(hist.registro#>>'{subdominio,id}')::uuid and sub.entidade='SubDominio' and hist.data >= sub.data and hist.data < coalesce(sub.proximo, '3000-01-01')
      where hist.entidade='Sistema'
      -- alocacao
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{sistema,id}') as sistema
        ,null::varchar as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'operacao', hist.operacao,
          'empregado', empr.nome,
          'percentual', hist.registro->>'percentual',
          'construcao', hist.registro->>'construcao',
          'sustentacao', hist.registro->>'sustentacao',
          'produto', hist.registro->>'produto'
        ) order by empr.nome)) as registro
        ,2 as prioridade
      from historico hist
        left join empregado empr on empr.cpf=hist.registro#>>'{empregado,cpf}'
      where hist.entidade='Alocacao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{sistema,id}';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_sistema_historico AS
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.id as sistema
        ,hist.operacao
        ,hist.atributos
        ,json_build_object(
          'subdominio', sub.codigo,
          'identificador', registro->'identificador',
          'sigla', registro->'sigla',
          'nome', registro->'nome',
          'descricao', registro->'descricao',
          'situacao', registro->'situacao',
          'linhaNegocio', registro->'linhaNegocio',
          'codigoServicoPrincipal', registro->'codigoServicoPrincipal',
          'codigoServicoAdicional', registro->'codigoServicoAdicional',
          'producao', registro->'producao'
        ) as registro
        ,1 as prioridade
      from historico hist
        left join subdominio sub on sub.id=(registro#>>'{subdominio,id}')::uuid
      where hist.entidade='Sistema'
      -- alocacao
      union all
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,(hist.registro#>>'{sistema,id}') as sistema
        ,null::varchar as operacao
        ,null::varchar[] as atributos
        ,array_to_json(array_agg(json_build_object(
          'operacao', hist.operacao,
          'empregado', empr.nome,
          'percentual', hist.registro->>'percentual',
          'construcao', hist.registro->>'construcao',
          'sustentacao', hist.registro->>'sustentacao',
          'produto', hist.registro->>'produto'
        ) order by empr.nome)) as registro
        ,2 as prioridade
      from historico hist
        left join empregado empr on empr.cpf=hist.registro#>>'{empregado,cpf}'
      where hist.entidade='Alocacao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{sistema,id}';
    `);
  }

}
