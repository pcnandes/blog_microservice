import { ViewAlocacao1571323237550 } from './1571323237550-view_empregado_alocacao';
import { MigrationInterface, QueryRunner } from 'typeorm';
import { ViewAlocacaoAlocacao1571851227256 } from './1571851227256-view_alocacao_historico';

export class AlocacaoSuporte1576587204943 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      DROP VIEW IF EXISTS vw_empregado_alocacao;
      ALTER TABLE alocacao ADD COLUMN construcao_int INTEGER NOT NULL DEFAULT 0;
      ALTER TABLE alocacao ADD COLUMN sustentacao_int INTEGER NOT NULL DEFAULT 0;
      ALTER TABLE alocacao ADD COLUMN produto_int INTEGER NOT NULL DEFAULT 0;
      UPDATE alocacao SET construcao_int=CEIL(construcao), sustentacao_int=FLOOR(sustentacao), produto_int=FLOOR(produto);
      ALTER TABLE alocacao DROP COLUMN construcao;
      ALTER TABLE alocacao DROP COLUMN sustentacao;
      ALTER TABLE alocacao DROP COLUMN produto;
      ALTER TABLE alocacao RENAME COLUMN construcao_int TO construcao;
      ALTER TABLE alocacao RENAME COLUMN sustentacao_int TO sustentacao;
      ALTER TABLE alocacao RENAME COLUMN produto_int TO produto;
    `);
    await queryRunner.query(`
      ALTER TABLE alocacao ADD COLUMN suporte INTEGER NOT NULL DEFAULT 0;
      ALTER TABLE alocacao ADD COLUMN gestao INTEGER NOT NULL DEFAULT 0;
      ALTER TABLE alocacao ADD COLUMN administrativo INTEGER NOT NULL DEFAULT 0;
      ALTER TABLE alocacao ALTER COLUMN sistema DROP NOT NULL;
      DROP INDEX alocacao_uk_emp;
      DROP INDEX alocacao_uk_sis;
      CREATE INDEX idx_alocacao_emp ON alocacao(empregado, sistema);
      CREATE INDEX idx_alocacao_sis ON alocacao(sistema, empregado);
    `);
    await queryRunner.query(`
      DROP VIEW IF EXISTS vw_alocacao_historico;
      CREATE OR REPLACE VIEW vw_alocacao_historico AS
      -- todas as alocações registradas para um determinado empregado
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.registro#>>'{empregado,cpf}' as empregado
        ,null::text as operacao
        ,array_to_json(array_agg(json_build_object(
          'operacao', hist.operacao,
          'percentual', hist.registro->'percentual',
          'construcao', hist.registro->'construcao',
          'sustentacao', hist.registro->'sustentacao',
          'produto', hist.registro->'produto',
          'suporte', hist.registro->'suporte',
          'gestao', hist.registro->'gestao',
          'administrativo', hist.registro->'administrativo',
          'sistema', sis.registro->>'identificador',
          'subdominio', sub.registro->>'codigo'
        ) order by sub.registro->>'codigo', sis.registro->>'identificador')) as registro
        ,1 as prioridade
      from historico hist
        left join historico sis on sis.id=(hist.registro#>>'{sistema,id}')::uuid and sis.entidade='Sistema' and hist.data >= sis.data and hist.data < coalesce(sis.proximo, '3000-01-01')
        left join historico sub on sub.id=(sis.registro#>>'{subdominio,id}')::uuid and sub.entidade='SubDominio' and sis.data >= sub.data and sis.data < coalesce(sub.proximo, '3000-01-01')
      where hist.entidade='Alocacao'
      group by hist.data, hist.autor, hist.entidade, hist.registro#>>'{empregado,cpf}'
      union all
      -- todos os rateios feitos para um empregado
      select hist.data
        ,hist.autor
        ,hist.entidade
        ,hist.registro#>>'{empregado,cpf}' as empregado
        ,hist.operacao
        ,hist.registro->'rateio' as registro
        ,2 as prioridade
      from historico hist
      where hist.entidade='AlocacaoRateio';
    `);
    await queryRunner.query(`
      CREATE OR REPLACE VIEW vw_empregado_alocacao AS
      SELECT empr.cpf
        ,COALESCE(SUM(aloc.percentual),0) AS percentual
        ,COUNT(DISTINCT aloc.sistema) AS sistemas
				,COALESCE(SUM(aloc.percentual * aloc.construcao)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS construcao
        ,COALESCE(SUM(aloc.percentual * aloc.sustentacao)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS sustentacao
        ,COALESCE(SUM(aloc.percentual * aloc.produto)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS produto
        ,COALESCE(SUM(aloc.percentual * aloc.suporte)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS suporte
        ,COALESCE(SUM(aloc.percentual * aloc.gestao)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS gestao
        ,COALESCE(SUM(aloc.percentual * aloc.administrativo)/SUM(aloc.percentual),0)::NUMERIC(5,2) AS administrativo
        ,COALESCE(MIN(CASE WHEN aloc.rateio IS NOT NULL THEN 'R' ELSE 'S' END),'R') AS rateio
      FROM empregado empr
        LEFT JOIN alocacao aloc ON empr.cpf=aloc.empregado
      GROUP BY empr.cpf;
      COMMENT ON VIEW vw_empregado_alocacao IS 'View com a alocação total por empregado';
    `);
    await queryRunner.query(`UPDATE historico SET autor='BATCH' WHERE autor='SGP';`);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    // TODO: o que fazer com o histórico se houver esse tipo de alocação na base?
    await queryRunner.query(ViewAlocacao1571323237550.VIEW);
    await queryRunner.query(ViewAlocacaoAlocacao1571851227256.VIEW);
    await queryRunner.query(`
      ALTER TABLE alocacao DROP COLUMN IF EXISTS suporte;
      ALTER TABLE alocacao DROP COLUMN IF EXISTS gestao;
      ALTER TABLE alocacao DROP COLUMN IF EXISTS administrativo;
      DROP INDEX idx_alocacao_emp;
      DROP INDEX idx_alocacao_sis;
      DELETE FROM alocacao WHERE sistema IS NULL;
      ALTER TABLE alocacao ALTER COLUMN sistema SET NOT NULL;
      CREATE UNIQUE INDEX alocacao_uk_emp ON alocacao(empregado, sistema);
      CREATE UNIQUE INDEX alocacao_uk_sis ON alocacao(sistema, empregado);
    `);
  }
}
