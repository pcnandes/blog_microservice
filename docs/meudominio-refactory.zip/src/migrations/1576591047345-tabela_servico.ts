import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaServico1576591047345 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`ALTER TABLE servico DROP COLUMN IF EXISTS compartilhado;`);
    await queryRunner.query(`ALTER TABLE servico ADD COLUMN compartilhado BOOLEAN NOT NULL DEFAULT FALSE;`);
    await queryRunner.query(`UPDATE servico SET compartilhado=TRUE WHERE codigo IN (SELECT DISTINCT servico FROM servico_distribuido);`);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
