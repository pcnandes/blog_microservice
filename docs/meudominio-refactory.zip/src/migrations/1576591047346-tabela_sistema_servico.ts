import { MigrationInterface, QueryRunner } from 'typeorm';

export class SistemaServico1576591047346 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE IF EXISTS sistema_servico;`);
    await queryRunner.query(`
      CREATE TABLE sistema_servico (
        id UUID DEFAULT uuid_generate_v4() NOT NULL,
        sistema UUID NOT NULL,
        servico INTEGER NOT NULL,
        principal boolean NOT NULL DEFAULT false,
        grupogovi CHARACTER VARYING[],
        percentual SMALLINT DEFAULT 100,
        versao INTEGER NOT NULL
      );
      ALTER TABLE ONLY sistema_servico ADD CONSTRAINT sistema_servico_pk PRIMARY KEY (id);
      ALTER TABLE ONLY sistema_servico ADD CONSTRAINT sistema_servico_fk_sistema FOREIGN KEY (sistema) REFERENCES sistema(id);
      CREATE UNIQUE INDEX sistema_servico_uk ON sistema_servico(sistema, servico);
      CREATE UNIQUE INDEX servico_sistema_uk ON sistema_servico(servico, sistema);
    `);
    // migra os dados para tova tabela
    await queryRunner.query(`
      insert into sistema_servico (id, sistema, servico, principal, versao, percentual)
      select x.id, x.sistema, x.servico, x.principal, x.versao, coalesce(cast(d.percentual as integer),100) as percentual
      from
      (
        select uuid_generate_v4() as id,
              id as sistema,
              codigo_servico_principal as servico,
              true as principal,
              1 as versao
            from sistema
            union all
            select uuid_generate_v4() as id,
              id as sistem,
              UNNEST (codigo_servico_adicional) as servico,
              false as principal,
              1 as versao
            from sistema
      ) x
      left join servico_distribuido d on d.sistema=x.sistema and d.servico=x.servico;
    `);

    // apagar vw_inconsistencia
    await queryRunner.query(`DROP VIEW IF EXISTS vw_inconsistencia;`);

    // criar vw_inconsistencia
    await queryRunner.query(`
      CREATE VIEW vw_inconsistencia AS
      WITH percentual AS (
        SELECT sis.servico
          ,SUM(COALESCE(sis.percentual, 0)) AS percentual
          ,COUNT(sis.sistema) AS quantidade
        FROM servico srv
          INNER JOIN sistema_servico sis ON sis.servico=srv.codigo
        GROUP BY sis.servico
      ),
      inconsistencias AS (
        SELECT dom.id AS dominio,
          sub.id AS subdominio,
          sis.id AS sistema,
          'SERVICO_MULTIPLOS_SISTEMAS'::text AS descricao,
          ARRAY_TO_STRING(ARRAY_AGG(DISTINCT btrim(LPAD(ssr.servico::text, 5, '0'::TEXT))), ','::TEXT) AS detalhes
        FROM sistema_servico ssr
          INNER JOIN percentual per ON per.servico = ssr.servico
          INNER JOIN sistema sis ON sis.id = ssr.sistema
          INNER JOIN subdominio sub ON sub.id = sis.subdominio
          INNER JOIN dominio dom ON dom.id = sub.dominio
          INNER JOIN servico srv ON srv.codigo=ssr.servico
        WHERE per.quantidade>1 AND (per.percentual<>100 OR ssr.percentual IS NULL OR srv.duplicavel=FALSE)
        GROUP BY dom.id, sub.id, sis.id
        UNION ALL
        SELECT dom.id AS dominio,
          sub.id AS subdominio,
          sis.id AS sistema,
          'SERVICO_PRINCIPAL_INATIVO'::text AS descricao,
          btrim(lpad(srv.codigo::text, 5, '0'::text)) AS detalhes
        FROM sistema sis
          JOIN subdominio sub ON sub.id = sis.subdominio
          JOIN dominio dom ON dom.id = sub.dominio
          JOIN sistema_servico sis_serv ON sis_serv.sistema = sis.id and sis_serv.principal = true
          JOIN servico srv ON srv.codigo = sis_serv.servico
        WHERE srv.data_desativacao IS NOT NULL
      )
      SELECT row_number() OVER (ORDER BY inconsistencias.dominio, inconsistencias.subdominio, inconsistencias.sistema, inconsistencias.descricao) AS id,
        inconsistencias.dominio,
        inconsistencias.subdominio,
        inconsistencias.sistema,
        inconsistencias.descricao,
        inconsistencias.detalhes
      FROM inconsistencias;
    `);

    // apagar atributos
    await queryRunner.query(`
      ALTER TABLE sistema DROP COLUMN codigo_servico_principal;
      ALTER TABLE sistema DROP COLUMN codigo_servico_adicional;
    `);

    // TODO migrar historico
    // await queryRunner.query(``);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    // await queryRunner.query(`DROP TABLE IF EXISTS sistema_servico;`);
    // TODO ver na reuniao tecnica
  }
}
