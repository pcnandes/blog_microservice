import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaGrupoGovi1580142736853 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`ALTER TABLE grupo_govi DROP COLUMN codigo_servico;`);
    await queryRunner.query(`ALTER TABLE grupo_govi DROP COLUMN dominio;`);
    await queryRunner.query(`ALTER TABLE grupo_govi DROP COLUMN subdominio;`);
    await queryRunner.query(`ALTER TABLE grupo_govi ADD COLUMN recorrencia1 CHARACTER(11);`);
    await queryRunner.query(`ALTER TABLE grupo_govi ADD COLUMN recorrencia2 CHARACTER(11);`);
    await queryRunner.query(`ALTER TABLE grupo_govi ADD COLUMN recorrencia3 CHARACTER(11);`);
    await queryRunner.query(`ALTER TABLE grupo_govi ADD COLUMN recorrencia4 CHARACTER(11);`);
    await queryRunner.query(`ALTER TABLE grupo_govi ADD COLUMN uf CHARACTER(2);`);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
