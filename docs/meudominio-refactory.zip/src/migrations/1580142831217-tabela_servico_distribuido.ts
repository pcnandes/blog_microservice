import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaServicoDistribuido1580142831217 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`DROP TABLE servico_distribuido;`);
    await queryRunner.query(`DELETE FROM historico WHERE entidade='ServicoDistribuido';`);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
