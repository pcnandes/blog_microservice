import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaAlocacaoRateio1580148281061 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`ALTER TABLE alocacao_rateio RENAME COLUMN rateio TO escopo;`);
    await queryRunner.query(`
      UPDATE historico SET atributos=string_to_array(replace(array_to_string(atributos,','),'rateio','escopo'),',')
        ,registro=replace(registro::text,'rateio','escopo')::json
        ,modificados=replace(modificados::text,'rateio','escopo')::json
      WHERE entidade='AlocacaoRateio';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
