import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaAlocacaoBaseline1580148365948 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE alocacao_snapshot RENAME COLUMN rateio TO rateada;
      ALTER TABLE alocacao_snapshot ADD COLUMN suporte INTEGER;
      ALTER TABLE alocacao_snapshot ADD COLUMN gestao INTEGER;
      ALTER TABLE alocacao_snapshot ADD COLUMN administrativo INTEGER;
      ALTER TABLE alocacao_snapshot ADD COLUMN construcao_int INTEGER;
      ALTER TABLE alocacao_snapshot ADD COLUMN sustentacao_int INTEGER;
      ALTER TABLE alocacao_snapshot ADD COLUMN produto_int INTEGER;
      UPDATE alocacao_snapshot SET construcao_int=CEIL(construcao), sustentacao_int=FLOOR(sustentacao), produto_int=FLOOR(produto);
      UPDATE alocacao_snapshot SET suporte=0, gestao=0, administrativo=0 WHERE percentual>0;
      ALTER TABLE alocacao_snapshot DROP COLUMN construcao;
      ALTER TABLE alocacao_snapshot DROP COLUMN sustentacao;
      ALTER TABLE alocacao_snapshot DROP COLUMN produto;
      ALTER TABLE alocacao_snapshot RENAME COLUMN construcao_int TO construcao;
      ALTER TABLE alocacao_snapshot RENAME COLUMN sustentacao_int TO sustentacao;
      ALTER TABLE alocacao_snapshot RENAME COLUMN produto_int TO produto;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
