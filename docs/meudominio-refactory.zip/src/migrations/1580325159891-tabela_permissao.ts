import { MigrationInterface, QueryRunner } from 'typeorm';

export class TabelaPermissao1580325159891 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<any> {
    await queryRunner.query(`
      ALTER TABLE permissao RENAME COLUMN recurso TO dominio;
      DELETE FROM permissao WHERE dominio NOT IN (SELECT id FROM dominio);
      ALTER TABLE permissao ADD CONSTRAINT permissao_dominio_fk FOREIGN KEY (dominio) REFERENCES dominio (id) ON DELETE CASCADE;
      UPDATE historico SET registro=replace(registro::text,'recurso','dominio')::json, modificados=replace(modificados::text,'recurso','dominio')::json, atributos=array_replace(atributos, 'recurso','dominio') WHERE entidade='Permissao';
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<any> {
    throw new Error('Operação não suportada');
  }
}
