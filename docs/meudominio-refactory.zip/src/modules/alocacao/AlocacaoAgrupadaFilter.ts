import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { isUUID } from '@nestjs/common/utils/is-uuid';

export class AlocacaoAgrupadaFilter {
  public readonly lotacao?: string;
  public readonly dominio?: string;
  public readonly subdominio?: string;
  public readonly sistema?: string;
  public readonly servico?: string;

  constructor(example?: Partial<AlocacaoAgrupadaFilter>) {
    this.sistema = example?.sistema;
    this.servico = example?.servico;
    this.subdominio = example?.subdominio;
    this.lotacao = example?.lotacao;
    this.dominio = example?.dominio;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public toSqlWhere(): string {
    let where = '';
    let count = 0;
    if (this.lotacao) {
      where = `${where} AND emp.lotacao ILIKE $${++count}`;
    }
    if (this.dominio) {
      where = `${where} AND ${isUUID(this.dominio) ? 'dom.id' : 'dom.codigo'} = $${++count}`;
    }
    if (this.subdominio) {
      where = `${where} AND ${isUUID(this.subdominio) ? 'sub.id' : 'sub.codigo'} = $${++count}`;
    }
    if (this.sistema) {
      where = `${where} AND ${isUUID(this.sistema) ? 'sis.id' : 'sis.identificador'} = $${++count}`;
    }
    if (this.servico) {
      where = `${where} AND srv.servico = ANY(CAST($${++count} AS INTEGER[]))`;
    }
    return where;
  }

  public toSqlParams(): any[] {
    const params = [];
    if (this.lotacao) {
      params.push(`${this.lotacao}%`);
    }
    if (this.dominio) {
      params.push(this.dominio);
    }
    if (this.subdominio) {
      params.push(this.subdominio);
    }
    if (this.sistema) {
      params.push(this.sistema);
    }
    if (this.servico) {
      const codigos = this.servico.split('-').map(srv => parseInt(srv, 10));
      params.push(`{${codigos.join(',')}}`);
    }
    return params;
  }
}
