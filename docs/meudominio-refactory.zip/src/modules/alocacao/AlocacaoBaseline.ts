import { ApiProperty } from '@nestjs/swagger';
import { LinhaNegocio } from '../sistema/LinhaNegocio';

class DominioBaselineDTO {
  @ApiProperty()
  public readonly id: string;
  @ApiProperty()
  public readonly codigo: string;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly categoria: string;
  @ApiProperty()
  public readonly ugDominio: string;
}

class SubDominioBaselineDTO {
  @ApiProperty()
  public readonly id: string;
  @ApiProperty()
  public readonly codigo: string;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly dominio: DominioBaselineDTO;
}

class SistemaBaselineDTO {
  @ApiProperty()
  public readonly id: string;
  @ApiProperty()
  public readonly identificador: string;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly linhaNegocio: LinhaNegocio;
  @ApiProperty()
  public readonly codigoServico: number;
  @ApiProperty()
  public readonly subdominio: SubDominioBaselineDTO;
}

class EmpregadoBaselineDTO {
  @ApiProperty()
  public readonly cpf: string;
  @ApiProperty()
  public readonly matricula: number;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly lotacao: string;
  @ApiProperty()
  public readonly teletrabalhador: boolean;
  @ApiProperty()
  public readonly funcaoConfianca: string;
}

export class AlocacaoBaseline {
  @ApiProperty()
  public readonly sistema: SistemaBaselineDTO;
  @ApiProperty()
  public readonly empregado: EmpregadoBaselineDTO;
  @ApiProperty()
  public readonly percentual: number;
  @ApiProperty()
  public readonly construcao: number;
  @ApiProperty()
  public readonly sustentacao: number;
  @ApiProperty()
  public readonly produto: number;
  @ApiProperty()
  public readonly suporte: number;
  @ApiProperty()
  public readonly gestao: number;
  @ApiProperty()
  public readonly administrativo: number;
  @ApiProperty()
  public readonly rateada: boolean;
}
