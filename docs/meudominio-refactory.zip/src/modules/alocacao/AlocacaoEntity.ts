import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsNotEmptyObject, IsNumber, Max, Min, IsInt } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { TransformerNumeric } from '../../common/repository/TransformerNumeric';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Dominio } from '../dominio/DominioEntity';
import { Empregado } from '../empregado/EmpregadoEntity';
import { Sistema } from '../sistema/SistemaEntity';
import { Example } from './../../common/utils/Types';

interface AlocacaoBuildParam {
  id: string;
  empregado: Empregado;
  sistema: Sistema;
  rateioID: string;
  percentual: number;
  construcao?: number;
  sustentacao?: number;
}

@Entity()
export class Alocacao {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional({ type: Sistema })
  @Allow()
  public readonly id?: string;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'empregado', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  @IsNotEmptyObject()
  public readonly empregado?: Empregado;

  @ManyToOne(type => Sistema)
  @JoinColumn({ name: 'sistema', referencedColumnName: 'id' })
  @ApiPropertyOptional({ type: Sistema })
  @Allow()
  public readonly sistema?: Sistema;

  @Column({ name: 'rateio' })
  public readonly rateioID?: string;

  @Column({ type: 'numeric', precision: 4, scale: 1, transformer: TransformerNumeric })
  @ApiPropertyOptional()
  @IsNumber()
  @Min(0, { message: 'O % alocado deve ser maior que zero' })
  @Max(100.0, { message: 'O % alocado deve ser no máximo 100' })
  public readonly percentual?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly construcao?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly sustentacao?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly produto?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly suporte?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly gestao?: number;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  @IsInt()
  public readonly administrativo?: number;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  constructor(example: Example<Alocacao> = {}) {
    this.id = example?.id;
    this.versao = example?.versao;
    this.empregado = example?.empregado ? new Empregado(example.empregado) : undefined;
    this.sistema = example?.sistema ? new Sistema(example.sistema) : example?.sistema;
    this.rateioID = example?.rateioID;
    this.percentual = example?.percentual || 0;
    this.construcao = example?.construcao || 0;
    this.sustentacao = example?.sustentacao || 0;
    this.produto = example?.produto || 0;
    this.suporte = example?.suporte || 0;
    this.gestao = example?.gestao || 0;
    this.administrativo = example?.administrativo || 0;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get dominio(): Dominio {
    if (this.sistema === undefined) {
      throw new Error('[Alocacao].sistema não carregado');
    }
    return this.sistema?.dominio;
  }

  public get dominioID(): string {
    if (this.sistema === undefined) {
      throw new Error('[Alocacao].sistema não carregado');
    }
    return this.sistema.dominioID;
  }

  public get possuiSistema(): boolean {
    if (this.sistema === undefined) {
      throw new Error('[Alocacao].sistema não carregado');
    }
    return !!this.sistema;
  }

  public get rateada(): boolean {
    if (this.rateioID === undefined) {
      throw new Error('[Alocacao].rateioID não carregado');
    }
    return !!this.rateioID;
  }

  public get totalSubProcesso(): number {
    return (
      (this.construcao || 0) +
      (this.sustentacao || 0) +
      (this.produto || 0) +
      (this.suporte || 0) +
      (this.gestao || 0) +
      (this.administrativo || 0)
    );
  }

  public static build({ id, empregado, sistema, rateioID, percentual, construcao, sustentacao }: AlocacaoBuildParam): Alocacao {
    let produto = 0;
    let suporte = 0;
    sustentacao = sustentacao || 0;
    construcao = construcao || 0;
    if (sistema) {
      if (sistema.isProdutoIndependente) {
        construcao = sustentacao = 0;
        produto = 100;
      } else if (sistema.isProdutoDependente) {
        sustentacao = 100;
        construcao = 0;
      } else if (construcao + sustentacao < 100) {
        sustentacao = Math.max(100 - construcao, 0);
      }
    } else {
      construcao = sustentacao = 0;
      suporte = 100;
    }
    return new Alocacao({ id, empregado, sistema, rateioID, percentual, construcao, sustentacao, produto, suporte });
  }
}
