import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DominioRepository } from '../dominio/DominioRepository';
import { DominioRepositoryORM } from '../dominio/DominioRepositoryORM';
import { CommonModule } from './../../common/CommonModule';
import { EmpregadoModule } from './../empregado/EmpregadoModule';
import { SistemaRepository } from './../sistema/SistemaRepository';
import { SistemaRepositoryORM } from './../sistema/SistemaRepositoryORM';
import { AlocacaoPipeAlterar } from './AlocacaoPipeAlterar';
import { AlocacaoPipeInserir } from './AlocacaoPipeInserir';
import { AlocacaoPipeRateio } from './AlocacaoPipeRateio';
import { AlocacaoRateioRepository } from './AlocacaoRateioRepository';
import { AlocacaoRateioRepositoryORM } from './AlocacaoRateioRepositoryORM';
import { AlocacaoRateioREST } from './AlocacaoRateioREST';
import { AlocacaoRateioService } from './AlocacaoRateioService';
import { AlocacaoRepository } from './AlocacaoRepository';
import { AlocacaoRepositoryORM } from './AlocacaoRepositoryORM';
import { AlocacaoREST } from './AlocacaoREST';
import { AlocacaoService } from './AlocacaoService';

@Module({
  controllers: [AlocacaoREST, AlocacaoRateioREST],
  exports: [AlocacaoService, AlocacaoRepository, AlocacaoRateioService, AlocacaoRateioRepository],
  imports: [
    TypeOrmModule.forFeature([AlocacaoRepositoryORM, AlocacaoRateioRepositoryORM, DominioRepositoryORM, SistemaRepositoryORM]),
    CommonModule,
    EmpregadoModule,
  ],
  providers: [
    AlocacaoPipeInserir,
    AlocacaoPipeAlterar,
    AlocacaoPipeRateio,
    AlocacaoService,
    AlocacaoRepository,
    AlocacaoRateioService,
    AlocacaoRateioRepository,
    DominioRepository,
    SistemaRepository,
  ],
})
export class AlocacaoModule {}
