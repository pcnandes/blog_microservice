import { ArgumentMetadata, BadRequestException, Injectable, NotFoundException, PipeTransform } from '@nestjs/common';
import { validate } from 'class-validator';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoRepository } from './AlocacaoRepository';

@Injectable()
export class AlocacaoPipeAlterar implements PipeTransform<any, Promise<Alocacao>> {
  constructor(protected readonly repositoryAlocacao: AlocacaoRepository) {}

  public async transform(value: any, metadata?: ArgumentMetadata): Promise<Alocacao> {
    if (!value.id) {
      throw new NotFoundException('Alocação não encontrada');
    }
    const alocacoesDoEmpregado = await this.buscarAlocacoesDoEmpregado(value.empregado?.cpf);
    const existente = this.buscarAlocacao(value.id, alocacoesDoEmpregado);
    const registro = Alocacao.build({
      id: existente.id,
      sistema: existente.sistema,
      empregado: value.empregado,
      percentual: value.percentual,
      construcao: value.construcao,
      sustentacao: value.sustentacao,
      rateioID: null,
    });
    await this.validarAlocacao(registro);
    await this.validarPercentualTotal(registro, ...alocacoesDoEmpregado.filter(a => a.id !== existente.id));
    return registro;
  }

  private buscarAlocacao(id: string, alocacoes: Alocacao[]): Alocacao {
    const existente = alocacoes.filter(aloc => aloc.id === id).pop();
    if (!existente) {
      throw new NotFoundException('Alocação não encontrada');
    }
    if (existente.rateioID) {
      throw new BadRequestException('Alocações por rateio não podem ser alteradas');
    }
    return existente;
  }

  protected async buscarAlocacoesDoEmpregado(cpf: string): Promise<Alocacao[]> {
    if (!cpf) {
      throw new BadRequestException('CPF não informado');
    }
    return this.repositoryAlocacao.findManyByEmpregado(
      cpf,
      'id-empregado.cpf-rateioID-sistema.(id-linhaNegocio-subdominio.dominio.(id-categoria))-percentual',
    );
  }

  protected async validarAlocacao(alocacao: Alocacao): Promise<void> {
    const errors = await validate(alocacao);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
    if (alocacao.totalSubProcesso < 100) {
      throw new BadRequestException('Construção + Sustentação devem somar 100%');
    }
  }

  protected async validarPercentualTotal(...alocacoes: Alocacao[]): Promise<void> {
    const total = alocacoes.reduce((soma, aloc) => soma + aloc.percentual, 0);
    if (total > 100) {
      throw new BadRequestException('O total alocado ultrapassa os 100%');
    }
  }
}
