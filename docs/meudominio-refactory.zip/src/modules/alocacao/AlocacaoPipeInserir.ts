import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { Empregado } from '../empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../empregado/EmpregadoRepository';
import { SistemaRepository } from '../sistema/SistemaRepository';
import { Sistema } from './../sistema/SistemaEntity';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoPipeAlterar } from './AlocacaoPipeAlterar';
import { AlocacaoRateioRepository } from './AlocacaoRateioRepository';
import { AlocacaoRepository } from './AlocacaoRepository';

@Injectable()
export class AlocacaoPipeInserir extends AlocacaoPipeAlterar implements PipeTransform<any, Promise<Alocacao>> {
  constructor(
    repositoryAlocacao: AlocacaoRepository,
    protected readonly repositoryRateio: AlocacaoRateioRepository,
    protected readonly repositoryEmpregado: EmpregadoRepository,
    protected readonly repositorySistema: SistemaRepository,
  ) {
    super(repositoryAlocacao);
  }

  public async transform(value: any, metadata?: ArgumentMetadata): Promise<Alocacao> {
    const empregado = await this.buscarEmpregado(value.empregado?.cpf);
    await this.verificarRateioExistente(empregado);
    const sistema = await this.buscarSistema(value.sistema?.id);
    const alocacoesDoEmpregado = await super.buscarAlocacoesDoEmpregado(empregado.cpf);
    this.verificarAlocacaoExistente(empregado, sistema, alocacoesDoEmpregado);
    const registro = Alocacao.build({
      sistema,
      empregado,
      percentual: value.percentual,
      construcao: value.construcao,
      sustentacao: value.sustentacao,
      rateioID: null,
      id: null,
    });
    await this.validarAlocacao(registro);
    await this.validarPercentualTotal(registro, ...alocacoesDoEmpregado);
    return registro;
  }

  protected async buscarEmpregado(cpf: string): Promise<Empregado> {
    if (!cpf) {
      throw new BadRequestException('CPF não informado');
    }
    const empregado = await this.repositoryEmpregado.findOneByCPF(cpf, '*');
    if (!empregado) {
      throw new BadRequestException('Empregado não encontrado');
    }
    if (!empregado.isAlocavel || empregado.isCOADM) {
      throw new BadRequestException('Este empregado não pode ser alocado');
    }
    return empregado;
  }

  protected async buscarSistema(id: string): Promise<Sistema> {
    if (!id) {
      return null;
    }
    const sistema = await this.repositorySistema.findOneById(id, 'id-identificador-linhaNegocio-subdominio.dominio.(id-categoria)');
    if (!sistema) {
      throw new BadRequestException('Sistema não encontrado');
    }
    return sistema;
  }

  protected async verificarRateioExistente(empregado: Empregado): Promise<void> {
    const rateio = await this.repositoryRateio.findOneByEmpregado(empregado.cpf, 'id');
    if (!!rateio) {
      throw new BadRequestException('Não é permitido incluir alocação para empregado com rateio de alocação');
    }
  }

  protected verificarAlocacaoExistente(empregado: Empregado, sistema: Sistema, alocacoes: Alocacao[]) {
    if (alocacoes.some(aloc => aloc.empregado.cpf === empregado.cpf && aloc.sistema?.id === sistema?.id)) {
      throw new BadRequestException(
        'Já existe alocação para este empregado ' + (sistema ? `no sistema ${sistema.identificador}` : 'em suporte'),
      );
    }
  }
}
