import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { Empregado } from '../empregado/EmpregadoEntity';
import { EmpregadoRepository } from './../empregado/EmpregadoRepository';
import { AlocacaoRateio } from './AlocacaoRateioEntity';
import { AlocacaoRateioRepository } from './AlocacaoRateioRepository';

@Injectable()
export class AlocacaoPipeRateio implements PipeTransform<any, Promise<AlocacaoRateio>> {
  constructor(protected readonly repositoryRateio: AlocacaoRateioRepository, protected readonly repositoryEmpregado: EmpregadoRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<AlocacaoRateio> {
    if (!value.empregado?.cpf) {
      throw new BadRequestException('CPF não informado');
    }
    const existente = await this.repositoryRateio.findOneByEmpregado(value.empregado.cpf, '*-empregado.cpf');
    const empregado = existente ? existente.empregado : await this.buscarEmpregado(value.empregado.cpf);
    if (!existente && !value.escopo?.length) {
      throw new BadRequestException('O escopo do rateio está vazio');
    }
    return new AlocacaoRateio({
      escopo: value.escopo,
      id: existente?.id,
      empregado,
      versao: value.versao,
    });
  }

  protected async buscarEmpregado(cpf: string): Promise<Empregado> {
    const empregado = await this.repositoryEmpregado.findOneByCPF(cpf, '*');
    if (!empregado) {
      throw new BadRequestException('Empregado não encontrado');
    }
    if (!empregado.isAlocavel || empregado.isCOADM) {
      throw new BadRequestException('Este empregado não pode ser alocado');
    }
    return empregado;
  }
}
