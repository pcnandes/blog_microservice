import { ApiProperty } from '@nestjs/swagger';

class DominioDTO {
  @ApiProperty()
  public readonly codigo: number;
  @ApiProperty()
  public readonly nome: string;
}

export class AlocacaoPorDominio {
  @ApiProperty()
  public readonly dominio: DominioDTO;
  @ApiProperty()
  public readonly quantidade: number;
  @ApiProperty()
  public readonly percentual: number;
  @ApiProperty()
  public readonly construcao: number;
  @ApiProperty()
  public readonly sustentacao: number;
  @ApiProperty()
  public readonly produto: number;
}
