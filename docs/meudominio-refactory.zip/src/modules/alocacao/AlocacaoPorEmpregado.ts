import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

class EmpregadoDTO {
  @ApiProperty()
  public readonly matricula: number;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly lotacao: string;
  @ApiProperty()
  public readonly funcaoConfianca: string;
}

export class AlocacaoPorEmpregado {
  @ApiProperty()
  public readonly empregado: EmpregadoDTO;
  @ApiProperty()
  public readonly percentual: number;
  @ApiProperty()
  public readonly construcao: number;
  @ApiProperty()
  public readonly sustentacao: number;
  @ApiProperty()
  public readonly produto: number;
  @ApiPropertyOptional()
  public readonly suporte?: number;
  @ApiPropertyOptional()
  public readonly gestao?: number;
  @ApiPropertyOptional()
  public readonly administrativo?: number;
  @ApiPropertyOptional()
  public readonly rateada?: boolean;
}
