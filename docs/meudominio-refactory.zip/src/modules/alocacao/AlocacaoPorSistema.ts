import { LinhaNegocio } from './../sistema/LinhaNegocio';
import { ApiProperty } from '@nestjs/swagger';

class SistemaDTO {
  @ApiProperty()
  public readonly identificador: string;
  @ApiProperty()
  public readonly nome: string;
  @ApiProperty()
  public readonly linhaNegocio: LinhaNegocio;
  @ApiProperty()
  public readonly codigoServico: number;
}

export class AlocacaoPorSistema {
  @ApiProperty()
  public readonly sistema: SistemaDTO;
  @ApiProperty()
  public readonly quantidade: number;
  @ApiProperty()
  public readonly percentual: number;
  @ApiProperty()
  public readonly construcao: number;
  @ApiProperty()
  public readonly sustentacao: number;
  @ApiProperty()
  public readonly produto: number;
}
