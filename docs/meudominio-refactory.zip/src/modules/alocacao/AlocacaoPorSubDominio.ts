import { ApiProperty } from '@nestjs/swagger';

class SubDominioDTO {
  @ApiProperty()
  public readonly codigo: number;
  @ApiProperty()
  public readonly nome: string;
}

export class AlocacaoPorSubDominio {
  @ApiProperty()
  public readonly subdominio: SubDominioDTO;
  @ApiProperty()
  public readonly quantidade: number;
  @ApiProperty()
  public readonly percentual: number;
  @ApiProperty()
  public readonly construcao: number;
  @ApiProperty()
  public readonly sustentacao: number;
  @ApiProperty()
  public readonly produto: number;
}
