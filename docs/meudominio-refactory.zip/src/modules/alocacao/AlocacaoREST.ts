import { BadRequestException, Body, Controller, Delete, Get, Param, Post, Put, Query, Res, NotFoundException } from '@nestjs/common';
import { ApiBearerAuth, ApiBody, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { Output } from '../../common/output/Output';
import { OutputJSON } from '../../common/output/OutputJSON';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Page } from '../../common/repository/Page';
import { ObjectPipe } from './../../common/pipes/ObjectPipe';
import { Pageable } from './../../common/repository/Pageable';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoPipeAlterar } from './AlocacaoPipeAlterar';
import { AlocacaoPipeInserir } from './AlocacaoPipeInserir';
import { AlocacaoPorDominio } from './AlocacaoPorDominio';
import { AlocacaoPorEmpregado } from './AlocacaoPorEmpregado';
import { AlocacaoPorSistema } from './AlocacaoPorSistema';
import { AlocacaoPorSubDominio } from './AlocacaoPorSubDominio';
import { AlocacaoRateioService } from './AlocacaoRateioService';
import { AlocacaoService } from './AlocacaoService';
import { AlocacaoAgrupadaFilter } from './AlocacaoAgrupadaFilter';
import { PageablePipe } from '../../common/pipes/PageablePipe';

class PageOfAlocacaoPorEmpregado extends Page<AlocacaoPorEmpregado> {}

@Controller('alocacao')
@ApiTags('Alocação')
@ApiBearerAuth()
export class AlocacaoREST {
  constructor(private readonly serviceAlocacao: AlocacaoService, private readonly serviceRateio: AlocacaoRateioService) {}

  @Get(':id')
  @ApiOperation({ summary: 'Obtém as informações de uma alocação' })
  @ApiParam({ name: 'id', description: 'ID da alocação', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = empregado.nome-percentual', required: false })
  @ApiResponse({ status: 200, type: Alocacao, description: 'Dados da alocação' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Alocação não encontrada' })
  @ApiProduces('application/json')
  public async buscarPorID(@Param('id') id: string, @Query('fields') fields: string = '*'): Promise<Alocacao> {
    return this.serviceAlocacao.findOneById(id, fields);
  }

  @Get('sistema/:id')
  @ApiOperation({ summary: 'Obtém as alocações de um sistema' })
  @ApiParam({ name: 'id', description: 'ID do sistema', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = empregado.nome-percentual', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiResponse({ status: 200, type: Alocacao, isArray: true, description: 'Dados do sistema' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async buscarPorSistema(
    @Res() response: Response,
    @Param('sistema') id: string,
    @Query('fields') fields: string = '*',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
  ) {
    output.ofList(response, await this.serviceAlocacao.findManyBySistema(id, fields));
  }

  @Get('empregado/:cpf')
  @ApiOperation({ summary: 'Obtém as alocações de um empregado' })
  @ApiParam({ name: 'cpf', description: 'CPF do empregado', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = sistema.identificador-percentual', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiResponse({ status: 200, type: Alocacao, isArray: true, description: 'Alocações' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async buscarPorEmpregado(
    @Res() response: Response,
    @Param('cpf') cpf: string,
    @Query('fields') fields: string = '*',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
  ) {
    output.ofList(response, await this.serviceAlocacao.findManyByEmpregado(cpf, fields));
  }

  @Transactional()
  @Post()
  @ApiOperation({ summary: 'Inclui uma nova alocação' })
  @ApiBody({ type: Alocacao })
  @ApiResponse({ status: 201, type: String, description: 'Alocação criada com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiProduces('text/plain')
  public async incluir(@Body(AlocacaoPipeInserir) alocacao: Alocacao): Promise<string> {
    return this.serviceAlocacao.incluir(alocacao);
  }

  @Transactional()
  @Put()
  @ApiOperation({ summary: 'Altera uma alocação existente' })
  @ApiBody({ type: Alocacao })
  @ApiResponse({ status: 204, description: 'Alocação alterada com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiResponse({ status: 404, description: 'Alocação não encontrada' })
  @ApiProduces('text/plain')
  public async alterar(@Body(AlocacaoPipeAlterar) alocacao: Alocacao): Promise<void> {
    return this.serviceAlocacao.alterar(alocacao);
  }

  @Transactional()
  @Delete(':id')
  @ApiOperation({ summary: 'Exclui uma alocação' })
  @ApiParam({ name: 'id', description: 'ID da alocação', required: true })
  @ApiResponse({ status: 204, description: 'Alocação excluída com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiResponse({ status: 404, description: 'Alocação não encontrada' })
  @ApiProduces('text/plain')
  public async excluirPorId(@Param('id') id: string): Promise<void> {
    return this.serviceAlocacao.excluirPorID(id);
  }

  @Transactional()
  @Delete('empregado/:cpf')
  @ApiOperation({ summary: 'Excluir todas as alocações e rateios de um empregado' })
  @ApiParam({ name: 'cpf', description: 'CPF do empregado', required: true })
  @ApiResponse({ status: 204, description: 'Alocação excluída com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiProduces('text/plain')
  public async excluirPorCPF(@Param('cpf') cpf: string): Promise<void> {
    try {
      const rateio = await this.serviceRateio.findOneByEmpregado(cpf, 'id');
      await this.serviceRateio.excluir(rateio.id);
    } catch (err) {
      if (err instanceof NotFoundException) {
        await this.serviceAlocacao.excluirPorEmpregado(cpf);
      }
    }
  }

  @Get('total/empregado/:cpf')
  @ApiOperation({ summary: 'Obtém o total alocado por um empregado' })
  @ApiParam({ name: 'cpf', description: 'CPF do empregado', required: true })
  @ApiResponse({ status: 200, type: AlocacaoPorEmpregado })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Empregado não encontrado' })
  @ApiProduces('application/json')
  public async totalDoEmpregado(@Param('cpf') cpf: string): Promise<AlocacaoPorEmpregado> {
    return this.serviceAlocacao.totalDoEmpregado(cpf);
  }

  @Get('total/empregado')
  @ApiOperation({ summary: 'Obtém o total alocado por empregado [PAGINADO]' })
  @ApiQuery({ name: 'page', description: 'Número da página, começando em 1. Padrão = 1', required: false })
  @ApiQuery({ name: 'size', description: 'Items por página. Padrão = 10', required: false })
  @ApiQuery({ name: 'sort', description: 'Ordenação', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'lotacao', description: 'Filtra por lotação', required: false })
  @ApiQuery({ name: 'dominio', description: 'ID ou Código do Domínio', required: false })
  @ApiQuery({ name: 'subdominio', description: 'ID ou Código do SubDomínio', required: false })
  @ApiQuery({ name: 'sistema', description: 'ID ou Identificador do Sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Código de Serviço. Pode ser passado mais de um separado por hífen', required: false })
  @ApiResponse({ status: 200, type: PageOfAlocacaoPorEmpregado })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async groupByEmpregado(
    @Res() response: Response,
    @Query(ObjectPipe) filtro: AlocacaoAgrupadaFilter,
    @Query(PageablePipe) pageable: Pageable,
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
  ) {
    output.ofPage(response, await this.serviceAlocacao.groupByEmpregado(pageable, filtro));
  }

  @Get('total/dominio')
  @ApiOperation({ summary: 'Obtém o total alocado por domínio' })
  @ApiQuery({ name: 'lotacao', description: 'Filtra por lotação', required: false })
  @ApiQuery({ name: 'dominio', description: 'ID ou Código do Domínio', required: false })
  @ApiQuery({ name: 'subdominio', description: 'ID ou Código do SubDomínio', required: false })
  @ApiQuery({ name: 'sistema', description: 'ID ou Identificador do Sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Código de Serviço. Pode ser passado mais de um separado por hífen', required: false })
  @ApiResponse({ status: 200, type: AlocacaoPorDominio, isArray: true })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json')
  public async groupByDominio(@Query(ObjectPipe) filtro: AlocacaoAgrupadaFilter): Promise<AlocacaoPorDominio[]> {
    return this.serviceAlocacao.groupByDominio(filtro);
  }

  @Get('total/subdominio')
  @ApiOperation({ summary: 'Obtém o total alocado por subdomínio' })
  @ApiQuery({ name: 'lotacao', description: 'Filtra por lotação', required: false })
  @ApiQuery({ name: 'dominio', description: 'ID ou Código do Domínio', required: false })
  @ApiQuery({ name: 'subdominio', description: 'ID ou Código do SubDomínio', required: false })
  @ApiQuery({ name: 'sistema', description: 'ID ou Identificador do Sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Código de Serviço. Pode ser passado mais de um separado por hífen', required: false })
  @ApiResponse({ status: 200, type: AlocacaoPorSubDominio, isArray: true })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json')
  public async groupBySubDominio(@Query(ObjectPipe) filtro: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSubDominio[]> {
    return this.serviceAlocacao.groupBySubDominio(filtro);
  }

  @Get('total/sistema')
  @ApiOperation({ summary: 'Obtém o total alocado por sistema' })
  @ApiQuery({ name: 'lotacao', description: 'Filtra por lotação', required: false })
  @ApiQuery({ name: 'dominio', description: 'ID ou Código do Domínio', required: false })
  @ApiQuery({ name: 'subdominio', description: 'ID ou Código do SubDomínio', required: false })
  @ApiQuery({ name: 'sistema', description: 'ID ou Identificador do Sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Código de Serviço. Pode ser passado mais de um separado por hífen', required: false })
  @ApiResponse({ status: 200, type: AlocacaoPorSistema, isArray: true })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json')
  public async groupBySistema(@Query(ObjectPipe) filtro: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSistema[]> {
    return this.serviceAlocacao.groupBySistema(filtro);
  }
}
