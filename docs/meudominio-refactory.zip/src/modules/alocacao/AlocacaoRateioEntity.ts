import { SubDominio } from './../subdominio/SubDominioEntity';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsNotEmpty } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Empregado } from '../empregado/EmpregadoEntity';
import { Sistema } from '../sistema/SistemaEntity';
import { Dominio } from '../dominio/DominioEntity';

@Entity()
export class AlocacaoRateio {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  public readonly id?: string;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'empregado', referencedColumnName: 'cpf' })
  @ApiProperty({ type: () => Empregado })
  @IsNotEmpty()
  public readonly empregado?: Empregado;

  @Column({ name: 'escopo', type: 'character varying', array: true })
  @ApiPropertyOptional()
  @IsNotEmpty()
  public readonly escopo?: string[];

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  constructor(example: Example<AlocacaoRateio> = {}) {
    this.id = example?.id;
    this.empregado = example?.empregado ? new Empregado(example.empregado) : undefined;
    this.escopo = example?.escopo;
    this.versao = example?.versao;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public incluiSistema(sistema: Sistema): boolean {
    if (!sistema?.subdominio) {
      throw new Error('[Sistema].subdominio não carregado');
    }
    return this.incluiSubDominio(sistema.subdominio);
  }

  public incluiSubDominio(subdominio: SubDominio): boolean {
    if (!subdominio?.codigo) {
      throw new Error('[SubDominio].codigo não carregado');
    }
    return this.escopo.includes(subdominio.codigo) || this.incluiDominio(subdominio.dominio);
  }

  public incluiDominio(dominio: Dominio): boolean {
    if (!dominio?.codigo) {
      throw new Error('[Dominio].codigo não carregado');
    }
    if (!dominio?.ugDominio) {
      throw new Error('[Dominio].ugDominio não carregado');
    }
    return this.escopo.includes(dominio.codigo) || this.escopo.includes(dominio.ugDominio);
  }
}
