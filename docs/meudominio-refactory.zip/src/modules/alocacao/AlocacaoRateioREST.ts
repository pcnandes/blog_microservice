import { Controller, Get, Param, Query, Put, Body } from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiOperation, ApiParam, ApiQuery, ApiResponse, ApiProduces, ApiBody } from '@nestjs/swagger';
import { AlocacaoRateioService } from './AlocacaoRateioService';
import { AlocacaoRateio } from './AlocacaoRateioEntity';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { AlocacaoPipeRateio } from './AlocacaoPipeRateio';

@Controller('alocacao/rateio')
@ApiTags('Rateio de Alocação')
@ApiBearerAuth()
export class AlocacaoRateioREST {
  constructor(private readonly serviceRateio: AlocacaoRateioService) {}

  @Get(':cpf')
  @ApiOperation({ summary: 'Obtém as informações de um rateio de alocação' })
  @ApiParam({ name: 'cpf', description: 'CPF do empregado', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *-empregado.cpf', required: false })
  @ApiResponse({ status: 200, type: AlocacaoRateio, description: 'Dados da alocação' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Rateio não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorID(@Param('cpf') cpf: string, @Query('fields') fields: string = '*-empregado.cpf'): Promise<AlocacaoRateio> {
    return this.serviceRateio.findOneByEmpregado(cpf, fields);
  }

  @Transactional()
  @Put()
  @ApiOperation({ summary: 'Aplica um rateio de alocação' })
  @ApiBody({ type: AlocacaoRateio })
  @ApiResponse({ status: 204, description: 'Alocação alterada com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiProduces('text/plain')
  public async alterar(@Body(AlocacaoPipeRateio) rateio: AlocacaoRateio): Promise<void> {
    if (rateio.id) {
      await this.serviceRateio.alterar(rateio);
    } else {
      await this.serviceRateio.incluir(rateio);
    }
  }
}
