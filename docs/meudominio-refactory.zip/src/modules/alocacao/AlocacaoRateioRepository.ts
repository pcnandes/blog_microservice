import { Injectable } from '@nestjs/common';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { AlocacaoRateio } from './AlocacaoRateioEntity';
import { AlocacaoRateioRepositoryORM } from './AlocacaoRateioRepositoryORM';

@Injectable()
export class AlocacaoRateioRepository extends RepositoryAuditable<AlocacaoRateio> {
  constructor(repository: AlocacaoRateioRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findOneByEmpregado(empregado: string | number, fields: string = '*'): Promise<AlocacaoRateio> {
    const atributo = typeof empregado === 'number' || empregado.match(/^[0-9]{1,8}$/) ? 'matricula' : 'cpf';
    const param = atributo === 'cpf' ? empregado : parseInt(empregado.toString(), 10);
    return this.findOne(fields, where => {
      where.andWhere(`alocacaorateio_empregado.${atributo} = :param`, { param });
      where.addJoin('empregado');
    });
  }

  public async findManyByEscopo(escopo: string[], fields: string = '*'): Promise<AlocacaoRateio[]> {
    return this.findAll(fields, where => {
      where.andWhere('alocacaorateio.escopo && CAST(:escopo AS CHARACTER VARYING[])', { escopo: `{${escopo.join(',')}}` });
    });
  }
}
