import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { AlocacaoRateio } from './AlocacaoRateioEntity';

@EntityRepository(AlocacaoRateio)
export class AlocacaoRateioRepositoryORM extends BaseRepository<AlocacaoRateio> {}
