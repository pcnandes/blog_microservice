import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { SecurityContext } from '../../common/security/SecurityContext';
import { DominioRepository } from '../dominio/DominioRepository';
import { Sistema } from '../sistema/SistemaEntity';
import { SistemaRepository } from '../sistema/SistemaRepository';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoRateio } from './AlocacaoRateioEntity';
import { AlocacaoRateioRepository } from './AlocacaoRateioRepository';
import { AlocacaoRepository } from './AlocacaoRepository';

@Injectable()
export class AlocacaoRateioService {
  constructor(
    private readonly security: SecurityContext,
    private readonly repositoryRateio: AlocacaoRateioRepository,
    private readonly repositoryAlocacao: AlocacaoRepository,
    private readonly repositoryDominio: DominioRepository,
    private readonly repositorySistema: SistemaRepository,
  ) {}

  public async atualizarPorEscopo(...escopo: string[]): Promise<void> {
    const rateios = await this.repositoryRateio.findManyByEscopo(escopo, '*-empregado.cpf');
    await this.executar(...rateios);
  }

  public async incluir(registro: AlocacaoRateio): Promise<string> {
    await this.verificarPermissaoEscopo(registro.escopo.concat(registro.escopo));
    const id = await this.repositoryRateio.insert(registro);
    await this.executar(new AlocacaoRateio({ ...registro, id }));
    return id;
  }

  public async alterar(registro: AlocacaoRateio): Promise<void> {
    if (!registro.escopo?.length) {
      return this.excluir(registro.id);
    }
    const antigo = await this.repositoryRateio.findOneById(registro.id, 'id-escopo');
    await this.verificarPermissaoEscopo(registro.escopo.concat(antigo.escopo));
    await this.repositoryRateio.update(registro);
    await this.executar(registro);
  }

  public async excluir(rateioID: string): Promise<void> {
    const alocacoes = await this.repositoryAlocacao.findManyByRateio(rateioID, 'id-sistema.subdominio.dominio.(id-nome)');
    this.verificarPermissaoAlocacao(alocacoes);
    await this.repositoryAlocacao.deleteAll(...alocacoes.map(a => a.id));
    return this.repositoryRateio.delete(rateioID);
  }

  public async findOneByEmpregado(cpf: string, fields: string = '*'): Promise<AlocacaoRateio> {
    const rateio = await this.repositoryRateio.findOneByEmpregado(cpf, fields);
    if (!rateio) {
      throw new NotFoundException();
    }
    return rateio;
  }

  private async verificarPermissaoEscopo(escopo: string[]): Promise<void> {
    escopo = [...new Set(escopo.map(item => /^([^-]+)(?:-[0-9]{3}){0,1}$/.exec(item)[1]))];
    const dominios = await this.repositoryDominio.findAll('id-codigo-ugDominio-nome');
    const afetados = dominios.filter(dom => escopo.includes(dom.ugDominio) || escopo.includes(dom.codigo));
    const usuario = this.security.getRequestUser();
    afetados.forEach(dom => {
      if (!usuario.podeAlocarDominio(dom.id)) {
        throw new ForbiddenException(`Você não tem permissão de alocar no domínio ${dom.nome}`);
      }
    });
  }

  private verificarPermissaoAlocacao(alocacoes: Alocacao[]) {
    const usuario = this.security.getRequestUser();
    alocacoes.forEach(alc => {
      if (alc.possuiSistema && !usuario.podeAlocarDominio(alc.dominioID)) {
        throw new ForbiddenException(`Você não tem permissão de remover alocações do domínio ${alc.dominio.nome}`);
      }
      if (!alc.possuiSistema && !usuario.podeAlocarSuporte) {
        throw new ForbiddenException(`Você não tem permissão de remover alocações em suporte`);
      }
    });
  }

  private async executar(...registros: AlocacaoRateio[]): Promise<void> {
    await this.removerAlocacoesEmpregado(...new Set(registros.map(rateio => rateio.empregado.cpf)));
    const sistemas = await this.repositorySistema.findAll('id-linhaNegocio-subdominio.(codigo-dominio.(codigo-ugDominio-categoria))');
    const alocacoes = registros.reduce((alc, rat) => alc.concat(this.gerarAlocacoes(rat, sistemas)), []);
    await this.repositoryAlocacao.insertAll(...alocacoes);
  }

  private gerarAlocacoes(rateio: AlocacaoRateio, sistemas: Sistema[]): Alocacao[] {
    const afetados = sistemas.filter(sis => rateio.incluiSistema(sis));
    if (afetados.length === 0) {
      return [];
    }
    const percent = Math.floor(1000 / afetados.length);
    const residuo = 1000 - percent * afetados.length;
    return afetados.map((sis, idx) =>
      Alocacao.build({
        id: null,
        rateioID: rateio.id,
        sistema: sis,
        empregado: rateio.empregado,
        percentual: (percent + (idx < residuo ? 1 : 0)) / 10.0,
        construcao: 0.0,
        sustentacao: 100.0,
      }),
    );
  }

  private async removerAlocacoesEmpregado(...cpf: string[]): Promise<void> {
    if (cpf.length === 0) {
      return;
    }
    if (cpf.some(i => !(i || '').match(/^[0-9]{11}$/))) {
      throw new Error('CPF inválido');
    }
    const alocacoesAnteriores = await this.repositoryAlocacao.findManyByEmpregado(cpf, 'id-sistema.subdominio.dominio.(id-nome)');
    this.verificarPermissaoAlocacao(alocacoesAnteriores);
    await this.repositoryAlocacao.deleteAll(...alocacoesAnteriores.map(alc => alc.id));
  }
}
