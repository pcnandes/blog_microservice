import { Injectable } from '@nestjs/common';
import { isUUID } from '@nestjs/common/utils/is-uuid';
import { get, set } from 'lodash';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';
import { Page } from '../../common/repository/Page';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { Historico } from '../historico/HistoricoEntity';
import { Pageable } from './../../common/repository/Pageable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { AlocacaoBaseline } from './AlocacaoBaseline';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoPorDominio } from './AlocacaoPorDominio';
import { AlocacaoPorEmpregado } from './AlocacaoPorEmpregado';
import { AlocacaoPorSistema } from './AlocacaoPorSistema';
import { AlocacaoPorSubDominio } from './AlocacaoPorSubDominio';
import { AlocacaoRepositoryORM } from './AlocacaoRepositoryORM';
import { AlocacaoAgrupadaFilter } from './AlocacaoAgrupadaFilter';

const SQL_SLCT_EMPR =
  'emp.matricula AS "empregado.matricula", emp.nome AS "empregado.nome", emp.lotacao AS "empregado.lotacao", emp.funcao_confianca AS "empregado.funcaoConfianca", rat.id IS NOT NULL as "rateada"';
const SQL_GRUP_EMPR = 'emp.matricula, emp.nome, emp.lotacao, emp.funcao_confianca, rat.id';
const SQL_CONT_EMPR = ', COUNT(DISTINCT emp.cpf)::INTEGER AS "quantidade"';
const SQL_SOMA_PERC = ', COALESCE(SUM(alc.percentual),0)::DOUBLE PRECISION AS "percentual"';
const SQL_SOMA_CONS = ', COALESCE(SUM(alc.percentual * 0.01 * alc.construcao),0)::DOUBLE PRECISION AS "construcao"';
const SQL_SOMA_SUST = ', COALESCE(SUM(alc.percentual * 0.01 * alc.sustentacao),0)::DOUBLE PRECISION AS "sustentacao"';
const SQL_SOMA_PROD = ', COALESCE(SUM(alc.percentual * 0.01 * alc.produto),0)::DOUBLE PRECISION AS "produto"';
const SQL_SOMA_SUPR = ', COALESCE(SUM(alc.percentual * 0.01 * alc.suporte),0)::DOUBLE PRECISION AS "suporte"';
const SQL_SOMA_GEST = ', COALESCE(SUM(alc.percentual * 0.01 * alc.gestao),0)::DOUBLE PRECISION AS "gestao"';
const SQL_SOMA_ADMN = ', COALESCE(SUM(alc.percentual * 0.01 * alc.administrativo),0)::DOUBLE PRECISION AS "administrativo"';
const SQL_ALOC_SIST = `${SQL_SOMA_PERC}${SQL_SOMA_CONS}${SQL_SOMA_SUST}${SQL_SOMA_PROD}`;
const SQL_ALOC_OUTR = `${SQL_SOMA_SUPR}${SQL_SOMA_GEST}${SQL_SOMA_ADMN}`;
const SQL_FROM = `FROM empregado emp LEFT JOIN alocacao alc ON emp.cpf=alc.empregado
  LEFT JOIN alocacao_rateio rat ON rat.empregado=emp.cpf
  LEFT JOIN sistema sis ON sis.id=alc.sistema
  LEFT JOIN subdominio sub ON sub.id=sis.subdominio
  LEFT JOIN dominio dom ON dom.id=sub.dominio
  LEFT JOIN sistema_servico srv ON srv.sistema=sis.id AND srv.principal=true
`;
const SQL_WHERE = `WHERE emp.lotacao LIKE 'DIDES/%' AND emp.data_desligamento IS NULL AND COALESCE(emp.funcao_confianca,'') NOT IN ('SUPERINTENDENTE','ASSESSOR DIRETORIA II')`;

@Injectable()
export class AlocacaoRepository extends RepositoryAuditable<Alocacao> {
  constructor(repository: AlocacaoRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  protected construirHistorico(id: string, before?: QueryDeepPartialEntity<Alocacao>, after?: QueryDeepPartialEntity<Alocacao>): Historico {
    // alocações por rateio não geram histórico
    if (!!get(before, 'rateioID') || !!get(after, 'rateioID')) {
      return null;
    }
    return super.construirHistorico(id, before, after);
  }

  public async findManyBySistema(sistemaID: string | string[], fields = 'id'): Promise<Alocacao[]> {
    return this.findAll(fields, where => {
      const arg = { sistemaID: Array.isArray(sistemaID) ? sistemaID : [sistemaID] };
      where.andWhere('alocacao_sistema.id IN (:...sistemaID)', arg);
      where.addJoin('sistema');
    });
  }

  public async findManyByEmpregado(empregado: string | string[] | number | number[], fields = 'id'): Promise<Alocacao[]> {
    if (!empregado) {
      return [];
    }
    const arr = Array.isArray(empregado) ? empregado : [empregado];
    if (arr.length === 0) {
      return [];
    }
    const att = typeof arr[0] === 'number' || arr[0].match(/^[0-9]{1,8}$/) ? 'matricula' : 'cpf';
    const arg = att === 'cpf' ? arr : arr.map(i => parseInt(i.toString(), 10));
    return this.findAll(fields, where => {
      where.andWhere(`alocacao_empregado.${att} IN (:...arg)`, { arg });
      where.addJoin('empregado');
    });
  }

  public async findManyByRateio(rateioID: string | string[], fields = 'id'): Promise<Alocacao[]> {
    const arg = { rateioID: Array.isArray(rateioID) ? rateioID : [rateioID] };
    return this.findAll(fields, where => {
      where.andWhere('alocacao.rateioID IN (:...rateioID)', arg);
    });
  }

  public async totalDoEmpregado(empregado: string | number): Promise<AlocacaoPorEmpregado> {
    const atributo = typeof empregado === 'number' || empregado.match(/^[0-9]{1,8}$/) ? 'matricula' : 'cpf';
    const param = atributo === 'cpf' ? empregado : parseInt(empregado.toString(), 10);
    const result = await this.querySQL(
      `
      SELECT ${SQL_SLCT_EMPR}${SQL_ALOC_SIST}${SQL_ALOC_OUTR}
      ${SQL_FROM}
      ${SQL_WHERE} AND emp.${atributo} = $1
      GROUP BY ${SQL_GRUP_EMPR}
    `,
      [param],
    );
    return result[0];
  }

  public async groupByEmpregado(pageable: Pageable, filtro?: AlocacaoAgrupadaFilter): Promise<Page<AlocacaoPorEmpregado>> {
    const params = filtro?.toSqlParams() || [];
    const where = filtro?.toSqlWhere() || '';
    return this.pagedSQL<AlocacaoPorEmpregado>(
      `
      SELECT ${SQL_SLCT_EMPR}${SQL_ALOC_SIST}${SQL_ALOC_OUTR}
      ${SQL_FROM}
      ${SQL_WHERE}${where}
      GROUP BY ${SQL_GRUP_EMPR}
    `,
      pageable,
      params,
    );
  }

  public async groupByDominio(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorDominio[]> {
    const params = filtro?.toSqlParams() || [];
    const where = filtro?.toSqlWhere() || '';
    return this.querySQL(
      `
      SELECT dom.codigo AS "dominio.codigo"
        ,dom.nome AS "dominio.nome"
        ${SQL_CONT_EMPR}${SQL_ALOC_SIST}${SQL_ALOC_OUTR}
      ${SQL_FROM}
      ${SQL_WHERE} AND dom.codigo IS NOT NULL ${where}
      GROUP BY dom.codigo, dom.nome
      UNION ALL
      SELECT NULL::TEXT AS "dominio.codigo"
        ,NULL::TEXT AS "dominio.nome"
        ${SQL_CONT_EMPR}${SQL_ALOC_SIST}${SQL_ALOC_OUTR}
      ${SQL_FROM}
      ${SQL_WHERE} AND alc.suporte > 0 ${where}
      HAVING COUNT(DISTINCT emp.cpf)>0
      UNION ALL
      SELECT NULL::TEXT AS "dominio.codigo"
        ,NULL::TEXT AS "dominio.nome"
        ${SQL_CONT_EMPR}${SQL_ALOC_SIST}${SQL_ALOC_OUTR}
      ${SQL_FROM}
      ${SQL_WHERE} AND (alc.gestao + alc.administrativo) > 0 ${where}
      HAVING COUNT(DISTINCT emp.cpf)>0
      ORDER BY "dominio.codigo" NULLS LAST
    `,
      params,
    );
  }

  public async groupBySubDominio(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSubDominio[]> {
    const params = filtro?.toSqlParams() || [];
    const where = filtro?.toSqlWhere() || '';
    return this.querySQL(
      `
      SELECT sub.codigo AS "subdominio.codigo"
        ,sub.nome AS "subdominio.nome"
        ${SQL_CONT_EMPR}${SQL_ALOC_SIST}
      ${SQL_FROM}
      ${SQL_WHERE} AND alc.sistema IS NOT NULL ${where}
      GROUP BY sub.codigo, sub.nome
      ORDER BY sub.codigo
    `,
      params,
    );
  }

  public async groupBySistema(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSistema[]> {
    const params = filtro?.toSqlParams() || [];
    const where = filtro?.toSqlWhere() || '';
    return this.querySQL(
      `
      SELECT sis.identificador AS "sistema.identificador"
        ,sis.nome AS "sistema.nome"
        ,sis.linha_negocio AS "sistema.linhaNegocio"
        ,MAX(CASE WHEN srv.principal THEN srv.servico END) AS "sistema.codigoServico"
        ${SQL_CONT_EMPR}${SQL_ALOC_SIST}
      ${SQL_FROM}
      ${SQL_WHERE} AND alc.sistema IS NOT NULL ${where}
      GROUP BY sis.identificador, sis.nome, sis.linha_negocio
      ORDER BY sis.identificador
    `,
      params,
    );
  }

  public async baseline(dia: Date): Promise<AlocacaoBaseline[]> {
    throw new Error('Não implementado ainda');
    return null;
  }

  private async querySQL(sql: string, params?: any[]): Promise<any> {
    const result = await this.repository.query(sql, params);
    return result.map(row => {
      return Object.keys(row).reduce((obj, key) => set(obj, key, row[key]), {});
    });
  }

  private async pagedSQL<T>(sql: string, pageable: Pageable, params?: any[], defaultSort: string = '"empregado.nome"'): Promise<Page<T>> {
    const [totalElements, content] = await Promise.all([
      this.countSQL(sql, params),
      this.querySQL(
        `${sql} ORDER BY ${pageable.sort?.sql || defaultSort} LIMIT ${pageable.pageSize} OFFSET ${pageable.pageOffset}`,
        params,
      ),
    ]);
    return new Page<T>({
      content,
      totalElements,
      pageNumber: pageable.pageNumber,
      pageSize: pageable.pageSize,
    });
  }

  private async countSQL(sql: string, params?: any[]): Promise<number> {
    const [{ count }] = await this.repository.query(`SELECT COUNT(*)::INTEGER AS count FROM (${sql}) X`, params);
    return count;
  }
}
