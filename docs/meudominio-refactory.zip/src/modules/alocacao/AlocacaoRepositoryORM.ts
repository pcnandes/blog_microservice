import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Alocacao } from './AlocacaoEntity';

@EntityRepository(Alocacao)
export class AlocacaoRepositoryORM extends BaseRepository<Alocacao> {}
