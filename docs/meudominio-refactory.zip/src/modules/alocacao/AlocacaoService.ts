import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { set } from 'lodash';
import { Page } from '../../common/repository/Page';
import { SecurityContext } from '../../common/security/SecurityContext';
import { Pageable } from './../../common/repository/Pageable';
import { Sistema } from './../sistema/SistemaEntity';
import { SistemaRepository } from './../sistema/SistemaRepository';
import { Alocacao } from './AlocacaoEntity';
import { AlocacaoPorDominio } from './AlocacaoPorDominio';
import { AlocacaoPorEmpregado } from './AlocacaoPorEmpregado';
import { AlocacaoPorSistema } from './AlocacaoPorSistema';
import { AlocacaoPorSubDominio } from './AlocacaoPorSubDominio';
import { AlocacaoRepository } from './AlocacaoRepository';
import { AlocacaoAgrupadaFilter } from './AlocacaoAgrupadaFilter';

@Injectable()
export class AlocacaoService {
  constructor(
    private readonly security: SecurityContext,
    private readonly repositoryAlocacao: AlocacaoRepository,
    private readonly repositorySistema: SistemaRepository,
  ) {}

  public async findOneById(id: string, fields: string = '*'): Promise<Alocacao> {
    return this.repositoryAlocacao.findOneById(id, fields);
  }

  public async totalDoEmpregado(empregado: string): Promise<AlocacaoPorEmpregado> {
    const result = await this.repositoryAlocacao.totalDoEmpregado(empregado);
    if (!result) {
      throw new NotFoundException();
    }
    return result;
  }

  public async groupByEmpregado(pageable: Pageable, filtro?: AlocacaoAgrupadaFilter): Promise<Page<AlocacaoPorEmpregado>> {
    return this.repositoryAlocacao.groupByEmpregado(pageable, filtro);
  }

  public async groupByDominio(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorDominio[]> {
    return this.repositoryAlocacao.groupByDominio(filtro);
  }

  public async groupBySubDominio(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSubDominio[]> {
    return this.repositoryAlocacao.groupBySubDominio(filtro);
  }

  public async groupBySistema(filtro?: AlocacaoAgrupadaFilter): Promise<AlocacaoPorSistema[]> {
    return this.repositoryAlocacao.groupBySistema(filtro);
  }

  public async incluir(registro: Alocacao): Promise<string> {
    this.validarAcesso(registro);
    return this.repositoryAlocacao.insert(registro);
  }

  public async alterar(registro: Alocacao): Promise<void> {
    this.validarAcesso(registro);
    return this.repositoryAlocacao.update(registro);
  }

  private async validarAcesso(alocacao: Alocacao): Promise<void> {
    const sistema = alocacao.possuiSistema
      ? await this.repositorySistema.findOneById(alocacao.sistema.id, 'subdominio.dominio.(id-nome)')
      : undefined;
    const usuario = this.security.getRequestUser();
    this.validarAcessoDoUsusarioAoSistema(usuario, sistema);
  }

  public async excluirPorID(...ids: string[]): Promise<void> {
    const alocacoes = await this.repositoryAlocacao.findManyById(ids, 'id-rateioID-sistema.(id-subdominio.dominio.(id-nome))');
    return this.excluir(...alocacoes);
  }

  public async excluirPorSistema(...sistemaID: string[]): Promise<void> {
    const alocacoes = await this.repositoryAlocacao.findManyBySistema(sistemaID, 'id-rateioID-sistema.(id-subdominio.dominio.(id-nome))');
    return this.excluir(...alocacoes);
  }

  public async excluirPorEmpregado(...cpf: string[]): Promise<void> {
    const alocacoes = await this.repositoryAlocacao.findManyByEmpregado(cpf, 'id-rateioID-sistema.(id-subdominio.dominio.(id-nome))');
    return this.excluir(...alocacoes);
  }

  private async excluir(...alocacoes: Alocacao[]): Promise<void> {
    const usuario = this.security.getRequestUser();
    alocacoes.forEach(a => {
      this.validarAcessoDoUsusarioAoSistema(usuario, a.sistema);
    });
    return this.repositoryAlocacao.deleteAll(...alocacoes.map(a => a.id));
  }

  private validarAcessoDoUsusarioAoSistema(usuario, sistema) {
    if (sistema && !usuario.podeAlocarDominio(sistema.dominioID)) {
      throw new ForbiddenException(`Você não pode incluir alocações no domínio ${sistema.dominio.nome}`);
    }
    if (!sistema && !usuario.podeAlocarSuporte) {
      throw new ForbiddenException('Você não pode excluir alocações de suporte');
    }
  }

  public async atualizarSubProcessos(...sistemas: Sistema[]): Promise<void> {
    const map = sistemas.reduce((acc, sis) => set(acc, sis.id, sis), {});
    const alocacoes = await this.repositoryAlocacao.findManyBySistema(Object.keys(map), '*-sistema.id-empregado.cpf');
    const updates = alocacoes.map(alocacao =>
      Alocacao.build({
        id: alocacao.id,
        percentual: alocacao.percentual,
        empregado: alocacao.empregado,
        construcao: alocacao.construcao,
        sustentacao: alocacao.sustentacao,
        rateioID: alocacao.rateioID,
        sistema: map[alocacao.sistema.id],
      }),
    );
    return this.repositoryAlocacao.updateAll(...updates);
  }

  public async findManyByEmpregado(cpf: string | string[], fields: string = '*'): Promise<Alocacao[]> {
    return this.repositoryAlocacao.findManyByEmpregado(cpf, fields);
  }

  public async findManyBySistema(sistemaID: string | string[], fields: string = '*'): Promise<Alocacao[]> {
    return this.repositoryAlocacao.findManyBySistema(sistemaID, fields);
  }

  public async findManyByRateio(rateioID: string | string[], fields: string = '*'): Promise<Alocacao[]> {
    return this.repositoryAlocacao.findManyByRateio(rateioID, fields);
  }
}
