export enum CategoriaDominio {
  NEGOCIO = 'NEGOCIO',
  INTERNO = 'INTERNO',
  PRODUTO = 'PRODUTO',
}
