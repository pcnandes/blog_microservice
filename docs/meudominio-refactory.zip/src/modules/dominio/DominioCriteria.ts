import { Allow } from 'class-validator';
import { set } from 'lodash';
import { Where } from '../../common/query/Where';
import { Criteria } from '../../common/repository/Criteria';
import { ObjectUtils } from '../../common/utils/ObjectUtils';

export class DominioCriteria implements Criteria {
  @Allow()
  public readonly gestor?: string;
  @Allow()
  public readonly ug?: string;
  @Allow()
  public readonly sistema?: string;
  @Allow()
  public readonly servico?: string;
  @Allow()
  public readonly subdominio?: string;
  @Allow()
  public readonly search?: string;
  @Allow()
  public readonly cliente?: string;
  @Allow()
  public readonly grupogovi?: string;

  constructor(example?: Partial<DominioCriteria>) {
    this.gestor = example?.gestor;
    this.ug = example?.ug;
    this.sistema = example?.sistema;
    this.cliente = example?.cliente;
    this.servico = example?.servico;
    this.subdominio = example?.subdominio;
    this.search = example?.search;
    this.grupogovi = example?.grupogovi;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public toWhere(): Where {
    const where = new Where();
    this.applyUG(where, this.ug);
    this.applySistema(where, this.sistema);
    this.applySubDominio(where, this.subdominio);
    this.applyServico(where, this.servico);
    this.applyGestor(where, this.gestor);
    this.applyCliente(where, this.cliente);
    this.applySearch(where, this.search);
    this.applyGrupoGovi(where, this.grupogovi);
    return where;
  }

  private applySistema(where: Where, param: string, alias: string = 'sistema') {
    if (param) {
      where.andWhere(sub => {
        const args = set({}, alias, `%${param}%`);
        sub.orWhere(`dominio_subdominios_sistemas.identificador ILIKE :${alias}`, args);
        sub.orWhere(`dominio_subdominios_sistemas.sigla ILIKE :${alias}`, args);
        sub.orWhere(`dominio_subdominios_sistemas.nome ILIKE :${alias}`, args);
      });
      where.addJoin('subdominios.sistemas');
    }
  }

  private applyUG(where: Where, param: string, alias: string = 'ug') {
    if (param) {
      where.andWhere(sub => {
        const args = set({}, alias, param.toUpperCase());
        sub.orWhere(`dominio.ugDominio = :${alias}`, args);
        sub.orWhere(`dominio.ugNegocio = :${alias}`, args);
        sub.orWhere(`dominio_subdominios_sistemas_servicos_servico.ug = :${alias}`, args);
      });
      where.addJoin('subdominios.sistemas.servicos.servico');
    }
  }

  private applySubDominio(where: Where, param: string, alias: string = 'subdominio') {
    if (param) {
      where.andWhere(`dominio_subdominios.nome ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('subdominios');
    }
  }

  private applyServico(where: Where, param: string, alias: string = 'servico') {
    if (param) {
      if (param.match(/^[0-9]+$/)) {
        where.andWhere(`dominio_subdominios_sistemas_servicos_servico.codigo = :${alias}`, set({}, alias, parseInt(param, 10)));
      } else {
        where.andWhere(sub => {
          sub.orWhere(`dominio_subdominios_sistemas_servicos_servico.mnemonico ILIKE :${alias}`, set({}, alias, `%${param}%`));
          sub.orWhere(`dominio_subdominios_sistemas_servicos_servico.titulo ILIKE :${alias}`, set({}, alias, `%${param}%`));
        });
      }
      where.addJoin('subdominios.sistemas.servicos.servico');
    }
  }

  private applyGrupoGovi(where: Where, param: string, alias: string = 'grupogovi') {
    if (param) {
      where.andWhere(`ARRAY_TO_STRING(dominio_subdominios_sistemas_servicos.grupogovi, ',') ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('subdominios.sistemas.servicos');
    }
  }

  private applyGestor(where: Where, param: string, alias: string = 'gestor') {
    if (param) {
      where.andWhere(`dominio_gestorDominio.nome ILIKE :${alias}`, set({}, alias, `${param}%`));
      where.addJoin('gestorDominio');
    }
  }

  private applyCliente(where: Where, param: string, alias: string = 'cliente') {
    if (param) {
      where.andWhere(`dominio_subdominios_sistemas_servicos_servico.cliente ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('subdominios.sistemas.servicos.servico');
    }
  }

  private applySearch(where: Where, param: string) {
    if (param) {
      where.andWhere(sub => {
        sub.orWhere(`dominio.nome ILIKE :search`, { search: `%${param}%` });
        sub.orWhere(nth => this.applyUG(nth, param, 'searchUG'));
        sub.orWhere(nth => this.applyGestor(nth, param, 'searchGestor'));
        sub.orWhere(nth => this.applySistema(nth, param, 'searchSistema'));
        sub.orWhere(nth => this.applyServico(nth, param, 'searchServico'));
        sub.orWhere(nth => this.applyCliente(nth, param, 'searchCliente'));
        sub.orWhere(nth => this.applySubDominio(nth, param, 'searchSubDominio'));
        sub.orWhere(nth => this.applyGrupoGovi(nth, param, 'searchGrupoGovi'));
      });
    }
    return null;
  }
}
