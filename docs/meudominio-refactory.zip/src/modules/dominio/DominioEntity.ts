import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsNotEmpty, IsNotEmptyObject } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Empregado } from '../empregado/EmpregadoEntity';
import { SubDominio } from '../subdominio/SubDominioEntity';
import { CategoriaDominio } from './CategoriaDominio';
import { SituacaoDominio } from './SituacaoDominio';

@Entity()
export class Dominio {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional()
  public readonly id?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly codigo?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty({ message: 'Informe o nome' })
  public readonly nome?: string;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly descricao?: string;

  @Column({ name: 'ug_dominio' })
  @ApiPropertyOptional({ example: 'SUPDR' })
  @IsNotEmpty({ message: 'Informe a UG do domínio' })
  public readonly ugDominio?: string;

  @Column({ name: 'ug_negocio' })
  @ApiPropertyOptional({ example: 'SUNEF' })
  @Allow()
  public readonly ugNegocio?: string;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'gestor_dominio', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  @IsNotEmptyObject({ message: 'Informe o gestor de domínio' })
  public readonly gestorDominio?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'gestor_negocio', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  @Allow()
  public readonly gestorNegocio?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'responsavel_ux', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  @Allow()
  public readonly responsavelUX?: Empregado;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  @Column()
  @ApiPropertyOptional({ enum: SituacaoDominio })
  public readonly situacao?: SituacaoDominio;

  @Column()
  @ApiPropertyOptional({ enum: CategoriaDominio })
  @IsNotEmpty()
  public readonly categoria?: CategoriaDominio;

  @OneToMany(
    type => SubDominio,
    subdominio => subdominio.dominio,
    { cascade: false },
  )
  @ApiPropertyOptional({ type: () => SubDominio, isArray: true })
  public readonly subdominios?: SubDominio[];

  constructor(example?: Example<Dominio>) {
    this.id = example?.id;
    this.codigo = example?.codigo;
    this.nome = example?.nome;
    this.descricao = example?.descricao;
    this.ugDominio = example?.ugDominio;
    this.ugNegocio = example?.ugNegocio;
    this.gestorDominio = example?.gestorDominio ? new Empregado(example.gestorDominio) : undefined;
    this.gestorNegocio = example?.gestorNegocio ? new Empregado(example.gestorNegocio) : undefined;
    this.responsavelUX = example?.responsavelUX ? new Empregado(example.responsavelUX) : undefined;
    this.situacao = example?.situacao;
    this.categoria = example?.categoria;
    this.versao = example?.versao;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isAtivo() {
    if (!this.situacao) {
      throw new Error('[Dominio].situacao não carregado');
    }
    return this.situacao !== SituacaoDominio.INATIVO;
  }
}
