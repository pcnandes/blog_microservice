import { SistemaRepositoryORM } from './../sistema/SistemaRepositoryORM';
import { SistemaRepository } from './../sistema/SistemaRepository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AlocacaoRateioRepository } from '../alocacao/AlocacaoRateioRepository';
import { AlocacaoRepository } from '../alocacao/AlocacaoRepository';
import { DominioRepositoryORM } from '../dominio/DominioRepositoryORM';
import { EmpregadoRepositoryORM } from '../empregado/EmpregadoRepositoryORM';
import { CommonModule } from './../../common/CommonModule';
import { AlocacaoRateioRepositoryORM } from './../alocacao/AlocacaoRateioRepositoryORM';
import { AlocacaoRateioService } from './../alocacao/AlocacaoRateioService';
import { AlocacaoRepositoryORM } from './../alocacao/AlocacaoRepositoryORM';
import { EmpregadoModule } from './../empregado/EmpregadoModule';
import { DominioRepository } from './DominioRepository';
import { DominioREST } from './DominioREST';
import { DominioService } from './DominioService';

@Module({
  controllers: [DominioREST],
  exports: [DominioService, DominioRepository],
  imports: [
    TypeOrmModule.forFeature([
      EmpregadoRepositoryORM,
      DominioRepositoryORM,
      AlocacaoRateioRepositoryORM,
      AlocacaoRepositoryORM,
      SistemaRepositoryORM,
    ]),
    CommonModule,
    EmpregadoModule,
  ],
  providers: [DominioService, DominioRepository, AlocacaoRateioService, AlocacaoRepository, AlocacaoRateioRepository, SistemaRepository],
})
export class DominioModule {}
