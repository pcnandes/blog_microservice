import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform, NotFoundException } from '@nestjs/common';
import { validate } from 'class-validator';
import { get } from 'lodash';
import { Empregado } from '../empregado/EmpregadoEntity';
import { EmpregadoRepository } from './../empregado/EmpregadoRepository';
import { Dominio } from './DominioEntity';
import { DominioRepository } from './DominioRepository';

interface DominioEmpregados {
  gestorDominio?: Empregado;
  gestorNegocio?: Empregado;
  responsavelUX?: Empregado;
}

@Injectable()
export class DominioPipeAlterar implements PipeTransform<any, Promise<Dominio>> {
  constructor(protected readonly repositoryDominio: DominioRepository, protected readonly repositoryEmpregado: EmpregadoRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Dominio> {
    const antigo = await this.repositoryDominio.findOneById(value.id);
    if (!antigo) {
      throw new NotFoundException();
    }
    const { gestorDominio, gestorNegocio, responsavelUX } = await this.validaEmpregados(value);
    const dominio = new Dominio({
      id: antigo.id,
      gestorDominio,
      gestorNegocio,
      responsavelUX,
      nome: value.nome,
      descricao: value.descricao,
      situacao: antigo.situacao,
      categoria: antigo.categoria,
      codigo: antigo.codigo,
      ugDominio: value.ugDominio,
      ugNegocio: value.ugNegocio,
      versao: value.versao,
    });
    await this.validaDominio(dominio);
    return dominio;
  }

  protected async validaDominio(dominio: Dominio): Promise<void> {
    const errors = await validate(dominio);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
  }

  protected async validaEmpregados(value: any): Promise<DominioEmpregados> {
    const gestorDominioCPF = get(value, 'gestorDominio.cpf');
    const gestorNegocioCPF = get(value, 'gestorNegocio.cpf');
    const responsavelUXCPF = get(value, 'responsavelUX.cpf');
    const listaCPF = [gestorDominioCPF, gestorNegocioCPF, responsavelUXCPF].filter(cpf => !!cpf);
    if (listaCPF.length === 0) {
      return {};
    }
    const empregados = await this.repositoryEmpregado.findManyByCPF(listaCPF, 'cpf-matricula-lotacao-dataDesligamento-funcaoConfianca');
    const gestorDominio = empregados.filter(empr => empr.cpf === gestorDominioCPF).pop();
    const gestorNegocio = empregados.filter(empr => empr.cpf === gestorNegocioCPF).pop();
    const responsavelUX = empregados.filter(empr => empr.cpf === responsavelUXCPF).pop();
    this.validaEmpregadoAtivoDIDES(gestorDominio, 'O gestor do domínio precisar ser da DIDES');
    this.validaEmpregadoAtivoDIDES(responsavelUX, 'O RUX precisar ser da DIDES');
    return {
      gestorDominio,
      gestorNegocio,
      responsavelUX,
    };
  }

  protected validaEmpregadoAtivoDIDES(empregado: Empregado, message: string) {
    if (empregado && (!empregado.isDIDES || !empregado.isAtivo)) {
      throw new BadRequestException(message);
    }
  }
}
