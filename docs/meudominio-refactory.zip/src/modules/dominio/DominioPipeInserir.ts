import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { EmpregadoRepository } from './../empregado/EmpregadoRepository';
import { Dominio } from './DominioEntity';
import { DominioPipeAlterar } from './DominioPipeAlterar';
import { DominioRepository } from './DominioRepository';
import { SituacaoDominio } from './SituacaoDominio';

@Injectable()
export class DominioPipeInserir extends DominioPipeAlterar implements PipeTransform<any, Promise<Dominio>> {
  constructor(repositoryDominio: DominioRepository, repositoryEmpregado: EmpregadoRepository) {
    super(repositoryDominio, repositoryEmpregado);
  }

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Dominio> {
    const { gestorDominio, gestorNegocio, responsavelUX } = await this.validaEmpregados(value);
    const codigo = await this.repositoryDominio.findNextCodigo();
    const dominio = new Dominio({
      gestorDominio,
      gestorNegocio,
      responsavelUX,
      situacao: SituacaoDominio.ATIVO,
      nome: value.nome,
      descricao: value.descricao,
      categoria: value.categoria,
      codigo,
      ugDominio: value.ugDominio,
      ugNegocio: value.ugNegocio,
    });
    await this.validaDominio(dominio);
    return dominio;
  }
}
