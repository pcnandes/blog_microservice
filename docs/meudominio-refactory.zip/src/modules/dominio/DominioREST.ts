import { Body, Controller, Get, Param, Post, Put, Query, Res } from '@nestjs/common';
import { isUUID } from '@nestjs/common/utils/is-uuid';
import { ApiBearerAuth, ApiBody, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { Output } from '../../common/output/Output';
import { ObjectPipe } from '../../common/pipes/ObjectPipe';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { SortPipe } from '../../common/pipes/SortPipe';
import { Sort } from '../../common/query/Sort';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { HasRole } from '../../common/security/HasRoleDecorator';
import { Perfil } from '../usuario/Perfil';
import { OutputJSON } from './../../common/output/OutputJSON';
import { DominioCriteria } from './DominioCriteria';
import { Dominio } from './DominioEntity';
import { DominioPipeAlterar } from './DominioPipeAlterar';
import { DominioPipeInserir } from './DominioPipeInserir';
import { DominioService } from './DominioService';

@Controller('dominio')
@ApiTags('Domínio')
@ApiBearerAuth()
export class DominioREST {
  constructor(private readonly service: DominioService) {}

  @Get(':identificacao')
  @ApiOperation({ summary: 'Obtém as informações de um domínio' })
  @ApiParam({ name: 'identificacao', description: 'ID ou código do domínio', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: Dominio, description: 'Dados do domínio' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Domínio não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorCodigoOuId(@Param('identificacao') identificacao: string, @Query('fields') fields: string = '*'): Promise<Dominio> {
    if (isUUID(identificacao)) {
      return this.service.findOneByID(identificacao, fields);
    } else {
      return this.service.findOneByCodigo(identificacao, fields);
    }
  }

  @Get()
  @ApiOperation({ summary: 'Obtém uma lista de domínios' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = id-codigo-nome', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'sort', description: 'Ordenação. Padrão = codigo', required: false })
  @ApiQuery({ name: 'gestor', description: 'Busca pelo nome do gestor', required: false })
  @ApiQuery({ name: 'ug', description: 'Busca pela UG do domínio, de negócio ou do serviço', required: false })
  @ApiQuery({ name: 'sistema', description: 'Busca pelo identificador, sigla ou nome do sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Busca pelo código ou nome do serviço', required: false })
  @ApiQuery({ name: 'subdominio', description: 'Busca pelo nome do subdomínio', required: false })
  @ApiQuery({ name: 'search', description: 'Busca por todos os critérios', required: false })
  @ApiResponse({ status: 200, type: Dominio, isArray: true, description: 'Lista de dominios' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listar(
    @Res() response: Response,
    @Query('fields') fields: string = 'id-codigo-nome',
    @Query('sort', SortPipe) sort: Sort = Sort.by('codigo'),
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Query(ObjectPipe) criteria?: DominioCriteria,
  ) {
    output.ofList(response, await this.service.findMany(fields, criteria, sort), [
      'subdominios',
      'subdominios.sistemas',
      'subdominios.sistemas.servicos',
    ]);
  }

  @Transactional()
  @Post()
  @HasRole(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)
  @ApiOperation({ summary: 'Inclui um novo domínio' })
  @ApiBody({ type: Dominio })
  @ApiResponse({ status: 201, description: 'Domínio criado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async inserir(@Res() response: Response, @Body(DominioPipeInserir) dominio: Dominio) {
    const id = await this.service.inserir(dominio);
    return response
      .status(201)
      .set({ 'Content-Type': 'text/plain' })
      .send(dominio.codigo);
  }

  @Transactional()
  @Put()
  @Authenticated()
  @ApiOperation({ summary: 'Altera um domínio existente' })
  @ApiBody({ type: Dominio })
  @ApiResponse({ status: 204, description: 'Domínio alterado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async alterar(@Res() response: Response, @Body(DominioPipeAlterar) dominio: Dominio) {
    await this.service.alterar(dominio);
    return response.status(204);
  }
}
