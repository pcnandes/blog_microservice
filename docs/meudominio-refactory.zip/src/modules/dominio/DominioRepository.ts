import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { Dominio } from './DominioEntity';
import { DominioRepositoryORM } from './DominioRepositoryORM';

@Injectable()
export class DominioRepository extends RepositoryAuditable<Dominio> {
  constructor(repository: DominioRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findManyByGestor(cpf: string, fields: string = '*'): Promise<Dominio[]> {
    return this.findAll(fields, (builder: Where) => {
      builder.andWhere('dominio_gestorDominio.cpf = :gestorDominio', { gestorDominio: cpf });
      builder.addJoin('gestorDominio');
    });
  }

  public async findOneByCodigo(codigo: string, fields: string = '*'): Promise<Dominio> {
    return this.findOne(fields, (builder: Where) => {
      builder.andWhere('codigo = :codigo', { codigo });
    });
  }

  public async findNextCodigo(): Promise<string> {
    const [{ codigo }] = await this.repository.query(
      `SELECT LPAD(CAST((CAST(COALESCE(MAX(codigo), '0000') AS INTEGER) + 1) AS TEXT),4,'0') AS codigo FROM dominio`,
    );
    return codigo;
  }
}
