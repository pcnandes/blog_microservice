import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Dominio } from './DominioEntity';

@EntityRepository(Dominio)
export class DominioRepositoryORM extends BaseRepository<Dominio> {}
