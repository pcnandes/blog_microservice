import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Sort } from '../../common/query/Sort';
import { CacheAdapter } from './../../common/cache/CacheAdapterRedis';
import { SecurityContext } from './../../common/security/SecurityContext';
import { AlocacaoRateioService } from './../alocacao/AlocacaoRateioService';
import { DominioCriteria } from './DominioCriteria';
import { Dominio } from './DominioEntity';
import { DominioRepository } from './DominioRepository';

@Injectable()
export class DominioService {
  constructor(
    private readonly repository: DominioRepository,
    private readonly security: SecurityContext,
    private readonly cache: CacheAdapter,
    private readonly alocacaoRateio: AlocacaoRateioService,
  ) {}

  public async findOneByCodigo(codigo: string, fields: string = '*'): Promise<Dominio> {
    const dominio = await this.repository.findOneByCodigo(codigo, fields);
    if (!dominio) {
      throw new NotFoundException();
    }
    return dominio;
  }

  public async findOneByID(id: string, fields: string = '*'): Promise<Dominio> {
    const dominio = await this.repository.findOneById(id, fields);
    if (!dominio) {
      throw new NotFoundException();
    }
    return dominio;
  }

  public async findMany(fields: string = 'id-codigo-nome', criteria?: DominioCriteria, sort: Sort = Sort.by('codigo')): Promise<Dominio[]> {
    return this.repository.findAll(fields, criteria, sort);
  }

  public async inserir(dominio: Dominio): Promise<string> {
    const usuario = this.security.getRequestUser();
    if (!usuario.isAdministrador && !usuario.isCadastradorDominio) {
      throw new ForbiddenException('Você não têm permissão para incluir um novo domínio');
    }
    const id = await this.repository.insert(dominio);
    this.cache.hdel('USUARIO', dominio.gestorDominio.cpf);
    return id;
  }

  public async alterar(dominio: Dominio): Promise<void> {
    const usuario = this.security.getRequestUser();
    if (!usuario.podeAlterarDominio(dominio.id)) {
      throw new ForbiddenException('Você não têm permissão para alterar o domínio');
    }
    const antigo = await this.findOneByID(dominio.id, 'id-gestorDominio.cpf-ugDominio');
    await this.repository.update(dominio);
    if (antigo.gestorDominio.cpf !== dominio.gestorDominio.cpf) {
      this.cache.hdel('USUARIO', antigo.gestorDominio.cpf, dominio.gestorDominio.cpf);
    }
    if (antigo.ugDominio !== dominio.ugDominio) {
      await this.alocacaoRateio.atualizarPorEscopo(antigo.ugDominio, dominio.ugDominio);
    }
  }
}
