export enum SituacaoDominio {
  ATIVO = 'ATIVO',
  INATIVO = 'INATIVO',
}
