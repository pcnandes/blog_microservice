import { ApiPropertyOptional } from '@nestjs/swagger';
import { Column, Entity, PrimaryColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';

@Entity()
export class Empregado {
  @PrimaryColumn()
  @ApiPropertyOptional()
  public readonly cpf?: string;

  @Column({ type: 'integer' })
  @ApiPropertyOptional()
  public readonly matricula?: number;

  @Column()
  @ApiPropertyOptional()
  public readonly nome?: string;

  @Column()
  @ApiPropertyOptional({ example: 'DIDES/SUPDG/DGGOV/DGGO7' })
  public readonly lotacao?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly ramal?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly email?: string;

  @Column({ type: 'date', name: 'data_desligamento' })
  @ApiPropertyOptional({ type: 'string', format: 'date', example: '2018-12-31' })
  public readonly dataDesligamento?: Date;

  @Column({ type: 'smallint' })
  @ApiPropertyOptional()
  public readonly jornada?: number;

  @Column()
  @ApiPropertyOptional()
  public readonly teletrabalhador?: boolean;

  @Column({ name: 'funcao_confianca' })
  @ApiPropertyOptional()
  public readonly funcaoConfianca?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly cargo?: string;

  constructor(example?: Example<Empregado>) {
    this.cpf = example?.cpf;
    this.matricula = example?.matricula;
    this.teletrabalhador = example?.teletrabalhador;
    this.nome = example?.nome;
    this.funcaoConfianca = example?.funcaoConfianca;
    this.lotacao = example?.lotacao;
    this.ramal = example?.ramal;
    this.email = example?.email;
    this.cargo = example?.cargo;
    this.jornada = example?.jornada;
    this.dataDesligamento = example?.dataDesligamento;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isChefe() {
    if (this.funcaoConfianca === undefined) {
      throw new Error('[Empregado].funcaoConfianca não carregado');
    }
    return !!this.funcaoConfianca;
  }

  public get isDIDES() {
    if (!this.lotacao) {
      throw new Error('[Empregado].lotacao não carregado');
    }
    return this.lotacao.startsWith('DIDES');
  }

  public get isCOADM() {
    if (!this.lotacao) {
      throw new Error('[Empregado].lotacao não carregado');
    }
    return this.lotacao.startsWith('DIDES/COADM');
  }

  public get isAtivo() {
    if (this.dataDesligamento === undefined) {
      throw new Error('[Empregado].dataDesligamento não carregado');
    }
    return !this.dataDesligamento;
  }

  public get isSuperintendente() {
    return this.isChefe && !!(this.funcaoConfianca === 'SUPERINTENDENTE');
  }

  public get isAssessorDiretoria() {
    return this.isChefe && this.funcaoConfianca.startsWith('ASSESSOR DIRETORIA');
  }

  public get isDiretor() {
    return this.isChefe && !!(this.funcaoConfianca === 'DIRETOR');
  }

  public get isAlocavel() {
    return this.isAtivo && this.isDIDES && !this.isSuperintendente && !this.isDiretor && !this.isAssessorDiretoria;
  }
}
