import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '../../common/CommonModule';
import { EmpregadoRepository } from './EmpregadoRepository';
import { EmpregadoRepositoryORM } from './EmpregadoRepositoryORM';
import { EmpregadoREST } from './EmpregadoREST';

@Module({
  controllers: [EmpregadoREST],
  exports: [EmpregadoRepository],
  imports: [TypeOrmModule.forFeature([EmpregadoRepositoryORM]), CommonModule],
  providers: [EmpregadoRepository],
})
export class EmpregadoModule {}
