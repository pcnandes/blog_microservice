import { BadRequestException, Controller, Get, NotFoundException, Param, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Output } from '../../common/output/Output';
import { OutputJSON } from '../../common/output/OutputJSON';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { Empregado } from './EmpregadoEntity';
import { EmpregadoRepository } from './EmpregadoRepository';

@Controller('empregado')
@ApiTags('Empregado')
@ApiBearerAuth()
export class EmpregadoREST {
  constructor(private readonly repository: EmpregadoRepository) {}

  @Get(':identificacao')
  @Authenticated()
  @ApiOperation({ summary: 'Busca empregado por CPF ou Matrícula' })
  @ApiParam({ name: 'identificacao', description: 'CPF ou Matrícula', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: Empregado })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 400, description: 'CPF ou Matrícula inválidos' })
  @ApiResponse({ status: 404, description: 'CPF ou Matrícula não encontrados' })
  @ApiProduces('application/json')
  public async buscarPorMatriculaOuCPF(
    @Param('identificacao') identificacao: string,
    @Query('fields') fields: string = '*',
  ): Promise<Empregado> {
    let empregado: Empregado;
    if (identificacao.match(/^[0-9]{11}$/)) {
      empregado = await this.repository.findOneByCPF(identificacao, fields);
    } else if (identificacao.match(/^[0-9]{1,8}/)) {
      empregado = await this.repository.findOneByMatricula(parseInt(identificacao, 10), fields);
    } else {
      throw new BadRequestException('CPF ou Matrícula inválida');
    }
    if (!empregado) {
      throw new NotFoundException();
    }
    return empregado;
  }

  @Get()
  @Authenticated()
  @ApiOperation({ summary: 'Obtém empregados ativos' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiResponse({ status: 200, type: Empregado, isArray: true, description: 'Lista de empregados' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listarAtivos(
    @Query('fields') fields: string = '*',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Res() response: Response,
  ) {
    const empregados = await this.repository.findAllAtivos(fields);
    return output.ofList(response, empregados);
  }
}
