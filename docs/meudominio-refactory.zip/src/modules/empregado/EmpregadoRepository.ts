import { Injectable } from '@nestjs/common';
import { RepositoryBase } from '../../common/repository/RepositoryBase';
import { Empregado } from './EmpregadoEntity';
import { EmpregadoRepositoryORM } from './EmpregadoRepositoryORM';
import { Where } from '../../common/query/Where';

@Injectable()
export class EmpregadoRepository extends RepositoryBase<Empregado> {
  constructor(repository: EmpregadoRepositoryORM) {
    super(repository);
  }

  public async findAllAtivos(select: string = '*'): Promise<Empregado[]> {
    return this.findAll(select, (builder: Where) => {
      builder.andWhere('empregado.dataDesligamento IS NULL');
    });
  }

  public async findOneByCPF(cpf: string, select: string = '*') {
    return this.findOneById(cpf, select);
  }

  public async findOneByMatricula(matricula: number, select: string = '*') {
    return this.findOne(select, (builder: Where) => {
      builder.andWhere('empregado.matricula = :matricula', { matricula });
    });
  }

  public async findManyByCPF(cpf: string[], select: string = '*') {
    return this.findManyById(cpf, select);
  }
}
