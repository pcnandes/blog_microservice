import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Empregado } from './EmpregadoEntity';

@EntityRepository(Empregado)
export class EmpregadoRepositoryORM extends BaseRepository<Empregado> {}
