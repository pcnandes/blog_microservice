import { Allow } from 'class-validator';
import { BooleanPipe } from '../../common/pipes/BooleanPipe';
import { Where } from '../../common/query/Where';
import { Criteria } from '../../common/repository/Criteria';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';

export class GrupoGoviCriteria implements Criteria {
  @Allow()
  public readonly sigla?: string;
  @Allow()
  public readonly ug?: string;
  @Allow()
  public readonly ativo?: boolean;
  @Allow()
  public readonly dides?: boolean;

  constructor(example?: Example<GrupoGoviCriteria>) {
    this.sigla = example?.sigla;
    this.ug = example?.ug;
    this.ativo = BooleanPipe.parse(example?.ativo);
    this.dides = BooleanPipe.parse(example?.dides);
    ObjectUtils.removePropertiesUndefined(this);
  }

  toWhere(): Where {
    const where = new Where();
    if (this.sigla) {
      where.andWhere('grupogovi.sigla ILIKE :sigla', { sigla: `${this.sigla}%` });
    }
    if (this.ug) {
      where.andWhere('grupogovi.ug = :ug', { ug: this.ug.toUpperCase() });
    }
    if (this.ativo === true) {
      where.andWhere(`COALESCE(grupogovi.situacao,'ATIVO') = 'ATIVO'`);
    }
    if (this.ativo === false) {
      where.andWhere(`grupogovi.situacao = 'INATIVO'`);
    }
    if (this.dides === true) {
      where.andWhere(sub => {
        sub
          .orWhere(`grupogovi.ug in ('SUPDE', 'SUPDA', 'SUPST', 'SUPSS', 'SUPSD', 'SUPDR', 'SUPDG', 'SUPAI', 'SUPSE')`)
          .orWhere(`grupogovi.sigla ilike 'GSDE%'`)
          .orWhere(`grupogovi.sigla ilike 'GSDA%'`)
          .orWhere(`grupogovi.sigla ilike 'GSSS%'`)
          .orWhere(`grupogovi.sigla ilike 'GSSD%'`);
      });
    }
    return where;
  }
}
