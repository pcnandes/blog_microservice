import { ApiPropertyOptional } from '@nestjs/swagger';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Empregado } from '../empregado/EmpregadoEntity';

@Entity({ name: 'grupo_govi' })
export class GrupoGovi {
  @PrimaryColumn()
  @ApiPropertyOptional()
  public readonly id: number;

  @Column()
  @ApiPropertyOptional()
  public readonly sigla?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly ug?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly situacao?: string;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'recorrencia1', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly recorrencia1?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'recorrencia2', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly recorrencia2?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'recorrencia3', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly recorrencia3?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'recorrencia4', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly recorrencia4?: Empregado;

  constructor(example?: Example<GrupoGovi>) {
    this.id = example?.id;
    this.situacao = example?.situacao;
    this.sigla = example?.sigla;
    this.ug = example?.ug;
    this.recorrencia1 = example?.recorrencia1 ? new Empregado(example.recorrencia1) : undefined;
    this.recorrencia2 = example?.recorrencia2 ? new Empregado(example.recorrencia2) : undefined;
    this.recorrencia3 = example?.recorrencia3 ? new Empregado(example.recorrencia3) : undefined;
    this.recorrencia4 = example?.recorrencia4 ? new Empregado(example.recorrencia4) : undefined;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isDIDES() {
    if (!this.sigla) {
      throw new Error('[GrupoGovi].sigla não carregado');
    }
    if (this.ug === undefined) {
      throw new Error('[GrupoGovi].ug não carregado');
    }
    return (
      ['SUPDE', 'SUPDA', 'SUPST', 'SUPSS', 'SUPSD', 'SUPDG', 'SUPDR', 'SUPAI', 'SUPSE'].includes(this.ug) ||
      ['GSDE', 'GSDA', 'GSSS', 'GSSD'].includes(this.sigla.slice(0, 4))
    );
  }

  public get ativo(): boolean {
    if (this.situacao === undefined) {
      throw new Error('[GrupoGovi].situacao não carregado');
    }
    return this.situacao !== 'INATIVO';
  }
}
