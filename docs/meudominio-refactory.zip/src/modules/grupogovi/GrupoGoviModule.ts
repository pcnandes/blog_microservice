import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '../../common/CommonModule';
import { GrupoGoviRepository } from './GrupoGoviRepository';
import { GrupoGoviRepositoryORM } from './GrupoGoviRepositoryORM';
import { GrupoGoviREST } from './GrupoGoviREST';

@Module({
  controllers: [GrupoGoviREST],
  exports: [GrupoGoviRepository],
  imports: [TypeOrmModule.forFeature([GrupoGoviRepositoryORM]), CommonModule],
  providers: [GrupoGoviRepository],
})
export class GrupoGoviModule {}
