import { Controller, Get, Param, ParseIntPipe, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Output } from '../../common/output/Output';
import { OutputJSON } from '../../common/output/OutputJSON';
import { ObjectPipe } from '../../common/pipes/ObjectPipe';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Sort } from '../../common/query/Sort';
import { Page } from '../../common/repository/Page';
import { Pageable } from '../../common/repository/Pageable';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { GrupoGoviCriteria } from './GrupoGoviCriteria';
import { GrupoGovi } from './GrupoGoviEntity';
import { GrupoGoviRepository } from './GrupoGoviRepository';

@Controller('grupogovi')
@ApiTags('Grupo Govi')
@ApiBearerAuth()
export class GrupoGoviREST {
  constructor(private readonly repository: GrupoGoviRepository) {}

  @Get(':id')
  @Authenticated()
  @ApiOperation({ summary: 'Busca grupo pelo ID' })
  @ApiParam({ name: 'codigo', description: 'Código de serviço', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: GrupoGovi })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Grupo não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorCodigo(@Param('id', ParseIntPipe) id: number, @Query('fields') fields: string = '*'): Promise<GrupoGovi> {
    return this.repository.findOneById(id, fields);
  }

  @Get()
  @Authenticated()
  @ApiOperation({ summary: 'Obtém lista de grupo {PAGINADO}' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = codigo', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'page', description: 'Número da página. Padrão = 1', required: false, type: Number })
  @ApiQuery({ name: 'size', description: 'Items por página. Padrão = 10', required: false, type: Number })
  @ApiQuery({ name: 'sort', description: 'Ordenação. Padrão = sigla', required: false })
  @ApiQuery({ name: 'sigla', description: 'Sigla do grupo', required: false })
  @ApiQuery({ name: 'dides', description: 'Somente Grupos DIDES', required: false, type: Boolean })
  @ApiQuery({ name: 'ativo', description: 'Ativo', required: false, type: Boolean })
  @ApiQuery({ name: 'ug', description: 'UG do Grupo', required: false })
  @ApiResponse({ status: 200, type: Page, description: 'Lista de grupos' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listarAtivos(
    @Res() response: Response,
    @Query('fields') fields: string = 'sigla',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Query(ObjectPipe) criteria?: GrupoGoviCriteria,
    @Query(ObjectPipe) pageable: Pageable = new Pageable({ pageNumber: 1, pageSize: 10, sort: Sort.by('sigla') }),
  ) {
    const servicos = await this.repository.findPage(pageable, fields, criteria);
    return output.ofPage(response, servicos);
  }
}
