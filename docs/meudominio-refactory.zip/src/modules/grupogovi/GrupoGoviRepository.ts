import { Injectable } from '@nestjs/common';
import { RepositoryBase } from '../../common/repository/RepositoryBase';
import { GrupoGovi } from './GrupoGoviEntity';
import { GrupoGoviRepositoryORM } from './GrupoGoviRepositoryORM';
import { Sort } from '../../common/query/Sort';

@Injectable()
export class GrupoGoviRepository extends RepositoryBase<GrupoGovi> {
  constructor(repository: GrupoGoviRepositoryORM) {
    super(repository);
  }

  public async findManyBySigla(siglas: string | string[], fields: string = 'sigla-ug-situacao'): Promise<GrupoGovi[]> {
    if (siglas.length === 0) {
      return [];
    }
    return this.findAll(
      fields,
      where => {
        where.andWhere('sigla IN (:...siglas)', { siglas: Array.isArray(siglas) ? siglas : [siglas] });
      },
      Sort.by('sigla'),
    );
  }
}
