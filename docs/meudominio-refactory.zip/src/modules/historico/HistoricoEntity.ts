import { ObjectUtils } from './../../common/utils/ObjectUtils';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Empregado } from '../empregado/EmpregadoEntity';

@Entity()
export class Historico {
  constructor(example?: Partial<Historico>) {
    this.pk = example?.pk;
    this.id = example?.id;
    this.data = example?.data;
    this.autor = example?.autor ? new Empregado(example.autor) : undefined;
    this.operacao = example?.operacao;
    this.entidade = example?.entidade;
    this.atributos = example?.atributos;
    this.registro = example?.registro;
    this.modificados = example?.modificados;
    this.proximo = example?.proximo;
    ObjectUtils.removePropertiesUndefined(this);
  }

  @PrimaryGeneratedColumn({ type: 'uuid' })
  public readonly pk?: string;

  @Column({ type: 'uuid' })
  public readonly id?: string;

  @Column()
  public readonly data?: Date;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'autor', referencedColumnName: 'cpf' })
  public readonly autor?: Empregado;

  @Column()
  public readonly operacao?: 'I' | 'U' | 'D';

  @Column()
  public readonly entidade?: string;

  @Column({ type: 'varchar', array: true })
  public readonly atributos?: string[];

  @Column({ type: 'json' })
  public readonly registro?: any;

  @Column({ type: 'json' })
  public readonly modificados?: any;

  @Column()
  public readonly proximo?: Date;
}
