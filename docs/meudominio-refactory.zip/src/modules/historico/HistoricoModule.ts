import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HistoricoRepository } from './HistoricoRepository';
import { HistoricoRepositoryORM } from './HistoricoRepositoryORM';

@Module({
  controllers: [],
  exports: [HistoricoRepository],
  imports: [TypeOrmModule.forFeature([HistoricoRepositoryORM])],
  providers: [HistoricoRepository],
})
export class HistoricoModule {}
