import { Injectable } from '@nestjs/common';
import { RepositoryCRUD } from '../../common/repository/RepositoryCRUD';
import { Historico } from './HistoricoEntity';
import { HistoricoRepositoryORM } from './HistoricoRepositoryORM';

@Injectable()
export class HistoricoRepository extends RepositoryCRUD<Historico> {
  constructor(repository: HistoricoRepositoryORM) {
    super(repository);
  }

  public async update(entity: Historico): Promise<void> {
    throw new Error('Operação não suportada');
  }

  public async updateAll(...entity: Historico[]): Promise<void> {
    throw new Error('Operação não suportada');
  }

  public async delete(id: string | number): Promise<void> {
    throw new Error('Operação não suportada');
  }

  public async deleteAll(...id: string[] | number[]): Promise<void> {
    throw new Error('Operação não suportada');
  }
}
