import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Historico } from './HistoricoEntity';

@EntityRepository(Historico)
export class HistoricoRepositoryORM extends BaseRepository<Historico> {}
