import { Injectable, Logger, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import { get } from 'lodash';
import { createNamespace, getNamespace } from 'node-request-context';
import { Usuario } from '../usuario/UsuarioEntity';
import { SecurityContext } from './../../common/security/SecurityContext';
import { UsuarioService } from './../usuario/UsuarioService';

@Injectable()
export class LoginMiddleware implements NestMiddleware {
  constructor(private readonly service: UsuarioService) {}

  async use(req: Request, res: Response, next: () => void) {
    const token = get(req, 'kauth');
    const username = get(token, 'grant.access_token.content.username');
    let usuario: Usuario = null;
    if (username) {
      try {
        usuario = await this.service.buscarPorUsername(username);
      } catch (err) {
        Logger.error(`Usuário ${username} não encontrado`, err.toString());
      }
    }
    const namespace = getNamespace(SecurityContext.NAMESPACE_NAME) || createNamespace(SecurityContext.NAMESPACE_NAME);
    namespace.run(() => {
      namespace.set(SecurityContext.PROP_USER, usuario);
      namespace.set(SecurityContext.PROP_TIME, new Date());
      next();
    });
  }
}
