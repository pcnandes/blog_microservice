import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DominioRepositoryORM } from '../dominio/DominioRepositoryORM';
import { EmpregadoRepositoryORM } from '../empregado/EmpregadoRepositoryORM';
import { PermissaoRepositoryORM } from '../permissao/PermissaoRepositoryORM';
import { UsuarioRepositoryORM } from '../usuario/UsuarioRepositoryORM';
import { UsuarioModule } from './../usuario/UsuarioModule';
import { LoginMiddleware } from './LoginMiddleware';

@Module({
  controllers: [],
  exports: [],
  imports: [
    TypeOrmModule.forFeature([EmpregadoRepositoryORM, UsuarioRepositoryORM, PermissaoRepositoryORM, DominioRepositoryORM]),
    UsuarioModule,
  ],
  providers: [],
})
export class LoginModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoginMiddleware).forRoutes('*');
  }
}
