export enum Operacao {
  ALOCAR = 'ALOCAR',
  EDITAR = 'EDITAR',
  CUSTOS = 'CUSTOS',
}
