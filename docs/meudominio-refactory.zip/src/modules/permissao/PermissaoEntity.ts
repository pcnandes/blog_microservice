import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsArray, IsNotEmptyObject, IsUUID } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Empregado } from '../empregado/EmpregadoEntity';
import { Operacao } from './Operacao';

@Entity()
export class Permissao {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional()
  public readonly pk?: string;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'usuario', referencedColumnName: 'cpf' })
  @ApiProperty({ type: () => Empregado })
  @IsNotEmptyObject({ message: 'Informe o empregado' })
  public readonly empregado?: Empregado;

  @ApiPropertyOptional()
  @Column({ name: 'dominio' })
  @IsUUID('4', { message: 'Informe o domínio' })
  public readonly dominioID?: string;

  @Column({ type: 'character varying', array: true })
  @ApiPropertyOptional()
  @IsArray()
  public readonly operacoes?: Operacao[];

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  constructor(example?: Example<Permissao>) {
    this.pk = example?.pk;
    this.empregado = example?.empregado ? new Empregado(example.empregado) : undefined;
    this.dominioID = example?.dominioID;
    this.versao = example?.versao;
    this.operacoes = example?.operacoes || [];
    ObjectUtils.removePropertiesUndefined(this);
  }

  public matches(dominioID: string, ...operacoes: Operacao[]): boolean {
    if (!!dominioID && !this.dominioID) {
      throw new Error('[Permissao].dominioID não carregado');
    }
    return (!dominioID || dominioID === this.dominioID) && (this.operacoes || []).some(operacao => operacoes.includes(operacao));
  }
}
