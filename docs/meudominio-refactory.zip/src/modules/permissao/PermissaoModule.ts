import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '../../common/CommonModule';
import { PermissaoRepository } from '../permissao/PermissaoRepository';
import { PermissaoRepositoryORM } from '../permissao/PermissaoRepositoryORM';
import { PermissaoService } from '../permissao/PermissaoService';
import { DominioModule } from './../dominio/DominioModule';
import { EmpregadoModule } from './../empregado/EmpregadoModule';
import { PermissaoREST } from './PermissaoREST';

@Module({
  controllers: [PermissaoREST],
  exports: [PermissaoService, PermissaoRepository],
  imports: [TypeOrmModule.forFeature([PermissaoRepositoryORM]), EmpregadoModule, DominioModule, CommonModule],
  providers: [PermissaoService, PermissaoRepository],
})
export class PermissaoModule {}
