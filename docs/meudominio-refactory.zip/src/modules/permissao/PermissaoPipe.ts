import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { validate } from 'class-validator';
import { difference } from 'lodash';
import { DominioRepository } from '../dominio/DominioRepository';
import { EmpregadoRepository } from '../empregado/EmpregadoRepository';
import { Permissao } from '../permissao/PermissaoEntity';

@Injectable()
export class PermissaoPipe implements PipeTransform<any, Promise<Permissao[]>> {
  constructor(protected readonly dominioRepository: DominioRepository, protected readonly empregadoRepository: EmpregadoRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Permissao[]> {
    const permissoes: Permissao[] = value.map(item => new Permissao(item));
    const errors = (await Promise.all(permissoes.map(p => validate(p)))).reduce((acc, item) => acc.concat(item), []);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
    this.validaAmbiguas(...permissoes);
    await this.validaEmpregados(...permissoes);
    await this.validaDominios(...permissoes);
    return permissoes;
  }

  private async validaEmpregados(...permissoes: Permissao[]): Promise<void> {
    const empregados = [...new Set(permissoes.map(p => p.empregado.cpf))];
    const existentes = (await this.empregadoRepository.findManyByCPF(empregados, 'cpf')).map(e => e.cpf);
    const inexistentes = difference(empregados, existentes);
    if (inexistentes.length > 0) {
      throw new BadRequestException('CPF não encontrados: ' + inexistentes.join(', '));
    }
  }

  private async validaDominios(...permissoes: Permissao[]): Promise<void> {
    const dominios = [...new Set(permissoes.map(p => p.dominioID))];
    const existentes = (await this.dominioRepository.findManyById(dominios, 'id')).map(d => d.id);
    const inexistentes = difference(dominios, existentes);
    if (inexistentes.length > 0) {
      throw new BadRequestException('Domínios não encontrados: ' + inexistentes.join(', '));
    }
  }

  private validaAmbiguas(...permissoes: Permissao[]) {
    for (let i = 0; i < permissoes.length - 1; i++) {
      for (let j = i + 1; j < permissoes.length; j++) {
        const a = permissoes[i];
        const b = permissoes[j];
        if (a.empregado.cpf === b.empregado.cpf && a.dominioID === b.dominioID) {
          throw new BadRequestException(`Não é permitido mais de um registro para o mesmo empregado e domínio`);
        }
      }
    }
  }
}
