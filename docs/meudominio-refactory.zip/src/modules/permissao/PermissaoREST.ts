import { Body, Controller, Get, Param, ParseUUIDPipe, Put } from '@nestjs/common';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiParam, ApiProduces, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { Permissao } from './PermissaoEntity';
import { PermissaoPipe } from './PermissaoPipe';
import { PermissaoService } from './PermissaoService';

@Controller('permissao')
@ApiTags('Permissão')
@ApiBearerAuth()
export class PermissaoREST {
  constructor(private readonly service: PermissaoService) {}

  @Get('dominio/:dominioID')
  @Authenticated()
  @ApiOperation({ summary: 'Busca permissões por domínio' })
  @ApiParam({ name: 'dominioID', description: 'ID do domínio', required: true })
  @ApiResponse({ status: 200, type: Permissao, isArray: true, description: 'Lista de permissões para o domínio' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json')
  public async buscarPorDominio(@Param('dominioID', ParseUUIDPipe) dominioID: string): Promise<Permissao[]> {
    return this.service.findManyByDominio(dominioID);
  }

  @Put('dominio/:dominioID')
  @Authenticated()
  @ApiOperation({ summary: 'Altera as permissões de um domínio' })
  @ApiParam({ name: 'dominioID', description: 'ID do domínio', required: true })
  @ApiBody({ description: 'Lista de permissões', type: Permissao, isArray: true })
  @ApiResponse({ status: 204, description: 'Perfis e permissões alteradas com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 400, description: 'Alguma informação está incorreta' })
  @ApiConsumes('application/json')
  public async salvarPorDominio(
    @Param('dominioID', ParseUUIDPipe) dominioID: string,
    @Body(PermissaoPipe) permissoes: Permissao[],
  ): Promise<void> {
    return this.service.alterarPermissoesPorDominio(dominioID, ...permissoes);
  }
}
