import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from '../../common/security/SecurityContext';
import { Permissao } from './PermissaoEntity';
import { PermissaoRepositoryORM } from './PermissaoRepositoryORM';

@Injectable()
export class PermissaoRepository extends RepositoryAuditable<Permissao> {
  constructor(repository: PermissaoRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findManyByEmpregado(cpf: string): Promise<Permissao[]> {
    return this.findAll('*-dominio-empregado.cpf', (builder: Where) => {
      builder.andWhere('permissao_empregado.cpf = :cpf', { cpf });
    });
  }

  public async findManyByDominio(dominioID: string): Promise<Permissao[]> {
    return this.findAll('*-dominio-empregado.cpf', (builder: Where) => {
      builder.andWhere('permissao.dominio = :dominioID', { dominioID });
    });
  }
}
