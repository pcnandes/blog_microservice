import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { differenceWith, intersectionWith, isEqual } from 'lodash';
import { CacheAdapter } from '../../common/cache/CacheAdapterRedis';
import { SecurityContext } from './../../common/security/SecurityContext';
import { Permissao } from './PermissaoEntity';
import { PermissaoRepository } from './PermissaoRepository';

@Injectable()
export class PermissaoService {
  constructor(
    private readonly repositoryPermissao: PermissaoRepository,
    private readonly security: SecurityContext,
    private readonly cache: CacheAdapter,
  ) {}

  public async alterarPermissoesPorEmpregado(cpf: string, ...permissoes: Permissao[]): Promise<void> {
    permissoes.forEach(p => {
      if (p.empregado.cpf !== cpf) {
        throw new BadRequestException('Existem permissões de empregados diferentes');
      }
    });
    const antigas = await this.repositoryPermissao.findManyByEmpregado(cpf);
    return this.alterarPermissoes(antigas, permissoes);
  }

  public async alterarPermissoesPorDominio(dominioID: string, ...permissoes: Permissao[]): Promise<void> {
    permissoes.forEach(p => {
      if (p.dominioID !== dominioID) {
        throw new BadRequestException('Existem permissões de domínios diferentes');
      }
    });
    const antigas = await this.repositoryPermissao.findManyByDominio(dominioID);
    return this.alterarPermissoes(antigas, permissoes);
  }

  public async findManyByEmpregado(cpf: string): Promise<Permissao[]> {
    return this.repositoryPermissao.findManyByEmpregado(cpf);
  }

  public async findManyByDominio(dominioID: string): Promise<Permissao[]> {
    return this.repositoryPermissao.findManyByDominio(dominioID);
  }

  private async alterarPermissoes(antes: Permissao[], depois: Permissao[]) {
    this.verificaAcesso(...antes, ...depois);
    depois = this.mapearPK(antes, depois);
    const incluidas = this.obterPermissoesIncluidas(antes, depois);
    const alteradas = this.obterPermissoesAlteradas(antes, depois);
    const excluidas = this.obterPermissoesExcluidas(antes, depois);
    await Promise.all([
      this.repositoryPermissao.insertAll(...incluidas),
      this.repositoryPermissao.updateAll(...alteradas),
      this.repositoryPermissao.deleteAll(...excluidas.map(p => p.pk)),
    ]);
    this.cache.hdel('USUARIO', ...new Set(antes.concat(depois).map(p => p.empregado.cpf)));
  }

  private verificaAcesso(...permissoes: Permissao[]) {
    const usuario = this.security.getRequestUser();
    const dominios = [...new Set(permissoes.map(p => p.dominioID))];
    dominios.forEach(dominioID => {
      if (!usuario.podeAlterarDominio(dominioID)) {
        throw new ForbiddenException('Você não pode alterar as permissões do domínio');
      }
    });
  }

  private mapearPK(antes: Permissao[], depois: Permissao[]): Permissao[] {
    return depois.map(d => {
      const existente = antes.filter(a => a.dominioID === d.dominioID && a.empregado.cpf === d.empregado.cpf).pop();
      return new Permissao({ ...d, pk: existente?.pk });
    });
  }

  private obterPermissoesIncluidas(antes: Permissao[], depois: Permissao[]): Permissao[] {
    return depois.filter(p => !p.pk && p.operacoes?.length > 0);
  }

  private obterPermissoesAlteradas(antes: Permissao[], depois: Permissao[]): Permissao[] {
    return intersectionWith(depois, antes, (a, b) => a.pk === b.pk && !isEqual(a.operacoes, b.operacoes) && a.operacoes?.length > 0);
  }

  private obterPermissoesExcluidas(antes: Permissao[], depois: Permissao[]): Permissao[] {
    return differenceWith(antes, depois, (a, b) => a.pk === b.pk).concat(depois.filter(p => !!p.pk && !p.operacoes?.length));
  }
}
