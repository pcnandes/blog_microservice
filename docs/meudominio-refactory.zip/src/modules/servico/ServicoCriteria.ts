import { BooleanPipe } from './../../common/pipes/BooleanPipe';
import { Allow } from 'class-validator';
import { Where } from '../../common/query/Where';
import { Criteria } from '../../common/repository/Criteria';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';

export class ServicoCriteria implements Criteria {
  @Allow()
  public readonly codigo?: number[];
  @Allow()
  public readonly ug?: string;
  @Allow()
  public readonly cliente?: string;
  @Allow()
  public readonly ativo?: boolean;
  @Allow()
  public readonly padrao?: boolean;
  @Allow()
  public readonly titulo?: string;

  constructor(example?: Example<ServicoCriteria>) {
    this.codigo = example?.codigo ? `${example.codigo.toString()}`.split(/[-,]/).map(v => parseInt(v, 10)) : undefined;
    this.ativo = BooleanPipe.parse(example?.ativo);
    this.padrao = BooleanPipe.parse(example?.padrao);
    this.ug = example?.ug;
    this.cliente = example?.cliente;
    this.titulo = example?.titulo;
    ObjectUtils.removePropertiesUndefined(this);
  }

  toWhere(): Where {
    const where = new Where();
    if (this.codigo?.length > 0) {
      where.andWhere('servico.codigo IN (:...codigo)', { codigo: this.codigo });
    }
    if (this.ug) {
      where.andWhere('servico.ug = :ug', { ug: this.ug.toUpperCase() });
    }
    if (this.cliente) {
      where.andWhere('servico.cliente ILIKE :cliente', { cliente: `%${this.cliente}%` });
    }
    if (this.ativo === true) {
      where.andWhere('servico.dataDesativacao IS NULL');
    }
    if (this.ativo === false) {
      where.andWhere('servico.dataDesativacao IS NOT NULL');
    }
    if (this.padrao === true) {
      where.andWhere('servico.padrao = true');
    }
    if (this.padrao === false) {
      where.andWhere('servico.padrao = false');
    }
    if (this.titulo) {
      where.andWhere(`(COALESCE(servico.mnemonico,'') ILIKE :titulo OR COALESCE(servico.titulo,'') ILIKE :titulo)`, {
        titulo: `%${this.titulo}%`,
      });
    }
    return where;
  }
}
