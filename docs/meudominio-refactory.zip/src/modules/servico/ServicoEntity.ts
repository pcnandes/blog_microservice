import { ApiPropertyOptional } from '@nestjs/swagger';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn, UpdateDateColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Empregado } from '../empregado/EmpregadoEntity';

@Entity()
export class Servico {
  @PrimaryColumn()
  @ApiPropertyOptional()
  public readonly codigo: number;

  @Column()
  @ApiPropertyOptional()
  public readonly padrao?: boolean;

  @Column()
  @ApiPropertyOptional()
  public readonly ug?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly cliente?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly mnemonico?: string;

  @Column()
  @ApiPropertyOptional()
  public readonly compartilhado?: boolean;

  @Column()
  @ApiPropertyOptional()
  public readonly titulo?: string;

  @UpdateDateColumn({ name: 'data_desativacao' })
  @ApiPropertyOptional({ type: 'string', format: 'date', example: '2018-11-21' })
  public readonly dataDesativacao?: Date;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'gestor_tecnico', referencedColumnName: 'matricula' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly gestorTecnico?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'gestor_negocio', referencedColumnName: 'matricula' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly gestorNegocio?: Empregado;

  @ManyToOne(type => Empregado)
  @JoinColumn({ name: 'gestor_servico', referencedColumnName: 'matricula' })
  @ApiPropertyOptional({ type: () => Empregado })
  public readonly gestorServico?: Empregado;

  public get ativo() {
    if (this.dataDesativacao === undefined) {
      throw new Error('[Servico].dataDesativacao não carregado');
    }
    return !this.dataDesativacao;
  }

  constructor(example?: Example<Servico>) {
    this.codigo = example?.codigo;
    this.padrao = example?.padrao;
    this.ug = example?.ug;
    this.cliente = example?.cliente;
    this.mnemonico = example?.mnemonico;
    this.compartilhado = example?.compartilhado;
    this.titulo = example?.titulo;
    this.dataDesativacao = example?.dataDesativacao;
    this.gestorTecnico = example?.gestorTecnico ? new Empregado(example.gestorTecnico) : undefined;
    this.gestorNegocio = example?.gestorNegocio ? new Empregado(example.gestorNegocio) : undefined;
    this.gestorServico = example?.gestorServico ? new Empregado(example.gestorServico) : undefined;
    ObjectUtils.removePropertiesUndefined(this);
  }
}
