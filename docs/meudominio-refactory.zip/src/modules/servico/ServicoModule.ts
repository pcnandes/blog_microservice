import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '../../common/CommonModule';
import { ServicoRepository } from './ServicoRepository';
import { ServicoRepositoryORM } from './ServicoRepositoryORM';
import { ServicoREST } from './ServicoREST';

@Module({
  controllers: [ServicoREST],
  exports: [ServicoRepository],
  imports: [TypeOrmModule.forFeature([ServicoRepositoryORM]), CommonModule],
  providers: [ServicoRepository],
})
export class ServicoModule {}
