import { Controller, Get, Param, ParseIntPipe, Query, Res, NotFoundException } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Output } from '../../common/output/Output';
import { OutputJSON } from '../../common/output/OutputJSON';
import { ObjectPipe } from '../../common/pipes/ObjectPipe';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Sort } from '../../common/query/Sort';
import { Page } from '../../common/repository/Page';
import { Pageable } from '../../common/repository/Pageable';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { ServicoCriteria } from './ServicoCriteria';
import { Servico } from './ServicoEntity';
import { ServicoRepository } from './ServicoRepository';

@Controller('servico')
@ApiTags('Servico')
@ApiBearerAuth()
export class ServicoREST {
  constructor(private readonly repository: ServicoRepository) {}

  @Get(':codigo')
  @Authenticated()
  @ApiOperation({ summary: 'Busca servico pelo código' })
  @ApiParam({ name: 'codigo', description: 'Código de serviço', required: true, type: Number })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: Servico })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Código de serviço não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorCodigo(@Param('codigo', ParseIntPipe) codigo: number, @Query('fields') fields: string = '*'): Promise<Servico> {
    const servico = await this.repository.findOneById(codigo, fields);
    if (!servico) {
      throw new NotFoundException(`Cód. Serv. ${codigo} não encontrado`);
    }
    return servico;
  }

  @Get()
  @Authenticated()
  @ApiOperation({ summary: 'Obtém lista de serviços {PAGINADO}' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = codigo-ug', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'page', description: 'Número da página. Padrão = 1', required: false, type: Number })
  @ApiQuery({ name: 'size', description: 'Items por página. Padrão = 10', required: false, type: Number })
  @ApiQuery({ name: 'sort', description: 'Ordenação. Padrão = codigo', required: false })
  @ApiQuery({ name: 'codigo', description: 'Código de serviço. Pode ser passado mais de um separador por hífen', required: false })
  @ApiQuery({ name: 'ativo', description: 'Ativo', required: false, type: Boolean })
  @ApiQuery({ name: 'padrao', description: 'Padrão (MultiCliente)', required: false, type: Boolean })
  @ApiQuery({ name: 'ug', description: 'UG do Serviço', required: false })
  @ApiQuery({ name: 'cliente', description: 'Cliente', required: false })
  @ApiQuery({ name: 'titulo', description: 'Mnemônico ou Título', required: false })
  @ApiResponse({ status: 200, type: Page, description: 'Lista de servicos' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listar(
    @Res() response: Response,
    @Query('fields') fields: string = 'codigo-ug',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Query(ObjectPipe) criteria?: ServicoCriteria,
    @Query(ObjectPipe) pageable: Pageable = new Pageable({ pageNumber: 1, pageSize: 10, sort: Sort.by('codigo') }),
  ) {
    const servicos = await this.repository.findPage(pageable, fields, criteria);
    return output.ofPage(response, servicos);
  }
}
