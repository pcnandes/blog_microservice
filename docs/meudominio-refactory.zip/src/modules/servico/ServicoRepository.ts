import { Injectable } from '@nestjs/common';
import { RepositoryBase } from '../../common/repository/RepositoryBase';
import { Servico } from './ServicoEntity';
import { ServicoRepositoryORM } from './ServicoRepositoryORM';

@Injectable()
export class ServicoRepository extends RepositoryBase<Servico> {
  constructor(repository: ServicoRepositoryORM) {
    super(repository);
  }
}
