import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Servico } from './ServicoEntity';

@EntityRepository(Servico)
export class ServicoRepositoryORM extends BaseRepository<Servico> {}
