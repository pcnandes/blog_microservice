import { isUUID } from '@nestjs/common/utils/is-uuid';
import { Allow } from 'class-validator';
import { set } from 'lodash';
import { Where } from '../../common/query/Where';
import { Criteria } from '../../common/repository/Criteria';
import { ObjectUtils } from '../../common/utils/ObjectUtils';

export class SistemaCriteria implements Criteria {
  @Allow()
  public readonly dominio?: string;
  @Allow()
  public readonly subdominio?: string;
  @Allow()
  public readonly servico?: string;
  @Allow()
  public readonly ug?: string;
  @Allow()
  public readonly grupogovi?: string;
  @Allow()
  public readonly cliente?: string;
  @Allow()
  public readonly search?: string;

  constructor(example?: Partial<SistemaCriteria>) {
    this.grupogovi = example?.grupogovi;
    this.ug = example?.ug;
    this.servico = example?.servico;
    this.cliente = example?.cliente;
    this.dominio = example?.dominio;
    this.subdominio = example?.subdominio;
    this.search = example?.search;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public toWhere(): Where {
    const where = new Where();
    this.applyUG(where, this.ug);
    this.applySubDominio(where, this.subdominio);
    this.applyServico(where, this.servico);
    this.applyDominio(where, this.dominio);
    this.applyCliente(where, this.cliente);
    this.applySearch(where, this.search);
    this.applyGrupoGovi(where, this.grupogovi);
    return where;
  }

  private applyUG(where: Where, param: string, alias: string = 'ug') {
    if (param) {
      const args = set({}, alias, param.toUpperCase());
      where.andWhere(sub => {
        sub.orWhere(`sistema_subdominio_dominio.ugDominio = :${alias}`, args);
        sub.orWhere(`sistema_subdominio_dominio.ugNegocio = :${alias}`, args);
        sub.orWhere(`sistema_servicos_servico.ug = :${alias}`, args);
      });
      where.addJoin('servicos.servico');
      where.addJoin('subdominio.dominio');
    }
  }

  private applyGrupoGovi(where: Where, param: string, alias: string = 'grupogovi') {
    if (param) {
      where.andWhere(`ARRAY_TO_STRING(sistema_servicos.grupogovi, ',') ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('servicos');
    }
  }

  private applyDominio(where: Where, param: string, alias: string = 'dominio') {
    if (param) {
      if (isUUID(param, '4')) {
        where.andWhere(`sistema_subdominio_dominio.id = :${alias}`, set({}, alias, param));
      } else {
        where.andWhere(`sistema_subdominio_dominio.codigo = :${alias}`, set({}, alias, param));
      }
      where.addJoin('subdominio.dominio');
    }
  }

  private applySubDominio(where: Where, param: string, alias: string = 'subdominio') {
    if (param) {
      if (isUUID(param, '4')) {
        where.andWhere(`sistema_subdominio.id = :${alias}`, set({}, alias, param));
      } else {
        where.andWhere(`sistema_subdominio.codigo = :${alias}`, set({}, alias, param));
      }
      where.addJoin('subdominio');
    }
  }

  private applyServico(where: Where, param: string, alias: string = 'servico') {
    if (param) {
      if (param.match(/^[0-9]+$/)) {
        where.andWhere(`sistema_servicos_servico.codigo = :${alias}`, set({}, alias, parseInt(param, 10)));
      } else {
        where.andWhere(sub => {
          sub.orWhere(`sistema_servicos_servico.mnemonico ILIKE :${alias}`, set({}, alias, `%${param}%`));
          sub.orWhere(`sistema_servicos_servico.titulo ILIKE :${alias}`, set({}, alias, `%${param}%`));
        });
      }
      where.addJoin('servicos.servico');
    }
  }

  private applyCliente(where: Where, param: string, alias: string = 'cliente') {
    if (param) {
      where.andWhere(`sistema_servicos_servico.cliente ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('servicos.servico');
    }
  }

  private applySearch(where: Where, param: string) {
    if (param) {
      where.andWhere(sub => {
        sub.orWhere(`sistema.identificador ILIKE :search`, { search: `%${param}%` });
        sub.orWhere(`sistema.sigla ILIKE :search`, { search: `%${param}%` });
        sub.orWhere(`sistema.nome ILIKE :search`, { search: `%${param}%` });
        sub.orWhere(nth => this.applyUG(nth, param, 'searchUG'));
        sub.orWhere(nth => this.applyServico(nth, param, 'searchServico'));
        sub.orWhere(nth => this.applyCliente(nth, param, 'searchCliente'));
        sub.orWhere(nth => this.applyGrupoGovi(nth, param, 'searchGrupoGovi'));
      });
    }
    return null;
  }
}
