import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsArray, IsNotEmpty, Matches, ArrayMinSize, IsNotEmptyObject } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Example } from '../../common/utils/Types';
import { Dominio } from '../dominio/DominioEntity';
import { SubDominio } from '../subdominio/SubDominioEntity';
import { CategoriaDominio } from './../dominio/CategoriaDominio';
import { LinhaNegocio } from './LinhaNegocio';
import { SistemaServico } from './SistemaServicoEntity';
import { SituacaoSistema } from './SituacaoSistema';

@Entity()
export class Sistema {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional()
  public readonly id?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty({ message: 'Informe o identificador' })
  @Matches(/^[A-Z](?:[A-Z0-9-]{0,18}[A-Z0-9]){0,1}$/, { message: 'Identificador inválido' })
  public readonly identificador?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty({ message: 'Informe a sigla' })
  public readonly sigla?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty({ message: 'Informe o nome' })
  public readonly nome?: string;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly descricao?: string;

  @Column()
  @ApiPropertyOptional({ enum: SituacaoSistema })
  public readonly situacao?: SituacaoSistema;

  @Column({ name: 'linha_negocio' })
  @ApiPropertyOptional({ enum: LinhaNegocio })
  @IsNotEmpty({ message: 'Informe a linha de negócio' })
  public readonly linhaNegocio?: LinhaNegocio;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly producao?: boolean;

  @ManyToOne(
    type => SubDominio,
    subdominio => subdominio.sistemas,
  )
  @JoinColumn({ name: 'subdominio' })
  @ApiPropertyOptional({ type: () => SubDominio })
  @IsNotEmptyObject()
  public readonly subdominio?: SubDominio;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  @OneToMany(
    type => SistemaServico,
    servico => servico.sistema,
    { cascade: false },
  )
  @ApiPropertyOptional({ type: () => SistemaServico, isArray: true })
  @IsArray()
  @ArrayMinSize(1, { message: 'Informe algum código de serviço para o sistema' })
  public readonly servicos?: SistemaServico[];

  constructor(example?: Example<Sistema>) {
    this.id = example?.id;
    this.nome = example?.nome;
    this.descricao = example?.descricao;
    this.situacao = example?.situacao;
    this.versao = example?.versao;
    this.identificador = example?.identificador;
    this.linhaNegocio = example?.linhaNegocio;
    this.producao = example?.producao;
    this.sigla = example?.sigla;
    this.subdominio = example?.subdominio ? new SubDominio(example.subdominio) : undefined;
    this.servicos = example?.servicos ? example.servicos.map(srv => new SistemaServico(srv)) : undefined;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isProduto(): boolean {
    return !this.isSobMedida;
  }

  public get isProdutoDependente(): boolean {
    if (!this.isProduto) {
      return false;
    }
    if (!this.subdominio?.dominio?.categoria) {
      throw new Error('[Sistema].subdominio.dominio.categoria não carregado');
    }
    return this.subdominio.dominio.categoria !== CategoriaDominio.PRODUTO;
  }

  public get isProdutoIndependente(): boolean {
    return this.isProduto && !this.isProdutoDependente;
  }

  public get isSobMedida(): boolean {
    if (!this.linhaNegocio) {
      throw new Error('[Sistema].linhaNegocio não carregado');
    }
    return this.linhaNegocio === LinhaNegocio.SERVICO_SOB_MEDIDA;
  }

  public get servicoPrincipal(): SistemaServico {
    if (!this.servicos?.length) {
      throw new Error('[Sistema].servicos não carregado');
    }
    return this.servicos.filter(srv => srv.principal).pop();
  }

  public get servicoAdicional(): SistemaServico[] {
    if (!this.servicos?.length) {
      throw new Error('[Sistema].servicos não carregado');
    }
    return this.servicos.filter(srv => !srv.principal);
  }

  public get codigoServicoPrincipal(): number {
    return this.servicoPrincipal.codigo;
  }

  public get codigoServicoAdicional(): number[] {
    return this.servicoAdicional.map(srv => srv.codigo);
  }

  public get codigoServico(): number[] {
    if (!this.servicos?.length) {
      throw new Error('[Sistema].servicos.servico.codigo não carregado');
    }
    return this.servicos.map(srv => srv.codigo);
  }

  public get dominioID(): string {
    if (!this.dominio?.id) {
      throw new Error('[Sistema].subdominio.dominio.id não carregado');
    }
    return this.dominio.id;
  }

  public get dominio(): Dominio {
    if (!this.subdominio?.dominio) {
      throw new Error('[Sistema].subdominio.dominio não carregado');
    }
    return this.subdominio.dominio;
  }

  public toJSON(): any {
    const result: any = { ...this };
    if (this.servicos?.length && typeof this.servicos[0]?.servico?.codigo === 'number') {
      result.codigoServicoPrincipal = this.codigoServicoPrincipal;
      result.codigoServicoAdicional = this.codigoServicoAdicional;
    }
    return result;
  }
}
