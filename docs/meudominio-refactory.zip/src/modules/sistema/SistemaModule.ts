import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AlocacaoRateioRepository } from '../alocacao/AlocacaoRateioRepository';
import { AlocacaoRepositoryORM } from '../alocacao/AlocacaoRepositoryORM';
import { DominioModule } from '../dominio/DominioModule';
import { GrupoGoviModule } from '../grupogovi/GrupoGoviModule';
import { CommonModule } from './../../common/CommonModule';
import { AlocacaoRateioRepositoryORM } from './../alocacao/AlocacaoRateioRepositoryORM';
import { AlocacaoRateioService } from './../alocacao/AlocacaoRateioService';
import { AlocacaoRepository } from './../alocacao/AlocacaoRepository';
import { AlocacaoService } from './../alocacao/AlocacaoService';
import { DominioRepositoryORM } from './../dominio/DominioRepositoryORM';
import { GrupoGoviRepositoryORM } from './../grupogovi/GrupoGoviRepositoryORM';
import { ServicoModule } from './../servico/ServicoModule';
import { ServicoRepositoryORM } from './../servico/ServicoRepositoryORM';
import { SubDominioModule } from './../subdominio/SubDominioModule';
import { SistemaPipeAlterar } from './SistemaPipeAlterar';
import { SistemaPipeGrupoGovi } from './SistemaPipeGrupoGovi';
import { SistemaPipeInserir } from './SistemaPipeInserir';
import { SistemaPipeServico } from './SistemaPipeServico';
import { SistemaRepository } from './SistemaRepository';
import { SistemaRepositoryORM } from './SistemaRepositoryORM';
import { SistemaREST } from './SistemaREST';
import { SistemaService } from './SistemaService';
import { SistemaServicoRepository } from './SistemaServicoRepository';
import { SistemaServicoRepositoryORM } from './SistemaServicoRepositoryORM';
import { SistemaServicoService } from './SistemaServicoService';

@Module({
  controllers: [SistemaREST],
  exports: [SistemaService, SistemaRepository],
  imports: [
    TypeOrmModule.forFeature([
      SistemaRepositoryORM,
      SistemaServicoRepositoryORM,
      AlocacaoRepositoryORM,
      AlocacaoRateioRepositoryORM,
      GrupoGoviRepositoryORM,
      ServicoRepositoryORM,
      DominioRepositoryORM,
    ]),
    CommonModule,
    SubDominioModule,
    DominioModule,
    GrupoGoviModule,
    ServicoModule,
  ],
  providers: [
    SistemaService,
    SistemaRepository,
    SistemaServicoService,
    SistemaServicoRepository,
    SistemaPipeInserir,
    SistemaPipeAlterar,
    SistemaPipeServico,
    SistemaPipeGrupoGovi,
    AlocacaoRepository,
    AlocacaoRateioRepository,
    AlocacaoRateioService,
    AlocacaoService,
  ],
})
export class SistemaModule {}
