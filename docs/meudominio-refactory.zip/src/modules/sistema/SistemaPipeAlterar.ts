import { ArgumentMetadata, BadRequestException, Injectable, NotFoundException, PipeTransform } from '@nestjs/common';
import { isUUID } from '@nestjs/common/utils/is-uuid';
import { validate } from 'class-validator';
import { BooleanPipe } from './../../common/pipes/BooleanPipe';
import { Sistema } from './SistemaEntity';
import { SistemaRepository } from './SistemaRepository';
import { SistemaServico } from './SistemaServicoEntity';

@Injectable()
export class SistemaPipeAlterar implements PipeTransform<any, Promise<Sistema>> {
  constructor(protected readonly repositorySistema: SistemaRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Sistema> {
    if (!value.id || !isUUID(value.id)) {
      throw new BadRequestException('ID do sistema não informado');
    }
    const antigo = await this.repositorySistema.findOneById(value.id, 'identificador-situacao-subdominio.id');
    if (!antigo) {
      throw new NotFoundException();
    }
    const sistema = new Sistema({
      id: value.id,
      nome: value.nome,
      descricao: value.descricao,
      sigla: value.sigla,
      identificador: antigo.identificador,
      situacao: antigo.situacao,
      versao: value.versao,
      subdominio: antigo.subdominio,
      linhaNegocio: value.linhaNegocio,
      producao: BooleanPipe.parse(value.producao),
      servicos: (value.servicos || []).map(srv => new SistemaServico(srv)),
    });
    await this.validarSistema(sistema);
    return sistema;
  }

  protected async validarSistema(sistema: Sistema): Promise<void> {
    const errors = await validate(sistema);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
    const outro = await this.repositorySistema.findOneByIdentificador(sistema.identificador, 'id');
    if (outro && outro?.id !== sistema.id) {
      throw new BadRequestException('Existe outro sistema com o mesmo identificador');
    }
  }
}
