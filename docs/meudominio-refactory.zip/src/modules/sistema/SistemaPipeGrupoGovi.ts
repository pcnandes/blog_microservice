import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { GrupoGoviRepository } from '../grupogovi/GrupoGoviRepository';
import { Sistema } from './SistemaEntity';
import { SistemaServico } from './SistemaServicoEntity';
import { SistemaServicoRepository } from './SistemaServicoRepository';

@Injectable()
export class SistemaPipeGrupoGovi implements PipeTransform<Sistema, Promise<Sistema>> {
  constructor(
    protected readonly repositorySisServ: SistemaServicoRepository,
    protected readonly repositoryGrupoGovi: GrupoGoviRepository,
  ) {}

  async transform(value: Sistema, metadata?: ArgumentMetadata): Promise<Sistema> {
    const siglas = this.extrairSiglas(value.servicos);
    if (siglas.length > 0) {
      const grupos = await this.repositoryGrupoGovi.findManyBySigla(siglas, 'sigla-ug-situacao');
      siglas.forEach(sigla => {
        const grupo = grupos.filter(g => g.sigla === sigla).pop();
        if (!grupo) {
          throw new BadRequestException(`Grupo Govi ${sigla} não encontrado`);
        }
        if (!grupo.isDIDES || !grupo.ativo) {
          throw new BadRequestException(`${sigla} não é um grupo DIDES ativo`);
        }
      });
      await this.verificaGruposDuplicadosEntreServicos(value.id, value.servicos, siglas);
    }
    return new Sistema(value);
  }

  private extrairSiglas(servicos: SistemaServico[]): string[] {
    const siglas = [];
    servicos.forEach(srv => {
      if (srv.grupoGovi?.length > 0) {
        this.verificaGruposDuplicadosNoServico(srv);
        siglas.push(...srv.grupoGovi);
      }
    });
    return [...new Set(siglas)];
  }

  private verificaGruposDuplicadosNoServico(servico: SistemaServico) {
    for (let i = 0; i < servico.grupoGovi.length - 1; i++) {
      for (let j = i + 1; j < servico.grupoGovi.length; j++) {
        if (servico.grupoGovi[i] === servico.grupoGovi[j]) {
          throw new BadRequestException(`Grupo Govi ${servico.grupoGovi[i]} aparece repetido no cód. serv. ${servico.codigo}`);
        }
      }
    }
  }

  private async verificaGruposDuplicadosEntreServicos(sistemaID: string, servicos: SistemaServico[], siglas: string[]) {
    const outros = await this.repositorySisServ.findManyByGrupoGovi(siglas, 'grupogovi-sistema.(id-identificador)-servico.codigo');
    const all = servicos.filter(srv => srv.grupoGovi?.length > 0).concat(outros.filter(srv => srv.sistema.id !== sistemaID));
    all.forEach((a, i) => {
      a.grupoGovi.forEach(sigla => {
        for (let j = i + 1; j < all.length; j++) {
          const b = all[j];
          if (b.grupoGovi.includes(sigla)) {
            if (b.sistema) {
              throw new BadRequestException(`Grupo Govi ${sigla} está sendo usado em outro sistema (${b.sistema.identificador})`);
            } else {
              throw new BadRequestException(`Grupo Govi ${sigla} está sendo usado em mais de um cód. serv. (${a.codigo}, ${b.codigo})`);
            }
          }
        }
      });
    });
  }
}
