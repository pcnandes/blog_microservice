import { SituacaoSistema } from './SituacaoSistema';
import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { BooleanPipe } from './../../common/pipes/BooleanPipe';
import { Sistema } from './SistemaEntity';
import { SistemaPipeAlterar } from './SistemaPipeAlterar';
import { SistemaRepository } from './SistemaRepository';
import { SistemaServico } from './SistemaServicoEntity';
import { SubDominioRepository } from '../subdominio/SubDominioRepository';

@Injectable()
export class SistemaPipeInserir extends SistemaPipeAlterar implements PipeTransform<any, Promise<Sistema>> {
  constructor(repositorySistema: SistemaRepository, protected readonly repositorySubDominio: SubDominioRepository) {
    super(repositorySistema);
  }

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Sistema> {
    const sistema = new Sistema({
      nome: value.nome,
      descricao: value.descricao,
      sigla: value.sigla,
      identificador: value.identificador,
      situacao: SituacaoSistema.ATIVO,
      subdominio: value.subdominio,
      linhaNegocio: value.linhaNegocio,
      producao: BooleanPipe.parse(value.producao),
      servicos: (value.servicos || []).map(srv => new SistemaServico(srv)),
    });
    await super.validarSistema(sistema);
    const subdominio = await this.repositorySubDominio.findOneById(sistema.subdominio.id, 'id');
    if (!subdominio) {
      throw new BadRequestException('SubDomínio não existe');
    }
    return sistema;
  }
}
