import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { Servico } from '../servico/ServicoEntity';
import { ServicoRepository } from '../servico/ServicoRepository';
import { Sistema } from './SistemaEntity';
import { SistemaServico } from './SistemaServicoEntity';
import { SistemaServicoRepository } from './SistemaServicoRepository';

@Injectable()
export class SistemaPipeServico implements PipeTransform<Sistema, Promise<Sistema>> {
  constructor(protected readonly repositorySisServ: SistemaServicoRepository, protected readonly repositoryServico: ServicoRepository) {}

  async transform(value: Sistema, metadata?: ArgumentMetadata): Promise<Sistema> {
    const principais = value.servicos.filter(srv => srv.principal).length;
    if (principais === 0) {
      throw new BadRequestException('Nenhum cód. serv. principal informado');
    }
    if (principais > 1) {
      throw new BadRequestException('Mais de um cód. serv. principal informado');
    }
    const servicos = await this.mapearServicos(value.id, value.servicos);
    return new Sistema({
      ...value,
      servicos,
    });
  }

  protected async mapearServicos(sistemaID: string, sistemaServico: any[]): Promise<SistemaServico[]> {
    const codigos = this.extrairCodigosDeServico(sistemaServico);
    const existentes = await this.repositorySisServ.findManyByServico(codigos, 'sistema.(id-identificador)-servico.codigo-percentual');
    const servicos = await this.repositoryServico.findManyById(codigos, 'codigo-compartilhado-dataDesativacao');
    const sissrv = sistemaServico.map(sis => {
      const cod = sis.servico?.codigo;
      const srv = servicos.filter(s => s.codigo === cod).pop();
      const old = existentes.filter(s => s.codigo === cod && s.sistema.id === sistemaID).pop();
      const outro = existentes.filter(s => s.codigo === cod && s.sistema.id !== sistemaID && !srv?.compartilhado).pop();
      if (outro) {
        throw new BadRequestException(`O Cód. Serv. ${cod} está vinculado a outro sistema (${outro.sistema.identificador})`);
      }
      return this.mapearSistemaServico(sis, srv, old);
    });
    return sissrv;
  }

  private mapearSistemaServico(sis: any, srv?: Servico, old?: SistemaServico): SistemaServico {
    const cod = sis.servico?.codigo;
    if (typeof cod !== 'number') {
      throw new BadRequestException(`Cód. Serv. não informado`);
    }
    if (!srv) {
      throw new BadRequestException(`Cód. Serv. ${cod} não encontrado`);
    }
    if (sis.principal && !srv.ativo) {
      throw new BadRequestException(`Cód. Serv. ${cod} está inativo`);
    }
    const percentual = srv.compartilhado ? old?.percentual || 0 : 100;
    return new SistemaServico({ ...sis, percentual, id: old?.id });
  }

  private extrairCodigosDeServico(sistemaServico: any[]): number[] {
    const codigos = sistemaServico.map(s => s?.servico?.codigo).filter(s => typeof s === 'number');
    for (let i = 0; i < codigos.length - 1; i++) {
      for (let j = i + 1; j < codigos.length; j++) {
        if (codigos[i] === codigos[j]) {
          throw new BadRequestException(`Cód. Serv. ${codigos[i]} aparece mais de uma vez`);
        }
      }
    }
    return codigos;
  }
}
