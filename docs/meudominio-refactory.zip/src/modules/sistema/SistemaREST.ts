import { SistemaPipeGrupoGovi } from './SistemaPipeGrupoGovi';
import { SistemaPipeServico } from './SistemaPipeServico';
import { BadRequestException, Body, Controller, Delete, Get, Param, Post, Put, Query, Res } from '@nestjs/common';
import { isUUID } from '@nestjs/common/utils/is-uuid';
import { ApiBearerAuth, ApiBody, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { Output } from '../../common/output/Output';
import { ObjectPipe } from '../../common/pipes/ObjectPipe';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Page } from '../../common/repository/Page';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { HasRole } from '../../common/security/HasRoleDecorator';
import { Perfil } from '../usuario/Perfil';
import { OutputJSON } from './../../common/output/OutputJSON';
import { BooleanPipe } from './../../common/pipes/BooleanPipe';
import { Pageable } from './../../common/repository/Pageable';
import { SistemaCriteria } from './SistemaCriteria';
import { Sistema } from './SistemaEntity';
import { SistemaPipeAlterar } from './SistemaPipeAlterar';
import { SistemaPipeInserir } from './SistemaPipeInserir';
import { SistemaService } from './SistemaService';
import { PageablePipe } from '../../common/pipes/PageablePipe';

@Controller('sistema')
@ApiTags('Sistema')
@ApiBearerAuth()
export class SistemaREST {
  constructor(private readonly service: SistemaService) {}

  @Get(':identificacao')
  @ApiOperation({ summary: 'Obtém as informações de um sistema' })
  @ApiParam({ name: 'identificacao', description: 'ID ou Identificador do sistema', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: Sistema, description: 'Dados do sistema' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Sistema não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorIdentificadorOuId(
    @Param('identificacao') identificacao: string,
    @Query('fields') fields: string = '*',
  ): Promise<Sistema> {
    if (isUUID(identificacao)) {
      return this.service.findOneByID(identificacao, fields);
    } else {
      return this.service.findOneByIdentificador(identificacao, fields);
    }
  }

  @Get()
  @ApiOperation({ summary: 'Obtém uma lista de sistemas [PAGINADO]' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = id-identificador-nome', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'page', description: 'Número da página, começando em 1. Padrão = 1', required: false })
  @ApiQuery({ name: 'size', description: 'Items por página. Padrão = 10', required: false })
  @ApiQuery({ name: 'sort', description: 'Ordenação', required: false })
  @ApiQuery({ name: 'gestor', description: 'Busca pelo nome do gestor', required: false })
  @ApiQuery({ name: 'ug', description: 'Busca pela UG do sistema, de negócio ou do serviço', required: false })
  @ApiQuery({ name: 'sistema', description: 'Busca pelo identificador, sigla ou nome do sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Busca pelo código ou nome do serviço', required: false })
  @ApiQuery({ name: 'subsistema', description: 'Busca pelo nome do subsistema', required: false })
  @ApiQuery({ name: 'search', description: 'Busca por todos os critérios', required: false })
  @ApiResponse({ status: 200, type: Page, description: 'Lista de sistemas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listar(
    @Res() response: Response,
    @Query('fields') fields: string = 'id-identificador-nome',
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Query(PageablePipe) pageable: Pageable = new Pageable(),
    @Query(ObjectPipe) criteria?: SistemaCriteria,
  ) {
    output.ofPage(response, await this.service.findPage(pageable, fields, criteria), ['servicos']);
  }

  @Transactional()
  @Post()
  @HasRole(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)
  @ApiOperation({ summary: 'Inclui um novo sistema' })
  @ApiBody({ type: Sistema })
  @ApiResponse({ status: 201, description: 'Sistema criado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async inserir(@Res() response: Response, @Body(SistemaPipeInserir, SistemaPipeServico, SistemaPipeGrupoGovi) sistema: Sistema) {
    const id = await this.service.inserir(sistema);
    return response
      .status(201)
      .set({ 'Content-Type': 'text/plain' })
      .send(id);
  }

  @Transactional()
  @Put()
  @Authenticated()
  @ApiOperation({ summary: 'Altera um sistema existente' })
  @ApiBody({ type: Sistema })
  @ApiResponse({ status: 204, description: 'Sistema alterado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async alterar(@Res() response: Response, @Body(SistemaPipeAlterar, SistemaPipeServico, SistemaPipeGrupoGovi) sistema: Sistema) {
    await this.service.alterar(sistema);
    return response.status(204);
  }

  @Transactional()
  @Delete()
  @Authenticated()
  @ApiOperation({ summary: 'Exclui um ou mais sistemas' })
  @ApiBody({ type: String, isArray: true, description: 'Lista com os IDs dos sistemas a serem excluídos' })
  @ApiResponse({ status: 204, description: 'Sistemas excluídos com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async excluir(@Res() response: Response, @Body() sistemaID: string[]) {
    await this.service.excluir(...sistemaID);
    return response.status(204);
  }

  @Transactional()
  @Put(':subdominio')
  @Authenticated()
  @ApiOperation({ summary: 'Exclui um ou mais sistemas' })
  @ApiParam({ name: 'subdominio', description: 'ID ou código do sistema', required: true })
  @ApiQuery({ name: 'alocacoes', description: 'Indica se as alocações devam ser mantidas. Padrão = true', required: false })
  @ApiBody({ type: String, isArray: true, description: 'Lista com os IDs dos sistemas a serem excluídos' })
  @ApiResponse({ status: 204, description: 'Sistemas excluídos com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async mover(
    @Res() response: Response,
    @Param('subdominio') subdominio: string,
    @Query('alocacoes', BooleanPipe) manterAlocacoes: boolean = true,
    @Body() sistema: string[],
  ) {
    sistema.concat(subdominio).forEach(id => {
      if (!isUUID(id)) {
        throw new BadRequestException('UUID inválido');
      }
    });
    await this.service.mover(sistema, subdominio, manterAlocacoes);
    return response.status(204);
  }
}
