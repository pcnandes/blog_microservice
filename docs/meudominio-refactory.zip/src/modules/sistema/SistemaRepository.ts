import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { Sistema } from './SistemaEntity';
import { SistemaRepositoryORM } from './SistemaRepositoryORM';

@Injectable()
export class SistemaRepository extends RepositoryAuditable<Sistema> {
  constructor(repository: SistemaRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findOneByIdentificador(identificador: string, fields: string = '*'): Promise<Sistema> {
    return this.findOne(fields, (builder: Where) => {
      builder.andWhere('identificador = :identificador', { identificador });
    });
  }
}
