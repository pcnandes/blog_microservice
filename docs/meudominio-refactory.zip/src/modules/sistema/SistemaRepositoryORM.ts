import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Sistema } from './SistemaEntity';

@EntityRepository(Sistema)
export class SistemaRepositoryORM extends BaseRepository<Sistema> {}
