import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Page } from '../../common/repository/Page';
import { AlocacaoService } from '../alocacao/AlocacaoService';
import { CategoriaDominio } from '../dominio/CategoriaDominio';
import { Dominio } from '../dominio/DominioEntity';
import { SubDominioRepository } from '../subdominio/SubDominioRepository';
import { Pageable } from './../../common/repository/Pageable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { AlocacaoRateioService } from './../alocacao/AlocacaoRateioService';
import { SubDominio } from './../subdominio/SubDominioEntity';
import { SistemaCriteria } from './SistemaCriteria';
import { Sistema } from './SistemaEntity';
import { SistemaRepository } from './SistemaRepository';
import { SistemaServicoService } from './SistemaServicoService';

@Injectable()
export class SistemaService {
  constructor(
    private readonly repositorySistema: SistemaRepository,
    private readonly repositorySubDominio: SubDominioRepository,
    private readonly serviceServico: SistemaServicoService,
    private readonly security: SecurityContext,
    private readonly alocacaoService: AlocacaoService,
    private readonly alocacaoRateio: AlocacaoRateioService,
  ) {}

  public async findOneByIdentificador(identificador: string, fields: string = '*'): Promise<Sistema> {
    const sistema = await this.repositorySistema.findOneByIdentificador(identificador, fields);
    if (!sistema) {
      throw new NotFoundException();
    }
    return sistema;
  }

  public async findOneByID(id: string, fields: string = '*'): Promise<Sistema> {
    const sistema = await this.repositorySistema.findOneById(id, fields);
    if (!sistema) {
      throw new NotFoundException();
    }
    return sistema;
  }

  public async findPage(
    pageable: Pageable = new Pageable(),
    fields: string = 'id-codigo-nome',
    criteria?: SistemaCriteria,
  ): Promise<Page<Sistema>> {
    return this.repositorySistema.findPage(pageable, fields, criteria);
  }

  public async inserir(sistema: Sistema): Promise<string> {
    const subdominio = await this.repositorySubDominio.findOneById(sistema.subdominio.id, 'codigo-dominio.(id-codigo-ugDominio)');
    this.verificaPermissao(subdominio.dominio, 'incluir');
    const id = await this.repositorySistema.insert(sistema);
    await this.serviceServico.atualizarPorSistema(id, ...sistema.servicos);
    await this.alocacaoRateio.atualizarPorEscopo(subdominio.codigo, subdominio.dominio.codigo, subdominio.dominio.ugDominio);
    return id;
  }

  public async alterar(sistema: Sistema): Promise<void> {
    const antigo = await this.repositorySistema.findOneById(sistema.id, 'id-linhaNegocio-subdominio.(id-dominio.(id-categoria))');
    this.verificaPermissao(antigo.dominio, 'alterar');
    await this.repositorySistema.update(sistema);
    await this.serviceServico.atualizarPorSistema(sistema.id, ...sistema.servicos);
    if (antigo.isSobMedida && !sistema.isSobMedida) {
      this.alocacaoService.atualizarSubProcessos(new Sistema({ ...sistema, subdominio: antigo.subdominio }));
    }
  }

  public async excluir(...sistemaID: string[]): Promise<void> {
    const sistemas = await this.repositorySistema.findManyById(
      sistemaID,
      'id-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))-servicos.id',
    );
    sistemas.forEach(sis => {
      if (sis.subdominio.codigo !== sistemas[0].subdominio.codigo) {
        throw new BadRequestException('Não é permitido excluir sistemas de subdomínios diferentes');
      }
      this.verificaPermissao(sis.dominio, 'excluir');
    });
    const servicos = sistemas.reduce((acc, sis) => acc.concat(sis.servicos.map(srv => srv.id)), []);
    await this.alocacaoService.excluirPorSistema(...sistemaID);
    await this.serviceServico.deleteAll(...servicos);
    await this.repositorySistema.deleteAll(...sistemaID);
    await this.alocacaoRateio.atualizarPorEscopo(
      sistemas[0].subdominio.codigo,
      sistemas[0].subdominio.dominioCD,
      sistemas[0].subdominio.dominioUG,
    );
  }

  public async mover(sistemaID: string[], subdominioID: string, manterAlocacoes: boolean = true): Promise<void> {
    if (!sistemaID?.length) {
      return;
    }
    const sistemas = await this.repositorySistema.findManyById(sistemaID, '*-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))');
    const subdominio = await this.repositorySubDominio.findOneById(subdominioID, 'id-codigo-dominio.(codigo-categoria-ugDominio)');
    this.validaMovimentacao(sistemaID, sistemas, subdominio);
    const updates = sistemas.map(sis => new Sistema({ ...sis, subdominio }));
    await this.repositorySistema.updateAll(...updates);
    await this.alocacaoRateio.atualizarPorEscopo(
      ...new Set([
        subdominio.codigo,
        subdominio.dominio.codigo,
        subdominio.dominio.ugDominio,
        sistemas[0].subdominio.codigo,
        sistemas[0].dominio.codigo,
        sistemas[0].dominio.ugDominio,
      ]),
    );
    const categoriaAntes = sistemas[0].dominio.categoria;
    const categoriaDepois = subdominio.dominio.categoria;
    if ([categoriaAntes, categoriaDepois].includes(CategoriaDominio.PRODUTO) && categoriaAntes !== categoriaDepois) {
      await this.alocacaoService.atualizarSubProcessos(...updates);
    }
  }

  private validaMovimentacao(ids: string[], sistemas: Sistema[], subdominio: SubDominio) {
    if (ids.length !== sistemas.length) {
      throw new NotFoundException();
    }
    const subdominioAnterior = sistemas[0].subdominio;
    sistemas.forEach(sis => {
      if (sis.subdominio.id !== subdominioAnterior.id) {
        throw new BadRequestException('Há sistemas de subdomínios diferentes');
      }
      if (sis.isSobMedida && subdominio.dominio.categoria === CategoriaDominio.PRODUTO) {
        throw new BadRequestException('Não é permitido mover sistema sob medida para domínio do tipo produto');
      }
    });
    this.verificaPermissao(subdominioAnterior.dominio, 'mover');
    this.verificaPermissao(subdominio.dominio, 'mover');
  }

  private verificaPermissao(dominio: Dominio, operacao: string) {
    const usuario = this.security.getRequestUser();
    if (!usuario.podeAlterarDominio(dominio.id)) {
      throw new ForbiddenException(`Você não têm permissão para ${operacao} o sistema`);
    }
  }
}
