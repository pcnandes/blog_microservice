import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsBoolean, IsNotEmptyObject } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Servico } from '../servico/ServicoEntity';
import { Example } from './../../common/utils/Types';
import { Sistema } from './SistemaEntity';

@Entity()
export class SistemaServico {
  @ApiPropertyOptional()
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @Allow()
  public readonly id?: string;

  @ManyToOne(
    type => Sistema,
    sistema => sistema.servicos,
  )
  @ApiPropertyOptional({ type: () => Sistema })
  @JoinColumn({ name: 'sistema', referencedColumnName: 'id' })
  public readonly sistema?: Sistema;

  @ManyToOne(type => Servico)
  @JoinColumn({ name: 'servico', referencedColumnName: 'codigo' })
  @ApiPropertyOptional({ type: () => Servico })
  @IsNotEmptyObject()
  public readonly servico?: Servico;

  @Column({ name: 'grupogovi', type: 'character varying', array: true })
  @ApiPropertyOptional()
  @Allow()
  public readonly grupoGovi?: string[];

  @Column()
  @ApiPropertyOptional()
  @IsBoolean()
  public readonly principal?: boolean;

  @Column()
  @ApiPropertyOptional()
  public readonly percentual?: number;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  constructor(example?: Example<SistemaServico>) {
    this.id = example?.id;
    this.sistema = example?.sistema ? new Sistema(example.sistema) : undefined;
    this.servico = example?.servico ? new Servico(example.servico) : undefined;
    this.principal = example?.principal;
    this.percentual = example?.percentual;
    this.versao = example?.versao;
    this.grupoGovi = example?.grupoGovi;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get codigo(): number {
    if (typeof this.servico?.codigo !== 'number') {
      throw new Error('[SistemaServico].servico.codigo não carregado');
    }
    return this.servico.codigo;
  }

  public get ativo(): boolean {
    if (!this.servico) {
      throw new Error('[SistemaServico].servico.dataDesativacao não carregado');
    }
    return this.servico.ativo;
  }
}
