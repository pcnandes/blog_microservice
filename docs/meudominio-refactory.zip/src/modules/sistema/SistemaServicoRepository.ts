import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { SistemaServico } from './SistemaServicoEntity';
import { SistemaServicoRepositoryORM } from './SistemaServicoRepositoryORM';

@Injectable()
export class SistemaServicoRepository extends RepositoryAuditable<SistemaServico> {
  constructor(repository: SistemaServicoRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findManyBySistema(sistemaID: string | string[], fields: string = '*'): Promise<SistemaServico[]> {
    const param = Array.isArray(sistemaID) ? sistemaID : [sistemaID];
    if (param.length === 0) {
      return [];
    }
    return this.findAll(fields, (builder: Where) => {
      builder.andWhere('sistemaservico_sistema.id IN (:...sistemas)', { sistemas: param });
      builder.addJoin('sistema');
    });
  }

  public async findManyByGrupoGovi(siglas: string | string[], fields: string = '*'): Promise<SistemaServico[]> {
    const param = Array.isArray(siglas) ? siglas : [siglas];
    if (param.length === 0) {
      return [];
    }
    return this.findAll(fields, (builder: Where) => {
      builder.andWhere('sistemaservico.grupogovi && CAST(:siglas AS CHARACTER VARYING[])', { siglas: `{${param.join(',')}}` });
    });
  }

  public async findManyByServico(codigo: number | number[], fields: string = '*'): Promise<SistemaServico[]> {
    const param = Array.isArray(codigo) ? codigo : [codigo];
    if (param.length === 0) {
      return [];
    }
    return this.findAll(fields, (builder: Where) => {
      builder.andWhere('sistemaservico_servico.codigo IN (:...codigos)', { codigos: param });
      builder.addJoin('servico');
    });
  }
}
