import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { SistemaServico } from './SistemaServicoEntity';

@EntityRepository(SistemaServico)
export class SistemaServicoRepositoryORM extends BaseRepository<SistemaServico> {}
