import { Injectable } from '@nestjs/common';
import { differenceWith, intersectionWith, isEqual } from 'lodash';
import { ServicoRepository } from '../servico/ServicoRepository';
import { SistemaServico } from './SistemaServicoEntity';
import { SistemaServicoRepository } from './SistemaServicoRepository';

@Injectable()
export class SistemaServicoService {
  constructor(private readonly repositoryEntity: SistemaServicoRepository, private readonly repositoryServico: ServicoRepository) {}

  public async atualizarPorSistema(sistemaID: string, ...entidades: SistemaServico[]): Promise<void> {
    const existentes = await this.findManyBySistema(sistemaID, '*-sistema.id-servico.codigo');
    entidades = this.mapearPK(
      existentes,
      entidades.map(srv => new SistemaServico({ ...srv, sistema: { id: sistemaID } })),
    );
    const incluidas = this.obterPermissoesIncluidas(existentes, entidades);
    const alteradas = this.obterPermissoesAlteradas(existentes, entidades);
    const excluidas = this.obterPermissoesExcluidas(existentes, entidades);
    await Promise.all([
      this.repositoryEntity.insertAll(...incluidas),
      this.repositoryEntity.updateAll(...alteradas),
      this.repositoryEntity.deleteAll(...excluidas.map(p => p.id)),
    ]);
  }

  private mapearPK(antes: SistemaServico[], depois: SistemaServico[]): SistemaServico[] {
    return depois.map(d => {
      const existente = antes.filter(a => a.sistema.id === d.sistema.id && a.codigo === d.codigo).pop();
      return new SistemaServico({ ...d, id: existente?.id });
    });
  }

  private obterPermissoesIncluidas(antes: SistemaServico[], depois: SistemaServico[]): SistemaServico[] {
    return depois.filter(p => !p.id);
  }

  private obterPermissoesAlteradas(antes: SistemaServico[], depois: SistemaServico[]): SistemaServico[] {
    return intersectionWith(depois, antes, (a, b) => a.id === b.id && !isEqual(a, b));
  }

  private obterPermissoesExcluidas(antes: SistemaServico[], depois: SistemaServico[]): SistemaServico[] {
    return differenceWith(antes, depois, (a, b) => a.id === b.id);
  }

  public async findManyBySistema(sistemaID: string | string[], fields: string): Promise<SistemaServico[]> {
    return this.repositoryEntity.findManyBySistema(sistemaID, fields);
  }

  public async deleteAll(...ids: string[]): Promise<void> {
    return this.repositoryEntity.deleteAll(...ids);
  }
}
