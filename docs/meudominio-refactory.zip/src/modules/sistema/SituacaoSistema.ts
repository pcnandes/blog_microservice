export enum SituacaoSistema {
  ATIVO = 'ATIVO',
  INATIVO = 'INATIVO',
}
