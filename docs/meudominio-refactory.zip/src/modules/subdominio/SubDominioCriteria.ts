import { isUUID } from '@nestjs/common/utils/is-uuid';
import { Allow } from 'class-validator';
import { Where } from '../../common/query/Where';
import { Criteria } from '../../common/repository/Criteria';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { set } from 'lodash';

export class SubDominioCriteria implements Criteria {
  @Allow()
  public readonly sistema?: string;
  @Allow()
  public readonly servico?: string;
  @Allow()
  public readonly search?: string;
  @Allow()
  public readonly cliente?: string;
  @Allow()
  public readonly dominio?: string;
  @Allow()
  public readonly grupogovi?: string;

  constructor(example?: Partial<SubDominioCriteria>) {
    this.sistema = example?.sistema;
    this.servico = example?.servico;
    this.search = example?.search;
    this.cliente = example?.cliente;
    this.dominio = example?.dominio;
    this.grupogovi = example?.grupogovi;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public toWhere(): Where {
    const where = new Where();
    this.applySistema(where, this.sistema);
    this.applyServico(where, this.servico);
    this.applyCliente(where, this.cliente);
    this.applyDominio(where, this.dominio);
    this.applySearch(where, this.search);
    this.applyGrupoGovi(where, this.grupogovi);
    return where;
  }

  private applySistema(where: Where, param: string, alias: string = 'sistema') {
    if (param) {
      where.andWhere(sub => {
        const args = set({}, alias, `%${param}%`);
        sub.orWhere(`subdominio_sistemas.identificador ILIKE :${alias}`, args);
        sub.orWhere(`subdominio_sistemas.sigla ILIKE :${alias}`, args);
        sub.orWhere(`subdominio_sistemas.nome ILIKE :${alias}`, args);
      });
      where.addJoin('sistemas');
    }
  }

  private applyGrupoGovi(where: Where, param: string, alias: string = 'grupogovi') {
    if (param) {
      where.andWhere(`ARRAY_TO_STRING(subdominio_sistemas_servicos.grupogovi, ',') ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('sistemas.servicos');
    }
  }

  private applyServico(where: Where, param: string, alias: string = 'servico') {
    if (param) {
      if (param.match(/^[0-9]+$/)) {
        where.andWhere(`subdominio_sistemas_servicos_servico.codigo = :${alias}`, set({}, alias, parseInt(param, 10)));
      } else {
        where.andWhere(sub => {
          sub.orWhere(`subdominio_sistemas_servicos_servico.mnemonico ILIKE :${alias}`, set({}, alias, `%${param}%`));
          sub.orWhere(`subdominio_sistemas_servicos_servico.titulo ILIKE :${alias}`, set({}, alias, `%${param}%`));
        });
      }
      where.addJoin('sistemas.servicos.servico');
    }
  }

  private applyCliente(where: Where, param: string, alias: string = 'cliente') {
    if (param) {
      where.andWhere(`subdominio_sistemas_servicos_servico.cliente ILIKE :${alias}`, set({}, alias, `%${param}%`));
      where.addJoin('sistemas.servicos.servico');
    }
  }

  private applyDominio(where: Where, param: string, alias: string = 'dominio') {
    if (param) {
      if (isUUID(param, '4')) {
        where.andWhere(`subdominio_dominio.id = :${alias}`, set({}, alias, param));
      } else {
        where.andWhere(`subdominio_dominio.codigo = :${alias}`, set({}, alias, param));
      }
      where.addJoin('dominio');
    }
  }

  private applySearch(where: Where, param: string) {
    if (param) {
      where.andWhere(sub => {
        sub.orWhere(`subdominio.nome ILIKE :search`, { search: `%${param}%` });
        sub.orWhere(nth => this.applySistema(nth, param, 'searchSistema'));
        sub.orWhere(nth => this.applyServico(nth, param, 'searchServico'));
        sub.orWhere(nth => this.applyCliente(nth, param, 'searchCliente'));
        sub.orWhere(nth => this.applyGrupoGovi(nth, param, 'searchGrupoGovi'));
      });
    }
    return null;
  }
}
