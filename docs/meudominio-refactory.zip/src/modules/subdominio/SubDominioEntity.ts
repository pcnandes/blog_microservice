import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsNotEmpty, IsNotEmptyObject } from 'class-validator';
import { Column, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Dominio } from '../dominio/DominioEntity';
import { Sistema } from '../sistema/SistemaEntity';
import { SituacaoDominio } from './../dominio/SituacaoDominio';
import { Example } from '../../common/utils/Types';

@Entity({ name: 'subdominio' })
export class SubDominio {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional()
  public readonly id?: string;

  @ManyToOne(
    type => Dominio,
    dominio => dominio.subdominios,
  )
  @JoinColumn({ name: 'dominio' })
  @ApiPropertyOptional({ type: () => Dominio })
  @IsNotEmptyObject()
  public readonly dominio?: Dominio;

  @Column()
  @ApiPropertyOptional()
  public readonly codigo?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty({ message: 'Informe o nome do subdomínio' })
  public readonly nome: string;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly descricao?: string;

  @Column()
  @ApiPropertyOptional({ enum: SituacaoDominio })
  public readonly situacao: SituacaoDominio;

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  @OneToMany(
    type => Sistema,
    sistema => sistema.subdominio,
    { cascade: false },
  )
  @ApiPropertyOptional({ type: () => Sistema, isArray: true })
  public sistemas?: Sistema[];

  constructor(example?: Example<SubDominio>) {
    this.id = example?.id;
    this.codigo = example?.codigo;
    this.nome = example?.nome;
    this.descricao = example?.descricao;
    this.situacao = example?.situacao;
    this.versao = example?.versao;
    this.dominio = example?.dominio ? new Dominio(example.dominio) : undefined;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isAtivo(): boolean {
    if (!this.situacao) {
      throw new Error('[SubDominio].situacao não carregado');
    }
    if (this.situacao === SituacaoDominio.INATIVO) {
      return false;
    }
    if (!this.dominio) {
      throw new Error('[SubDominio].dominio não carregado');
    }
    return this.dominio.isAtivo;
  }

  public get dominioID(): string {
    if (!this.dominio?.id) {
      throw new Error('[SubDominio].dominio.id não carregado');
    }
    return this.dominio.id;
  }

  public get dominioCD(): string {
    if (!this.dominio?.codigo) {
      throw new Error('[SubDominio].dominio.codigo não carregado');
    }
    return this.dominio.codigo;
  }

  public get dominioUG(): string {
    if (!this.dominio?.ugDominio) {
      throw new Error('[SubDominio].dominio.ugDominio não carregado');
    }
    return this.dominio.ugDominio;
  }
}
