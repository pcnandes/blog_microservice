import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DominioModule } from '../dominio/DominioModule';
import { SubDominioRepositoryORM } from '../subdominio/SubDominioRepositoryORM';
import { CommonModule } from './../../common/CommonModule';
import { DominioRepositoryORM } from './../dominio/DominioRepositoryORM';
import { SubDominioRepository } from './SubDominioRepository';
import { SubDominioREST } from './SubDominioREST';
import { SubDominioService } from './SubDominioService';

@Module({
  controllers: [SubDominioREST],
  exports: [SubDominioService, SubDominioRepository],
  imports: [TypeOrmModule.forFeature([SubDominioRepositoryORM, DominioRepositoryORM]), CommonModule, DominioModule],
  providers: [SubDominioService, SubDominioRepository],
})
export class SubDominioModule {}
