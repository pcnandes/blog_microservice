import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform, NotFoundException } from '@nestjs/common';
import { validate } from 'class-validator';
import { SubDominio } from './SubDominioEntity';
import { SubDominioRepository } from './SubDominioRepository';
import { DominioRepository } from '../dominio/DominioRepository';

@Injectable()
export class SubDominioPipeAlterar implements PipeTransform<any, Promise<SubDominio>> {
  constructor(protected readonly repositorySubDominio: SubDominioRepository, protected readonly repositoryDominio: DominioRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<SubDominio> {
    const antigo = await this.repositorySubDominio.findOneById(value.id, 'codigo-situacao-dominio.id');
    if (!antigo) {
      throw new NotFoundException();
    }
    const subdominio = new SubDominio({
      id: antigo.id,
      nome: value.nome,
      descricao: value.descricao,
      situacao: antigo.situacao,
      codigo: antigo.codigo,
      versao: value.versao,
      dominio: antigo.dominio,
    });
    await this.validar(subdominio);
    return subdominio;
  }

  protected async validar(subdominio: SubDominio): Promise<void> {
    const dominio = subdominio.dominio?.id ? await this.repositoryDominio.findOneById(subdominio.dominio.id, 'id-codigo-situacao') : null;
    if (!dominio) {
      throw new BadRequestException('Domínio não encontrado');
    }
    if (!dominio.isAtivo) {
      throw new BadRequestException('Domínio inativo');
    }
    if (!subdominio.codigo?.match(new RegExp(`${dominio.codigo}-[0-9]{3}`))) {
      throw new BadRequestException('Código inválido');
    }
    const errors = await validate(subdominio);
    if (errors.length > 0) {
      const constraints = errors[0].constraints;
      const validations = Object.keys(constraints);
      throw new BadRequestException(constraints[validations[0]]);
    }
  }
}
