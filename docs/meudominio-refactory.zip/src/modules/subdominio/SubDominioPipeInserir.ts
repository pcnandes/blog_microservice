import { ArgumentMetadata, Injectable, PipeTransform } from '@nestjs/common';
import { SubDominio } from './SubDominioEntity';
import { SubDominioPipeAlterar } from './SubDominioPipeAlterar';
import { SubDominioRepository } from './SubDominioRepository';
import { SituacaoDominio } from '../dominio/SituacaoDominio';
import { DominioRepository } from '../dominio/DominioRepository';

@Injectable()
export class SubDominioPipeInserir extends SubDominioPipeAlterar implements PipeTransform<any, Promise<SubDominio>> {
  constructor(repositorySubDominio: SubDominioRepository, repositoryDominio: DominioRepository) {
    super(repositorySubDominio, repositoryDominio);
  }

  async transform(value: any, metadata?: ArgumentMetadata): Promise<SubDominio> {
    const codigo = !!value.dominio?.id ? await this.repositorySubDominio.findNextCodigo(value.dominio.id) : undefined;
    const subdominio = new SubDominio({
      situacao: SituacaoDominio.ATIVO,
      nome: value.nome,
      descricao: value.descricao,
      codigo,
      dominio: value.dominio?.id ? { id: value.dominio.id } : undefined,
    });
    await this.validar(subdominio);
    return subdominio;
  }
}
