import { Body, Controller, Get, Param, Post, Put, Query, Res } from '@nestjs/common';
import { isUUID } from '@nestjs/common/utils/is-uuid';
import { ApiBearerAuth, ApiBody, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { Output } from '../../common/output/Output';
import { ObjectPipe } from '../../common/pipes/ObjectPipe';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { SortPipe } from '../../common/pipes/SortPipe';
import { Sort } from '../../common/query/Sort';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { HasRole } from '../../common/security/HasRoleDecorator';
import { Perfil } from '../usuario/Perfil';
import { OutputJSON } from './../../common/output/OutputJSON';
import { SubDominioCriteria } from './SubDominioCriteria';
import { SubDominio } from './SubDominioEntity';
import { SubDominioPipeAlterar } from './SubDominioPipeAlterar';
import { SubDominioPipeInserir } from './SubDominioPipeInserir';
import { SubDominioService } from './SubDominioService';

@Controller('subdominio')
@ApiTags('SubDomínio')
@ApiBearerAuth()
export class SubDominioREST {
  constructor(private readonly service: SubDominioService) {}

  @Get(':identificacao')
  @ApiOperation({ summary: 'Obtém as informações de um subdomínio' })
  @ApiParam({ name: 'identificacao', description: 'ID ou código do subdomínio', required: true })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = *', required: false })
  @ApiResponse({ status: 200, type: SubDominio, description: 'Dados do subdomínio' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'SubDomínio não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorCodigoOuId(
    @Param('identificacao') identificacao: string,
    @Query('fields') fields: string = '*',
  ): Promise<SubDominio> {
    if (isUUID(identificacao)) {
      return this.service.findOneByID(identificacao, fields);
    } else {
      return this.service.findOneByCodigo(identificacao, fields);
    }
  }

  @Get()
  @ApiOperation({ summary: 'Obtém uma lista de subdomínios' })
  @ApiQuery({ name: 'fields', description: 'Campos a serem recuperados. Padrão = id-codigo-nome', required: false })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiQuery({ name: 'sort', description: 'Ordenação. Padrão = codigo', required: false })
  @ApiQuery({ name: 'sistema', description: 'Busca pelo identificador, sigla ou nome do sistema', required: false })
  @ApiQuery({ name: 'servico', description: 'Busca pelo código ou nome do serviço', required: false })
  @ApiQuery({ name: 'dominio', description: 'Busca pelo código ou ID do domínio', required: false })
  @ApiQuery({ name: 'search', description: 'Busca por todos os critérios', required: false })
  @ApiResponse({ status: 200, type: SubDominio, isArray: true, description: 'Lista de subdominios' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiProduces('application/json', 'text/csv')
  public async listar(
    @Res() response: Response,
    @Query('fields') fields: string = 'id-codigo-nome',
    @Query('sort', SortPipe) sort: Sort = Sort.by('codigo'),
    @Query('output', OutputPipe) output: Output = new OutputJSON(),
    @Query(ObjectPipe) criteria?: SubDominioCriteria,
  ) {
    output.ofList(response, await this.service.findMany(fields, criteria, sort), ['sistemas', 'sistemas.servicos']);
  }

  @Transactional()
  @Post()
  @HasRole(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)
  @ApiOperation({ summary: 'Inclui um novo subdomínio' })
  @ApiBody({ type: SubDominio })
  @ApiResponse({ status: 201, description: 'SubDomínio criado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async inserir(@Res() response: Response, @Body(SubDominioPipeInserir) subdominio: SubDominio) {
    await this.service.inserir(subdominio);
    return response
      .status(201)
      .set({ 'Content-Type': 'text/plain' })
      .send(subdominio.codigo);
  }

  @Transactional()
  @Put()
  @Authenticated()
  @ApiOperation({ summary: 'Altera um subdomínio existente' })
  @ApiBody({ type: SubDominio })
  @ApiResponse({ status: 204, description: 'SubDomínio alterado com sucesso' })
  @ApiResponse({ status: 400, description: 'Informações inválidas' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  public async alterar(@Res() response: Response, @Body(SubDominioPipeAlterar) subdominio: SubDominio) {
    await this.service.alterar(subdominio);
    return response.status(204);
  }
}
