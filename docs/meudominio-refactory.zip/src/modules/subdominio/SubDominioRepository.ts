import { isUUID } from '@nestjs/common/utils/is-uuid';
import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { SubDominio } from './SubDominioEntity';
import { SubDominioRepositoryORM } from './SubDominioRepositoryORM';

@Injectable()
export class SubDominioRepository extends RepositoryAuditable<SubDominio> {
  constructor(repository: SubDominioRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  /**
   * @param dominio ID ou Código do domínio
   */
  public async findManyByDominio(dominio: string, fields: string = '*'): Promise<SubDominio[]> {
    return this.findAll(fields, (builder: Where) => {
      if (isUUID(dominio)) {
        builder.andWhere('subdominio_dominio.id = :dominio', { dominio });
        builder.addJoin('dominio');
      } else {
        builder.andWhere('subdominio.codigo LIKE :dominio', { dominio: `${dominio}-%` });
      }
    });
  }

  public async findOneByCodigo(codigo: string, fields: string = '*'): Promise<SubDominio> {
    return this.findOne(fields, (builder: Where) => {
      builder.andWhere('codigo = :codigo', { codigo });
    });
  }

  /**
   * @param dominio ID ou Código do domínio
   */
  public async findNextCodigo(dominio: string): Promise<string> {
    const sql = isUUID(dominio)
      ? `SELECT '${dominio}-'||LPAD(CAST((CAST(COALESCE(MAX(SUBSTRING(codigo FROM 6)), '000') AS INTEGER) + 1) AS TEXT),3,'0') AS codigo FROM subdominio WHERE codigo LIKE ?`
      : `SELECT dom.codigo||'-'||LPAD(CAST((CAST(COALESCE(MAX(SUBSTRING(sub.codigo FROM 6)), '000') AS INTEGER) + 1) AS TEXT),3,'0') AS codigo FROM dominio dom LEFT JOIN subdominio sub ON dom.id=sub.dominio WHERE dom.id=?`;
    const arg = [isUUID(dominio) ? dominio : `${dominio}-%`];
    const [{ codigo }] = await this.repository.query(sql, arg);
    return codigo;
  }
}
