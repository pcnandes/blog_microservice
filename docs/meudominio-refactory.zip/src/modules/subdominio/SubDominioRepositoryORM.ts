import { EntityRepository } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { SubDominio } from './SubDominioEntity';

@EntityRepository(SubDominio)
export class SubDominioRepositoryORM extends BaseRepository<SubDominio> {}
