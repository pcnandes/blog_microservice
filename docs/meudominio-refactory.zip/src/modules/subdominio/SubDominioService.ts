import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Sort } from '../../common/query/Sort';
import { SecurityContext } from './../../common/security/SecurityContext';
import { SubDominioCriteria } from './SubDominioCriteria';
import { SubDominio } from './SubDominioEntity';
import { SubDominioRepository } from './SubDominioRepository';

@Injectable()
export class SubDominioService {
  constructor(private readonly repository: SubDominioRepository, private readonly security: SecurityContext) {}

  public async findOneByCodigo(codigo: string, fields: string = '*'): Promise<SubDominio> {
    const subdominio = await this.repository.findOneByCodigo(codigo, fields);
    if (!subdominio) {
      throw new NotFoundException();
    }
    return subdominio;
  }

  public async findOneByID(id: string, fields: string = '*'): Promise<SubDominio> {
    const subdominio = await this.repository.findOneById(id, fields);
    if (!subdominio) {
      throw new NotFoundException();
    }
    return subdominio;
  }

  public async findMany(
    fields: string = 'id-codigo-nome',
    criteria?: SubDominioCriteria,
    sort: Sort = Sort.by('codigo'),
  ): Promise<SubDominio[]> {
    return this.repository.findAll(fields, criteria, sort);
  }

  public async inserir(subdominio: SubDominio): Promise<string> {
    const usuario = this.security.getRequestUser();
    if (!usuario.podeAlterarDominio(subdominio.dominio.id)) {
      throw new ForbiddenException('Você não têm permissão para incluir um subdomínio ao domínio');
    }
    const id = await this.repository.insert(subdominio);
    return id;
  }

  public async alterar(subdominio: SubDominio): Promise<void> {
    const usuario = this.security.getRequestUser();
    if (!usuario.podeAlterarDominio(subdominio.dominio.id)) {
      throw new ForbiddenException('Você não têm permissão para alterar o subdomínio');
    }
    await this.repository.update(subdominio);
  }
}
