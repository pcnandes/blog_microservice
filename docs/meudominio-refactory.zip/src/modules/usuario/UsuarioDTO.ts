import { ApiPropertyOptional } from '@nestjs/swagger';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Empregado } from '../empregado/EmpregadoEntity';
import { Perfil } from './Perfil';
import { Usuario } from './UsuarioEntity';

export class UsuarioDTO {
  @ApiPropertyOptional()
  public id?: string;

  @ApiPropertyOptional()
  public username?: string;

  @ApiPropertyOptional()
  public perfis?: Perfil[];

  @ApiPropertyOptional({ type: () => Empregado })
  public empregado?: Empregado;

  constructor(from?: any) {
    this.id = from?.id;
    this.username = from?.username;
    this.perfis = from?.perfis;
    this.empregado = from?.empregado ? new Empregado(from.empregado) : undefined;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public static of(usuario: Usuario): UsuarioDTO {
    return new UsuarioDTO(usuario);
  }
}
