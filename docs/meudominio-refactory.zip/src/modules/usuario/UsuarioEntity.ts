import { ApiPropertyOptional } from '@nestjs/swagger';
import { Allow, IsArray, IsNotEmpty, IsNotEmptyObject, Matches } from 'class-validator';
import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { ObjectUtils } from '../../common/utils/ObjectUtils';
import { Empregado } from '../empregado/EmpregadoEntity';
import { Operacao } from '../permissao/Operacao';
import { Permissao } from '../permissao/PermissaoEntity';
import { Perfil } from './Perfil';
import { Example } from '../../common/utils/Types';

@Entity()
export class Usuario {
  @PrimaryGeneratedColumn({ type: 'uuid' })
  @ApiPropertyOptional()
  public readonly id?: string;

  @Column()
  @ApiPropertyOptional()
  @IsNotEmpty()
  @Matches(/^[0-9]{11}$/, { message: 'CPF inválido' })
  public readonly username?: string;

  @Column({ name: 'perfis', type: 'character varying', array: true })
  @ApiPropertyOptional()
  @Allow()
  @IsArray()
  public readonly perfis?: Perfil[];

  @Column()
  @ApiPropertyOptional()
  @Allow()
  public readonly versao?: number;

  @OneToOne(type => Empregado, { cascade: false, primary: true })
  @JoinColumn({ name: 'username', referencedColumnName: 'cpf' })
  @ApiPropertyOptional({ type: () => Empregado })
  @IsNotEmptyObject()
  public readonly empregado?: Empregado;

  @ApiPropertyOptional({ type: Permissao, isArray: true, description: 'Lista de permissões do usuário' })
  @Allow()
  public readonly permissoes?: Permissao[];

  @ApiPropertyOptional({ type: String, isArray: true, description: 'Lista de domínio ID em que o usuário é gestor' })
  public readonly gestorDominio?: string[];

  constructor(example?: Example<Usuario>) {
    this.empregado = example?.empregado ? new Empregado(example.empregado) : undefined;
    this.username = example?.username;
    this.gestorDominio = example?.gestorDominio;
    this.perfis = example?.perfis;
    this.id = example?.id;
    this.permissoes = example?.permissoes ? example.permissoes.map(p => new Permissao({ ...p, empregado: example?.empregado })) : undefined;
    this.versao = example?.versao;
    ObjectUtils.removePropertiesUndefined(this);
  }

  public get isEmpregado(): boolean {
    return !!this.empregado?.matricula;
  }

  public get isAdministrador(): boolean {
    return this.possuiPerfil(Perfil.ADMINISTRADOR);
  }

  public get isCadastradorDominio(): boolean {
    return this.possuiPerfil(Perfil.CADASTRADOR_DOMINIO);
  }

  public get isGestorAlocacao(): boolean {
    return this.possuiPerfil(Perfil.GESTOR_ALOCACAO);
  }

  public get isGestorAlgumDominio(): boolean {
    return this.gestorDominio?.length > 0;
  }

  public isGestorDoDominio(dominioID: string): boolean {
    return !!this.gestorDominio?.includes(dominioID);
  }

  public possuiPerfil(...perfil: Perfil[]): boolean {
    return !!this.perfis?.some(p => perfil.includes(p));
  }

  public possuiPermissao(dominioID?: string, ...operacao: Operacao[]) {
    return !!this.permissoes?.some(p => p.matches(dominioID, ...operacao));
  }

  public podeAlterarDominio(dominioID: string): boolean {
    return (
      this.isAdministrador ||
      this.isCadastradorDominio ||
      this.isGestorDoDominio(dominioID) ||
      this.possuiPermissao(dominioID, Operacao.EDITAR)
    );
  }

  public podeAlocarDominio(dominioID: string): boolean {
    return (
      this.isAdministrador || this.isGestorAlocacao || this.isGestorDoDominio(dominioID) || this.possuiPermissao(dominioID, Operacao.ALOCAR)
    );
  }

  public podeAlocarSuporte(): boolean {
    return (
      this.isAdministrador || this.isGestorAlocacao || this.isGestorAlgumDominio || (!!this.empregado?.isDIDES && !!this.empregado?.isChefe)
    );
  }
}
