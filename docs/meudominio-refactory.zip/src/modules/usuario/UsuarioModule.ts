import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonModule } from '../../common/CommonModule';
import { EmpregadoRepositoryORM } from '../empregado/EmpregadoRepositoryORM';
import { PermissaoRepositoryORM } from '../permissao/PermissaoRepositoryORM';
import { DominioModule } from './../dominio/DominioModule';
import { DominioRepositoryORM } from './../dominio/DominioRepositoryORM';
import { EmpregadoModule } from './../empregado/EmpregadoModule';
import { PermissaoModule } from './../permissao/PermissaoModule';
import { UsuarioRepository } from './UsuarioRepository';
import { UsuarioRepositoryORM } from './UsuarioRepositoryORM';
import { UsuarioREST } from './UsuarioREST';
import { UsuarioService } from './UsuarioService';

@Module({
  controllers: [UsuarioREST],
  exports: [UsuarioService, UsuarioRepository],
  imports: [
    TypeOrmModule.forFeature([UsuarioRepositoryORM, EmpregadoRepositoryORM, DominioRepositoryORM, PermissaoRepositoryORM]),
    EmpregadoModule,
    DominioModule,
    CommonModule,
    PermissaoModule,
  ],
  providers: [UsuarioService, UsuarioRepository],
})
export class UsuarioModule {}
