import { ArgumentMetadata, BadRequestException, Injectable, NotFoundException, PipeTransform } from '@nestjs/common';
import { validate } from 'class-validator';
import { Permissao } from '../permissao/PermissaoEntity';
import { EmpregadoRepository } from './../empregado/EmpregadoRepository';
import { Usuario } from './UsuarioEntity';

@Injectable()
export class UsuarioPipe implements PipeTransform<any, Promise<Usuario>> {
  constructor(protected readonly repositoryEmpregado: EmpregadoRepository) {}

  async transform(value: any, metadata?: ArgumentMetadata): Promise<Usuario> {
    const username = value.username || '';
    if (!username.match(/^[0-9]{11}$/)) {
      throw new BadRequestException('CPF inválido');
    }
    const empregado = await this.repositoryEmpregado.findOneByCPF(username, 'cpf-dataDesligamento');
    if (!empregado?.isAtivo) {
      throw new NotFoundException('Empregado não encontrado');
    }
    const usuario = new Usuario({
      username,
      id: value.id,
      empregado,
      perfis: value.perfis,
      versao: value.versao,
      permissoes: (value.permissoes || []).map(item => new Permissao({ ...item, empregado })),
    });
    const errors = await validate(usuario);
    if (errors.length > 0) {
      throw new BadRequestException();
    }
    return usuario;
  }
}
