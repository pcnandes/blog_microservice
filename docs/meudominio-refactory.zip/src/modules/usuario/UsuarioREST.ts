import { Body, Controller, Get, Param, Put, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiBody, ApiOperation, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { Transactional } from 'typeorm-transactional-cls-hooked';
import { Output } from '../../common/output/Output';
import { OutputJSON } from '../../common/output/OutputJSON';
import { OutputPipe } from '../../common/pipes/OutputPipe';
import { Authenticated } from '../../common/security/AuthenticatedDecorator';
import { HasRole } from '../../common/security/HasRoleDecorator';
import { Perfil } from './Perfil';
import { Usuario } from './UsuarioEntity';
import { UsuarioPipe } from './UsuarioPipe';
import { UsuarioService } from './UsuarioService';

@Controller('usuario')
@ApiTags('Usuário')
@ApiBearerAuth()
export class UsuarioREST {
  constructor(private readonly service: UsuarioService) {}

  @Get(':username')
  @Authenticated()
  @ApiOperation({ summary: 'Obtém as informações de um usuário' })
  @ApiParam({ name: 'username', description: 'CPF do usuário', required: true })
  @ApiResponse({ status: 200, type: Usuario, description: 'Dados do usuário' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 404, description: 'Usuário não encontrado' })
  @ApiProduces('application/json')
  public async buscarPorUsername(@Param('username') username: string): Promise<Usuario> {
    return this.service.buscarPorUsername(username);
  }

  @Get()
  @HasRole(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)
  @ApiOperation({ summary: 'Obtém a lista de usuários que possuem algum perfil' })
  @ApiResponse({ status: 200, type: Usuario, isArray: true, description: 'Lista de usuários' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiQuery({ name: 'output', description: 'Formato da resposta. Padrão = JSON', required: false })
  @ApiProduces('application/json', 'text/csv')
  public async listar(@Query('output', OutputPipe) output: Output = new OutputJSON(), @Res() response: Response) {
    return output.ofList(response, await this.service.listar());
  }

  @Transactional()
  @Put()
  @HasRole(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)
  @ApiOperation({ summary: 'Altera os perfis e permissões do usuário' })
  @ApiBody({ type: Usuario })
  @ApiResponse({ status: 204, description: 'Perfis e permissões alterados com sucesso' })
  @ApiResponse({ status: 401, description: 'Não autenticado' })
  @ApiResponse({ status: 403, description: 'Sem permissão' })
  @ApiResponse({ status: 404, description: 'Usuário não encontrado' })
  public async alterar(@Body(UsuarioPipe) usuario: Usuario): Promise<void> {
    return this.service.alterar(usuario);
  }
}
