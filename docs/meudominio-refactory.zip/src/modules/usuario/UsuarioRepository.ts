import { Injectable } from '@nestjs/common';
import { Where } from '../../common/query/Where';
import { RepositoryAuditable } from '../../common/repository/RepositoryAuditable';
import { SecurityContext } from './../../common/security/SecurityContext';
import { Usuario } from './UsuarioEntity';
import { UsuarioRepositoryORM } from './UsuarioRepositoryORM';

@Injectable()
export class UsuarioRepository extends RepositoryAuditable<Usuario> {
  constructor(repository: UsuarioRepositoryORM, security: SecurityContext) {
    super(repository, security);
  }

  public async findOneByUsername(username: string, fields: string = '*-empregado.*') {
    return this.findOne(fields, (builder: Where) => {
      builder.andWhere('username = :username', { username });
    });
  }
}
