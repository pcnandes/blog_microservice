import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Cached } from '../../common/cache/CachedDecorator';
import { CacheRemove } from '../../common/cache/CacheRemoveDecorator';
import { DominioRepository } from '../dominio/DominioRepository';
import { Permissao } from '../permissao/PermissaoEntity';
import { PermissaoService } from '../permissao/PermissaoService';
import { SecurityContext } from './../../common/security/SecurityContext';
import { EmpregadoRepository } from './../empregado/EmpregadoRepository';
import { Perfil } from './Perfil';
import { UsuarioDTO } from './UsuarioDTO';
import { Usuario } from './UsuarioEntity';
import { UsuarioRepository } from './UsuarioRepository';

@Injectable()
export class UsuarioService {
  constructor(
    private readonly repositoryUsuario: UsuarioRepository,
    private readonly repositoryEmpregado: EmpregadoRepository,
    private readonly repositoryDominio: DominioRepository,
    private readonly servicePermissao: PermissaoService,
    private readonly security: SecurityContext,
  ) {}

  @Cached('USUARIO', username => username, Usuario)
  public async buscarPorUsername(username: string): Promise<Usuario> {
    const isCPF = username.match(/^[0-9]{11}$/);
    if (isCPF) {
      const atributos = 'cpf-matricula-nome-lotacao-funcaoConfianca-ramal-email-dataDesligamento';
      const usuario = await this.repositoryUsuario.findOneByUsername(username, `*-empregado.(${atributos})`);
      const empregado = usuario?.empregado ? usuario.empregado : await this.repositoryEmpregado.findOneByCPF(username, atributos);
      if (!empregado || !empregado.isAtivo) {
        throw new NotFoundException('Empregado não encontrado');
      }
      const permissoes = isCPF ? await this.servicePermissao.findManyByEmpregado(username) : [];
      const gestorDominio = (isCPF ? await this.repositoryDominio.findManyByGestor(username, 'id') : []).map(dominio => dominio.id);
      return new Usuario({
        id: usuario?.id,
        username,
        empregado,
        permissoes,
        gestorDominio,
      });
    } else {
      return new Usuario({ username });
    }
  }

  public async listar(): Promise<UsuarioDTO[]> {
    const usuarios = await this.repositoryUsuario.findAll('*');
    return usuarios.map(u => UsuarioDTO.of(u));
  }

  @CacheRemove('USUARIO', ({ username }) => username)
  public async alterar(usuario: Usuario): Promise<void> {
    await this.validar(usuario);
    const possuiPerfis = usuario.perfis?.length > 0;
    if (usuario.id) {
      if (possuiPerfis) {
        await this.repositoryUsuario.update(usuario);
      } else {
        await this.repositoryUsuario.delete(usuario.id);
      }
    } else if (possuiPerfis) {
      await this.repositoryUsuario.insert(usuario);
    }
    await this.servicePermissao.alterarPermissoesPorEmpregado(
      usuario.username,
      ...(usuario.permissoes || []).map(p => new Permissao({ ...p, empregado: usuario.empregado })),
    );
  }

  private async validar(usuario: Usuario): Promise<void> {
    const logged = this.security.getRequestUser();
    if (!logged?.possuiPerfil(Perfil.ADMINISTRADOR, Perfil.CADASTRADOR_DOMINIO)) {
      throw new ForbiddenException('Você não pode alterar os perfis de outro usuário');
    }
    const antigo = await this.buscarPorUsername(usuario.username);
    if (usuario.id !== antigo.id) {
      throw new BadRequestException('Você não está com a versão mais atual do registro');
    }
    if (usuario.isAdministrador && !logged.isAdministrador && !antigo.isAdministrador) {
      throw new ForbiddenException('Você não pode atribuir o perfil Administrador');
    }
  }
}
