import 'jest';

import { mock } from 'jest-mock-extended';
import { RedisClient } from 'redis';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { CacheAdapter } from './../../../../src/common/cache/CacheAdapterRedis';

function callback(argIdx, value?, err?) {
  return (...args): boolean => {
    args[argIdx](err, value);
    return true;
  };
}

describe('unit/common/cache/CacheAdapterRedisTest', () => {
  const client = mock<RedisClient>();
  const adapter = new CacheAdapter(client);
  const grupo = 'USUARIO';
  const chave = '11122233300';
  const valor = new Empregado({ matricula: 123, nome: 'Zé Ruela', lotacao: 'Não Sei', funcaoConfianca: 'Big Boss' });

  beforeEach(() => {
    client.keys.mockClear();
    client.get.mockClear();
    client.set.mockClear();
    client.del.mockClear();
    client.hkeys.mockClear();
    client.hget.mockClear();
    client.hset.mockClear();
    client.hdel.mockClear();
    client.flushall.mockClear();
    client.expire.mockClear();
  });

  it('put', async () => {
    client.set.mockImplementation(callback(4));
    await adapter.put(chave, valor, 100);
    expect(client.set).toBeCalledTimes(1);
    expect(client.set).toBeCalledWith(chave, JSON.stringify(valor), 'EX', 100, expect.anything());
  });

  it('get', async () => {
    client.get.mockImplementation(callback(1, JSON.stringify(valor)));
    await expect(adapter.get(chave, Empregado)).resolves.toStrictEqual(valor);
    expect(client.get).toBeCalledTimes(1);
    expect(client.get).toBeCalledWith(chave, expect.anything());
  });

  it('del', async () => {
    client.del.mockImplementation(callback(1));
    await adapter.del(chave);
    expect(client.del).toBeCalledTimes(1);
    expect(client.del).toBeCalledWith([chave], expect.anything());
  });

  it('keys', async () => {
    const keys = ['abc', 'def', 'hij'];
    client.keys.mockImplementation(callback(1, keys));
    await expect(adapter.keys()).resolves.toStrictEqual(keys);
    expect(client.keys).toBeCalledTimes(1);
    expect(client.keys).toBeCalledWith('*', expect.anything());
  });

  it('hput', async () => {
    client.hset.mockImplementation(callback(3));
    await adapter.hput(grupo, chave, valor, 500);
    expect(client.hset).toBeCalledTimes(1);
    expect(client.hset).toBeCalledWith(grupo, chave, JSON.stringify(valor), expect.anything());
    expect(client.expire).toBeCalledTimes(1);
    expect(client.expire).toBeCalledWith(grupo, 500);
  });

  it('hget', async () => {
    client.hget.mockImplementation(callback(2, JSON.stringify(valor)));
    await expect(adapter.hget(grupo, chave, Empregado)).resolves.toStrictEqual(valor);
    expect(client.hget).toBeCalledTimes(1);
    expect(client.hget).toBeCalledWith(grupo, chave, expect.anything());
  });

  it('hdel', async () => {
    client.hdel.mockImplementation(callback(2));
    await adapter.hdel(grupo, chave);
    expect(client.hdel).toBeCalledTimes(1);
    expect(client.hdel).toBeCalledWith(grupo, [chave], expect.anything());
  });

  it('hkeys', async () => {
    const keys = ['abc', 'def', 'hij'];
    client.hkeys.mockImplementation(callback(1, keys));
    await expect(adapter.hkeys(grupo)).resolves.toStrictEqual(keys);
    expect(client.hkeys).toBeCalledTimes(1);
    expect(client.hkeys).toBeCalledWith(grupo, expect.anything());
  });

  it('clear', async () => {
    client.flushall.mockImplementation(callback(0));
    await adapter.clear();
    expect(client.flushall).toBeCalledTimes(1);
  });
});
