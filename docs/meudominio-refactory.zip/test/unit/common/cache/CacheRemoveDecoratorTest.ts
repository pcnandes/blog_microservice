import 'jest';

describe('unit/common/cache/CacheRemoveDecoratorTest', () => {
  it('dummy', async () => {
    expect(true).toStrictEqual(true);
  });
});
