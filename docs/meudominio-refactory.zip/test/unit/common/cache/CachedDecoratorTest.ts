import 'jest';

describe('unit/common/cache/CachedDecoratorTest', () => {
  it('dummy', async () => {
    expect(true).toStrictEqual(true);
  });
});
