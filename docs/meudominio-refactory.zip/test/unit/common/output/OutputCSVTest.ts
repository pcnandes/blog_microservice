import 'jest';

import { Page } from '../../../../src/common/repository/Page';
import { OutputCSV } from '../../../../src/common/output/OutputCSV';
import moment from 'moment';

const mockResponse = () => {
  const res: any = {};
  res.send = jest.fn().mockReturnValue(res);
  res.set = jest.fn().mockReturnValue(res);
  res.end = jest.fn().mockReturnValue(res);
  return res;
};

jest.mock('moment', () => {
  const mMoment = {
    format: jest.fn().mockReturnThis(),
    valueOf: jest.fn(),
  };
  return jest.fn(() => mMoment);
});

describe('unit/common/output/OutputCSV', () => {
  const output = new OutputCSV();
  const response = mockResponse();
  const content = [
    {
      codigo: '0001',
      nome: 'Dominio 01',
      gestorDominio: { nome: 'Fulano' },
      subdominios: [
        {
          codigo: '0001-001',
          sistemas: [{ identificador: 'Sistema 0001-001 A' }, { identificador: 'Sistema 0001-001 B' }],
        },
        {
          codigo: '0001-002',
          sistemas: [{ identificador: 'Sistema 0001-002 A' }, { identificador: 'Sistema 0001-002 B' }],
        },
        {
          codigo: '0001-003',
          sistemas: [{ identificador: 'Sistema 0001-003 A' }, { identificador: 'Sistema 0001-003 B' }],
        },
      ],
    },
    {
      codigo: '0002',
      nome: 'Dominio 02',
      gestorDominio: { nome: 'Cicrano' },
      subdominios: [{ codigo: '0002-001', sistemas: [{ identificador: 'Sistema 0002-001 X' }] }],
    },
  ];

  beforeEach(() => {
    response.send.mockClear();
    response.set.mockClear();
    response.end.mockClear();
    (moment().format as jest.MockedFunction<any>).mockReturnValueOnce('20180130T123456');
  });

  it('ofPage', () => {
    output.ofPage(response, Page.of(content, content.length, 1, 0));
    expect(response.set).toBeCalledTimes(1);
    expect(response.set).toBeCalledWith({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment;filename=meudominio_20180130T123456.csv`,
      'Page-ItemsPerPage': content.length,
      'Page-TotalPages': 1,
      'Page-TotalElements': content.length,
      'Page-Number': 1,
    });
    expect(response.send).toBeCalledTimes(1);
    expect(response.end).toBeCalledTimes(1);
  });

  it('ofList', () => {
    output.ofList(response, content, ['subdominios', 'subdominios.sistemas']);
    expect(response.set).toBeCalledTimes(1);
    expect(response.set).toBeCalledWith({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment;filename=meudominio_20180130T123456.csv`,
    });
    expect(response.send).toBeCalledTimes(1);
    expect(response.send).toBeCalledWith(
      '"codigo","nome","gestorDominio.nome","subdominios.codigo","subdominios.sistemas.identificador"\n' +
        '"0001","Dominio 01","Fulano","0001-001","Sistema 0001-001 A"\n' +
        '"0001","Dominio 01","Fulano","0001-001","Sistema 0001-001 B"\n' +
        '"0001","Dominio 01","Fulano","0001-002","Sistema 0001-002 A"\n' +
        '"0001","Dominio 01","Fulano","0001-002","Sistema 0001-002 B"\n' +
        '"0001","Dominio 01","Fulano","0001-003","Sistema 0001-003 A"\n' +
        '"0001","Dominio 01","Fulano","0001-003","Sistema 0001-003 B"\n' +
        '"0002","Dominio 02","Cicrano","0002-001","Sistema 0002-001 X"',
    );
    expect(response.end).toBeCalledTimes(1);
  });
});
