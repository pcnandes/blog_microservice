import 'jest';

import { BooleanPipe } from '../../../../src/common/pipes/BooleanPipe';

describe('unit/common/pipes/BooleanPipeTest', () => {
  const parser = new BooleanPipe();

  it('empty', () => {
    expect(parser.transform('')).toStrictEqual(true);
  });

  it('true string', () => {
    expect(parser.transform('true')).toStrictEqual(true);
  });

  it('false string', () => {
    expect(parser.transform('false')).toStrictEqual(false);
  });

  it('true boolean', () => {
    expect(parser.transform(true)).toStrictEqual(true);
  });

  it('false boolean', () => {
    expect(parser.transform(false)).toStrictEqual(false);
  });

  it('object', () => {
    expect(parser.transform({})).toStrictEqual(undefined);
  });

  it('null', () => {
    expect(parser.transform(null)).toStrictEqual(undefined);
  });

  it('undefined', () => {
    expect(parser.transform(undefined)).toStrictEqual(undefined);
  });
});
