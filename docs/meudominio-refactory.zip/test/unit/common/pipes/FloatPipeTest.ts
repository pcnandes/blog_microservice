import 'jest';

import { FloatPipe } from '../../../../src/common/pipes/FloatPipe';

describe('unit/common/pipes/FloatPipeTest', () => {
  const parser = new FloatPipe();

  it('empty', () => {
    expect(parser.transform('')).toStrictEqual(undefined);
  });

  it('int string', () => {
    expect(parser.transform('-567')).toStrictEqual(-567);
  });

  it('int number', () => {
    expect(parser.transform(567)).toStrictEqual(567);
  });

  it('float string', () => {
    expect(parser.transform('+0567.8')).toStrictEqual(567.8);
  });

  it('float number', () => {
    expect(parser.transform(567.8)).toStrictEqual(567.8);
  });

  it('object', () => {
    expect(parser.transform({})).toStrictEqual(undefined);
  });

  it('null', () => {
    expect(parser.transform(null)).toStrictEqual(undefined);
  });

  it('undefined', () => {
    expect(parser.transform(undefined)).toStrictEqual(undefined);
  });
});
