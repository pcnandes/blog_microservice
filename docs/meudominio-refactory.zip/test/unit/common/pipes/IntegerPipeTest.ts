import 'jest';

import { IntegerPipe } from '../../../../src/common/pipes/IntegerPipe';

describe('unit/common/pipes/IntegerPipeTest', () => {
  const parser = new IntegerPipe();

  it('empty', () => {
    expect(parser.transform('')).toStrictEqual(undefined);
  });

  it('int string', () => {
    expect(parser.transform('-0567')).toStrictEqual(-567);
  });

  it('int number', () => {
    expect(parser.transform(567)).toStrictEqual(567);
  });

  it('float number', () => {
    expect(parser.transform(567.8)).toStrictEqual(567);
  });

  it('object', () => {
    expect(parser.transform({})).toStrictEqual(undefined);
  });

  it('null', () => {
    expect(parser.transform(null)).toStrictEqual(undefined);
  });

  it('undefined', () => {
    expect(parser.transform(undefined)).toStrictEqual(undefined);
  });
});
