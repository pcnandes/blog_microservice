import 'jest';

import { OutputPipe } from '../../../../src/common/pipes/OutputPipe';
import { OutputJSON } from '../../../../src/common/output/OutputJSON';
import { OutputCSV } from '../../../../src/common/output/OutputCSV';

describe('unit/common/pipes/OutputPipeTest', () => {
  const parser = new OutputPipe();

  it('empty', () => {
    expect(parser.transform('')).toBeInstanceOf(OutputJSON);
  });

  it('csv', () => {
    expect(parser.transform('csv')).toBeInstanceOf(OutputCSV);
  });

  it('json', () => {
    expect(parser.transform('json')).toBeInstanceOf(OutputJSON);
  });

  it('invalid', () => {
    expect(() => parser.transform('xml')).toThrow('Formato inválido: xml');
  });

  it('null', () => {
    expect(parser.transform(null)).toBeInstanceOf(OutputJSON);
  });

  it('undefined', () => {
    expect(parser.transform(undefined)).toBeInstanceOf(OutputJSON);
  });
});
