import 'jest';

import { BadRequestException } from '@nestjs/common';
import { PageablePipe } from '../../../../src/common/pipes/PageablePipe';
import { Order } from '../../../../src/common/query/Order';
import { Pageable } from '../../../../src/common/repository/Pageable';
import { Sort } from './../../../../src/common/query/Sort';

describe('unit/common/pipes/PageablePipeTest', () => {
  const parser = new PageablePipe();

  it('empty', async () => {
    await expect(parser.transform({})).resolves.toStrictEqual(new Pageable());
  });

  it('invalido', async () => {
    await expect(parser.transform({ size: '-1', page: '-1' })).rejects.toThrow(BadRequestException);
  });

  it('sucesso', async () => {
    const pageable = await parser.transform({ size: '100', page: 5, sort: 'nome<' });
    expect(pageable.pageNumber).toStrictEqual(5);
    expect(pageable.pageSize).toStrictEqual(100);
    expect(pageable.sort).toStrictEqual(Sort.by(Order.desc('nome')));
  });
});
