import 'jest';

import { SortPipe } from '../../../../src/common/pipes/SortPipe';
import { Order } from '../../../../src/common/query/Order';
import { Sort } from '../../../../src/common/query/Sort';

describe('unit/common/pipes/SortPipeTest', () => {
  const parser = new SortPipe();

  it('asc', () => {
    expect(parser.transform('nome>', null)).toStrictEqual(Sort.by(Order.asc('nome')));
  });

  it('desc', () => {
    expect(parser.transform('nome<', null)).toStrictEqual(Sort.by(Order.desc('nome')));
  });

  it('multiple', () => {
    expect(parser.transform('nome-codigo<-sistema.nome', null)).toStrictEqual(
      Sort.by(Order.asc('nome'), Order.desc('codigo'), Order.asc('sistema.nome')),
    );
  });

  it('empty', () => {
    expect(parser.transform('', null)).toStrictEqual(undefined);
  });

  it('null', () => {
    expect(parser.transform(null, null)).toStrictEqual(undefined);
  });

  it('undefined', () => {
    expect(parser.transform(undefined, null)).toStrictEqual(undefined);
  });
});
