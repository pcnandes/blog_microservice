import 'jest';

import { mock } from 'jest-mock-extended';
import { set } from 'lodash';
import { EntityMetadata, SelectQueryBuilder, Brackets } from 'typeorm';
import { Query } from '../../../../src/common/query/Query';
import { Where } from '../../../../src/common/query/Where';
import { EntityType, metadata } from '../repository/Metadata';
import { Sort } from '../../../../src/common/query/Sort';

jest.mock('../../../../src/common/query/Where');

describe('unit/common/query/QueryTest', () => {
  const where = new Where() as jest.Mocked<Where>;
  const builder = mock<SelectQueryBuilder<EntityType>>();
  const alias = metadata.name.toLowerCase();
  set(builder, 'alias', alias);

  beforeEach(() => {
    builder.skip.mockClear();
    builder.take.mockClear();
    builder.where.mockClear();
    builder.select.mockClear();
    builder.orderBy.mockClear();
    builder.addOrderBy.mockClear();
    builder.addOrderBy.mockClear();
    builder.leftJoin.mockClear();
    builder.getSql.mockClear();
    builder.getManyAndCount.mockClear();
    builder.getMany.mockClear();
    builder.getOne.mockClear();
    where.getBrackets.mockClear();
    where.getJoins.mockClear();
    where.orWhere.mockClear();
    where.orWhereInIds.mockClear();
    where.andWhere.mockClear();
    where.andWhereInIds.mockClear();
  });

  it('getManyAndCount', async () => {
    const r1 = {};
    const r2 = {};
    const r3 = {};
    const brackets = null;
    builder.getManyAndCount.mockResolvedValue([[r1, r2, r3], 3]);
    where.getJoins.mockReturnValue([]);
    const query = new Query<EntityType>(builder, metadata as EntityMetadata);
    set(query, 'where', where);
    set(where, 'isEmpty', false);
    where.getBrackets.mockReturnValue(brackets);
    query
      .addSelect('codigo-nome-servico.mnemonico')
      .addSelect('sistemas.(sigla-dominio.*)')
      .andWhere('codigo = :cod', { cod: '0001' })
      .addJoin('sistemas')
      .addOrderBy(Sort.by('tipo.titulo'))
      .take(3)
      .skip(2);
    const [items, count] = await query.getManyAndCount();
    expect(count).toStrictEqual(3);
    expect(where.getBrackets).toBeCalledTimes(1);
    expect(where.getJoins).toBeCalledTimes(1);
    expect(where.andWhere).toBeCalledTimes(1);
    expect(where.andWhere).toBeCalledWith('codigo = :cod', { cod: '0001' });
    expect(builder.getManyAndCount).toBeCalledTimes(1);
    expect(builder.where).toBeCalledTimes(1);
    expect(builder.where).toBeCalledWith(brackets);
    expect(builder.leftJoin).toBeCalledTimes(3);
    expect(builder.skip).toBeCalledTimes(1);
    expect(builder.skip).toBeCalledWith(2);
    expect(builder.take).toBeCalledTimes(1);
    expect(builder.take).toBeCalledWith(3);
    expect(builder.select).toBeCalledTimes(1);
    expect(builder.select).toBeCalledWith([
      `${alias}.codigo`,
      `${alias}.nome`,
      `${alias}_servico.mnemonico`,
      `${alias}_servico.id`,
      `${alias}_sistemas.sigla`,
      `${alias}_sistemas_dominio.id`,
      `${alias}_sistemas_dominio.ug`,
      `${alias}_sistemas.identificador`,
      `${alias}_tipo.titulo`,
    ]);
  });
});
