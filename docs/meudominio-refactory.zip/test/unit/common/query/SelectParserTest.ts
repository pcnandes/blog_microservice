import 'jest';

import { SelectParser } from '../../../../src/common/query/SelectParser';

describe('unit/common/persistence/SelectParserTest', () => {
  it('*', () => {
    expect(SelectParser.parse('*')).toStrictEqual(['*']);
  });

  it('*-dominio.*', () => {
    expect(SelectParser.parse('*-dominio.*')).toStrictEqual(['*', 'dominio.*']);
  });

  it('id-dominio.codigo-descricao', () => {
    expect(SelectParser.parse('id-dominio.codigo-descricao')).toStrictEqual(['id', 'dominio.codigo', 'descricao']);
  });

  it('*-dominio.(id-codigo)', () => {
    expect(SelectParser.parse('*-dominio.(id-codigo)')).toStrictEqual(['*', 'dominio.(id-codigo)']);
  });

  it('id-codigo-subdominios.(sistemas.(servicos.(servico.*)))-gestorDominio.*-gestorNegocio.(nome)', () => {
    expect(
      SelectParser.parse('id-codigo-subdominios.(codigo-sistemas.(servicos.(principal-servico.*)))-gestorDominio.*-gestorNegocio.(nome)'),
    ).toStrictEqual([
      'id',
      'codigo',
      'subdominios.(codigo-sistemas.(servicos.(principal-servico.*)))',
      'gestorDominio.*',
      'gestorNegocio.(nome)',
    ]);
  });
});
