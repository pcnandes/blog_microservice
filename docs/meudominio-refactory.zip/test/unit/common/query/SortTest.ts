import 'jest';

import { Order } from '../../../../src/common/query/Order';
import { Sort } from '../../../../src/common/query/Sort';

describe('unit/common/query/SortTest', () => {
  it('sort', () => {
    const sort = new Sort();
    expect(sort.empty).toStrictEqual(true);
    expect(() => sort.sql).toThrowError('Ordenação vazia');
    sort.and('lotacao');
    expect(sort.empty).toStrictEqual(false);
    sort.and(Order.desc('nome'));
    expect(sort.sql).toStrictEqual('"lotacao" ASC NULLS LAST, "nome" DESC NULLS LAST');
  });
});
