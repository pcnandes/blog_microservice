import 'jest';

import { Where, WhereOperator } from '../../../../src/common/query/Where';

describe('unit/common/query/WhereTest', () => {
  it('isEmpty', () => {
    const where = new Where();
    expect(where.isEmpty).toStrictEqual(true);
    where.andWhere(sub => sub.andWhere(() => ({})));
    where.andWhere(() => ({}));
    where.andWhere(() => ({}));
    expect(where.isEmpty).toStrictEqual(true);
    expect(new Where(WhereOperator.AND).isEmpty).toStrictEqual(true);
    expect(new Where(WhereOperator.AND, 'TRUE').isEmpty).toStrictEqual(false);
    expect(new Where(WhereOperator.AND, []).isEmpty).toStrictEqual(true);
    expect(new Where(WhereOperator.AND, [123]).isEmpty).toStrictEqual(false);
  });

  it('isFinal', () => {
    expect(new Where().isFinal).toStrictEqual(false);
    expect(new Where().andWhere(() => ({})).isFinal).toStrictEqual(false);
    expect(new Where(WhereOperator.AND, [123]).isFinal).toStrictEqual(true);
    expect(new Where(WhereOperator.AND, 'TRUE').isFinal).toStrictEqual(true);
  });

  it('hasChildren', () => {
    expect(new Where().hasChildren).toStrictEqual(false);
    expect(new Where().andWhere(() => ({})).hasChildren).toStrictEqual(true);
  });
});
