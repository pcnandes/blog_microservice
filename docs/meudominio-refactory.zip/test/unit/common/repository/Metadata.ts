export interface EntityType {
  codigo?: string;
  nome?: string;
  descricao?: string;
  servico?: { id?: number; mnemonico?: string };
  tipo?: { pk?: string; titulo?: string };
  sistemas?: { identificador?: string; sigla?: string }[];
  versao?: number;
}

export const metadata = {
  primaryColumns: [{ propertyName: 'codigo', databaseName: 'codigo' }],
  columns: [
    { propertyName: 'codigo', target: 'Teste', databaseName: 'codigo' },
    { propertyName: 'nome', target: 'Teste', databaseName: 'nome' },
    { propertyName: 'descricao', target: 'Teste', databaseName: 'descricao' },
    { propertyName: 'servico', target: 'Servico', databaseName: 'codigo' },
    { propertyName: 'versao', target: 'Teste', databaseName: 'versao' },
  ],
  relations: [
    // ManyToOne
    {
      isOwning: true,
      joinColumns: [{ databaseName: 'tipo' }],
      propertyName: 'tipo',
      inverseEntityMetadata: {
        columns: [
          { isPrimary: true, propertyName: 'pk' },
          { isPrimary: false, propertyName: 'titulo' },
        ],
        relations: [],
        primaryColumns: [{ propertyName: 'pk', databaseName: 'pk' }],
      },
      entityMetadata: {
        name: 'Teste',
      },
    },
    // OneToOne
    {
      isOwning: true,
      propertyName: 'servico',
      joinColumns: [{ databaseName: 'codigo' }],
      inverseEntityMetadata: {
        columns: [
          { isPrimary: true, propertyName: 'id' },
          { isPrimary: false, propertyName: 'mnemonico' },
          { isPrimary: false, propertyName: 'ug' },
        ],
        primaryColumns: [{ propertyName: 'id', databaseName: 'id' }],
        relations: [],
      },
      entityMetadata: {
        name: 'Teste',
      },
    },
    // OneToMany
    {
      isOwning: false,
      propertyName: 'sistemas',
      inverseEntityMetadata: {
        columns: [
          { isPrimary: true, propertyName: 'identificador' },
          { isPrimary: false, propertyName: 'sigla' },
          { isPrimary: false, propertyName: 'nome' },
          { isPrimary: false, propertyName: 'dominio', target: 'Dominio' },
        ],
        primaryColumns: [{ propertyName: 'identificador', databaseName: 'identificador' }],
        relations: [
          {
            isOwning: true,
            joinColumns: [{ databaseName: 'identificador' }],
            propertyName: 'dominio',
            inverseEntityMetadata: {
              columns: [{ isPrimary: true, propertyName: 'id' }],
              relations: [],
              primaryColumns: [{ propertyName: 'id', databaseName: 'id' }],
            },
            entityMetadata: {
              name: 'Dominio',
              columns: [
                { isPrimary: true, propertyName: 'id' },
                { isPrimary: false, propertyName: 'ug' },
              ],
              primaryColumns: [{ propertyName: 'id', databaseName: 'id' }],
              relations: [],
            },
          },
        ],
      },
      entityMetadata: {
        name: 'Teste',
      },
    },
  ],
  name: 'Teste',
  target: 'Teste',
};

export const entities: EntityType[] = [
  {
    codigo: '234',
    nome: 'DEF',
    descricao: 'Descrição 2',
    servico: { id: 567, mnemonico: 'SUNEF' },
    sistemas: [{ identificador: 'PMD', sigla: 'PORTAL MD' }],
  },
  {
    codigo: '123',
    nome: 'ABC',
    descricao: 'Descrição 1',
    servico: { id: 456, mnemonico: 'BLABLABLA' },
    tipo: { pk: 'abc', titulo: 'Abobrinha' },
    sistemas: [
      { identificador: 'SIG', sigla: 'SIGEPE' },
      { identificador: 'RAD', sigla: 'RADAR' },
    ],
  },
];
