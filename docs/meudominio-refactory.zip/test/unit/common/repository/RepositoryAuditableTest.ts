import 'jest';

import { BadRequestException, NotFoundException } from '@nestjs/common';
import { mock } from 'jest-mock-extended';
import { cloneDeep, set } from 'lodash';
import { In, IsNull } from 'typeorm';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { Query } from '../../../../src/common/query/Query';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { Historico } from '../../../../src/modules/historico/HistoricoEntity';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { RepositoryAuditable } from '../../../../src/common/repository/RepositoryAuditable';
import { RepositoryBase } from '../../../../src/common/repository/RepositoryBase';
import { entities, EntityType, metadata } from './Metadata';

const query = mock<Query<EntityType>>();

jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/common/query/Query');

describe('unit/common/repository/RepositoryAuditableTest', () => {
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const repositoryORM = mock<BaseRepository<EntityType>>();
  const repositoryHIS = mock<BaseRepository<EntityType>>();
  set(repositoryORM, 'metadata', metadata);
  set(repositoryORM, 'manager', { getRepository: () => repositoryHIS });
  set(RepositoryBase.prototype, 'createQuery', () => query);
  const repository = new RepositoryAuditable<EntityType>(repositoryORM, security);
  const requestUser = new Usuario({ username: '12345678900', empregado: new Empregado({ cpf: '12345678900' }) });
  const requestTime = new Date();

  beforeEach(() => {
    repositoryORM.insert.mockClear();
    repositoryORM.update.mockClear();
    repositoryORM.delete.mockClear();
    repositoryHIS.insert.mockClear();
    repositoryHIS.update.mockClear();
    repositoryORM.createQueryBuilder.mockReturnValue(null);
    security.getRequestUser.mockReturnValue(requestUser);
    security.getRequestTime.mockReturnValue(requestTime);
    query.andWhere.mockClear();
    query.andWhereInIds.mockClear();
    query.addSelect.mockClear();
    query.addOrderBy.mockClear();
    query.getMany.mockClear();
    query.andWhere.mockReturnThis();
    query.andWhereInIds.mockReturnThis();
    query.addSelect.mockReturnThis();
    query.addOrderBy.mockReturnThis();
  });

  it('entidade sem atributo versão', () => {
    const wrapper = mock<BaseRepository<EntityType>>();
    set(wrapper, 'metadata', { ...cloneDeep(metadata), columns: metadata.columns.filter(c => c.propertyName !== 'versao') });
    expect(() => new RepositoryAuditable<EntityType>(wrapper, security)).toThrowError(
      `Entidade auditável ${metadata.name} não possui atributo versao`,
    );
  });

  describe('insert', () => {
    it('insert one', async () => {
      const idEsperado = '987';
      repositoryORM.insert.mockResolvedValue({ identifiers: [{ codigo: idEsperado }], generatedMaps: [], raw: {} });
      const idRecebido = await repository.insert(entities[1]);
      const registro = {
        codigo: '123',
        nome: 'ABC',
        descricao: 'Descrição 1',
        tipo: { pk: 'abc' },
        versao: 1,
      };
      expect(idRecebido).toStrictEqual(idEsperado);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryORM.insert).toBeCalledTimes(1);
      expect(repositoryORM.insert).toBeCalledWith([registro]);
      expect(repositoryHIS.insert).toBeCalledTimes(1);
      delete registro.codigo;
      expect(repositoryHIS.insert).toBeCalledWith([
        new Historico({
          autor: requestUser.empregado,
          data: requestTime,
          entidade: metadata.name,
          operacao: 'I',
          id: idEsperado,
          atributos: ['nome', 'descricao', 'tipo'],
          modificados: {},
          registro,
        }),
      ]);
    });

    it('insert all', async () => {
      const idEsperado = ['987', '012'];
      repositoryORM.insert.mockResolvedValue({
        identifiers: [{ codigo: idEsperado[0] }, { codigo: idEsperado[1] }],
        generatedMaps: [],
        raw: {},
      });
      const idRecebido = await repository.insertAll(...entities);
      const registros = [
        {
          codigo: '234',
          nome: 'DEF',
          descricao: 'Descrição 2',
          versao: 1,
        },
        {
          codigo: '123',
          nome: 'ABC',
          descricao: 'Descrição 1',
          tipo: { pk: 'abc' },
          versao: 1,
        },
      ];
      expect(idRecebido).toStrictEqual(idEsperado);
      expect(repositoryORM.insert).toBeCalledTimes(1);
      expect(repositoryORM.insert).toBeCalledWith(registros);
      expect(repositoryHIS.insert).toBeCalledTimes(1);
      expect(repositoryHIS.update).toBeCalledTimes(1);
      delete registros[0].codigo;
      delete registros[1].codigo;
      expect(repositoryHIS.insert).toBeCalledWith([
        new Historico({
          autor: requestUser.empregado,
          data: requestTime,
          entidade: metadata.name,
          operacao: 'I',
          id: idEsperado[0],
          atributos: ['nome', 'descricao'],
          modificados: {},
          registro: registros[0],
        }),
        new Historico({
          autor: requestUser.empregado,
          data: requestTime,
          entidade: metadata.name,
          operacao: 'I',
          id: idEsperado[1],
          atributos: ['nome', 'descricao', 'tipo'],
          modificados: {},
          registro: registros[1],
        }),
      ]);
    });

    it('insert all empty', async () => {
      const id = await repository.insertAll();
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryHIS.insert).toBeCalledTimes(0);
      expect(repositoryHIS.update).toBeCalledTimes(0);
      expect(id).toStrictEqual([]);
    });
  });

  describe('update', () => {
    it('registro inexistente', async () => {
      query.getMany.mockResolvedValue([]);
      await expect(repository.update(entities[0])).rejects.toThrow(NotFoundException);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
    });

    it('versão vazia', async () => {
      const entity = entities[0];
      query.getMany.mockResolvedValue([
        {
          codigo: entity.codigo,
          nome: entity.nome + ' antigo',
          descricao: entity.descricao + ' antigo',
          versao: 999,
        },
      ]);
      await expect(repository.update(entity)).rejects.toThrow(BadRequestException);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
    });

    it('versão incorreta', async () => {
      const entity = { ...entities[0], versao: 1 };
      query.getMany.mockResolvedValue([
        {
          codigo: entity.codigo,
          nome: entity.nome + ' antigo',
          descricao: entity.descricao + ' antigo',
          versao: 2,
        },
      ]);
      await expect(repository.update(entity)).rejects.toThrow(BadRequestException);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
    });

    it('update one', async () => {
      const entity = { ...entities[1], versao: 2 };
      const registro = {
        codigo: entity.codigo,
        nome: entity.nome,
        descricao: entity.descricao,
        tipo: { pk: entity.tipo.pk },
        versao: 3,
      };
      query.getMany.mockResolvedValue([
        {
          codigo: entity.codigo,
          nome: entity.nome + ' antigo',
          descricao: entity.descricao,
          versao: 2,
        },
      ]);
      await repository.update(entity);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(1);
      expect(repositoryORM.update).toBeCalledWith(entity.codigo, registro);
      expect(repositoryHIS.update).toBeCalledTimes(1);
      expect(repositoryHIS.update).toBeCalledWith(
        { id: In([entity.codigo]), proximo: IsNull(), entidade: metadata.name },
        { proximo: requestTime },
      );
      delete registro.codigo;
      expect(repositoryHIS.insert).toBeCalledTimes(1);
      expect(repositoryHIS.insert).toBeCalledWith([
        new Historico({
          autor: requestUser.empregado,
          data: requestTime,
          entidade: metadata.name,
          operacao: 'U',
          id: entity.codigo,
          atributos: ['nome', 'tipo'],
          modificados: { nome: entity.nome + ' antigo', tipo: null },
          registro,
        }),
      ]);
    });

    it('update all empty', async () => {
      await repository.updateAll();
      expect(query.getMany).toBeCalledTimes(0);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryHIS.insert).toBeCalledTimes(0);
      expect(repositoryHIS.update).toBeCalledTimes(0);
    });

    it('update sem alteração', async () => {
      const entity = { ...entities[0], versao: 1 };
      query.getMany.mockResolvedValue([
        {
          codigo: entity.codigo,
          nome: entity.nome,
          descricao: entity.descricao,
          versao: 1,
        },
      ]);
      await repository.update(entity);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryHIS.insert).toBeCalledTimes(0);
      expect(repositoryHIS.update).toBeCalledTimes(0);
    });
  });

  describe('delete', () => {
    it('inexistente', async () => {
      query.getMany.mockResolvedValue([]);
      await expect(repository.delete('123')).rejects.toThrow(NotFoundException);
      expect(repositoryHIS.insert).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(0);
      expect(repositoryHIS.update).toBeCalledTimes(0);
    });

    it('delete one', async () => {
      const entity = { ...entities[1] };
      const registro = {
        codigo: entity.codigo,
        nome: entity.nome,
        descricao: entity.descricao,
        versao: 2,
      };
      query.getMany.mockResolvedValue([registro]);
      await repository.delete(entity.codigo);
      expect(repositoryORM.insert).toBeCalledTimes(0);
      expect(repositoryORM.update).toBeCalledTimes(0);
      expect(repositoryORM.delete).toBeCalledTimes(1);
      expect(repositoryORM.delete).toBeCalledWith([entity.codigo]);
      expect(repositoryHIS.update).toBeCalledTimes(1);
      expect(repositoryHIS.update).toBeCalledWith(
        { id: In([entity.codigo]), proximo: IsNull(), entidade: metadata.name },
        { proximo: requestTime },
      );
      delete registro.codigo;
      expect(repositoryHIS.insert).toBeCalledTimes(1);
      expect(repositoryHIS.insert).toBeCalledWith([
        new Historico({
          autor: requestUser.empregado,
          data: requestTime,
          entidade: metadata.name,
          operacao: 'D',
          id: entity.codigo,
          atributos: [],
          modificados: {},
          registro,
        }),
      ]);
    });

    it('delete all empty', async () => {
      await repository.deleteAll();
      expect(repositoryORM.delete).toBeCalledTimes(0);
    });
  });
});
