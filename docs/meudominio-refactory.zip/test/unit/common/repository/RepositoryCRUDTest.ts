import 'jest';

import { mock } from 'jest-mock-extended';
import { set } from 'lodash';
import { BaseRepository } from 'typeorm-transactional-cls-hooked';
import { RepositoryCRUD } from '../../../../src/common/repository/RepositoryCRUD';
import { entities, EntityType, metadata } from './Metadata';

describe('unit/common/repository/RepositoryCRUDTest', () => {
  const repositoryORM = mock<BaseRepository<EntityType>>();
  set(repositoryORM, 'metadata', metadata);
  const repository = new RepositoryCRUD<EntityType>(repositoryORM);

  beforeEach(() => {
    repositoryORM.insert.mockClear();
    repositoryORM.update.mockClear();
    repositoryORM.delete.mockClear();
  });

  it('insert', async () => {
    repositoryORM.insert.mockResolvedValue({ identifiers: [{ codigo: '999' }], generatedMaps: [], raw: {} });
    const id = await repository.insert(entities[1]);
    expect(repositoryORM.insert).toBeCalledTimes(1);
    expect(repositoryORM.insert).toBeCalledWith({
      codigo: '123',
      nome: 'ABC',
      descricao: 'Descrição 1',
      tipo: { pk: 'abc' },
    });
    expect(id).toStrictEqual('999');
  });

  it('insertAll', async () => {
    const idsEsperados = ['123', '456'];
    repositoryORM.insert.mockResolvedValue({
      identifiers: [{ codigo: idsEsperados[0] }, { codigo: idsEsperados[1] }],
      generatedMaps: [],
      raw: {},
    });
    const idsRecebidos = await repository.insertAll(...entities);
    expect(repositoryORM.insert).toBeCalledTimes(1);
    expect(repositoryORM.insert).toBeCalledWith([
      {
        codigo: '234',
        nome: 'DEF',
        descricao: 'Descrição 2',
      },
      {
        codigo: '123',
        nome: 'ABC',
        descricao: 'Descrição 1',
        tipo: { pk: 'abc' },
      },
    ]);
    expect(idsRecebidos).toStrictEqual(idsEsperados);
  });

  it('insertAll empty', async () => {
    const ids = await repository.insertAll();
    expect(ids).toStrictEqual([]);
    expect(repositoryORM.insert).toBeCalledTimes(0);
  });

  it('update', async () => {
    repositoryORM.update.mockResolvedValue(null);
    await repository.update(entities[1]);
    expect(repositoryORM.update).toBeCalledTimes(1);
    expect(repositoryORM.update).toBeCalledWith('123', {
      codigo: '123',
      nome: 'ABC',
      descricao: 'Descrição 1',
      tipo: { pk: 'abc' },
    });
  });

  it('updateAll', async () => {
    repositoryORM.update.mockResolvedValue(null);
    await repository.updateAll(...entities);
    expect(repositoryORM.update).toBeCalledTimes(2);
  });

  it('updateAll empty', async () => {
    await repository.updateAll();
    expect(repositoryORM.update).toBeCalledTimes(0);
  });

  it('delete', async () => {
    repositoryORM.delete.mockResolvedValue(null);
    await repository.delete(123);
    expect(repositoryORM.delete).toBeCalledTimes(1);
    expect(repositoryORM.delete).toBeCalledWith(123);
  });

  it('deleteAll', async () => {
    repositoryORM.delete.mockResolvedValue(null);
    await repository.deleteAll('abc', 'def');
    expect(repositoryORM.delete).toBeCalledTimes(1);
    expect(repositoryORM.delete).toBeCalledWith(['abc', 'def']);
  });

  it('deleteAll empty', async () => {
    await repository.deleteAll();
    expect(repositoryORM.delete).toBeCalledTimes(0);
  });
});
