import 'jest';

import { ForbiddenException } from '@nestjs/common';
import { HasPermission } from '../../../../src/common/security/HasPermissionDecorator';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';

jest.mock('../../../../src/common/security/SecurityContext');

describe('unit/common/security/HasPermissionDecoratorTest', () => {
  const getLoggedUser = jest.fn();
  const method = jest.fn();
  SecurityContext.getLoggedUser = getLoggedUser;

  beforeEach(() => {
    getLoggedUser.mockClear();
    method.mockClear();
  });

  it('não autenticado', async () => {
    getLoggedUser.mockReturnValue(null);
    const descriptor = HasPermission()(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('usuário de serviço', async () => {
    getLoggedUser.mockReturnValue(new Usuario({ username: 'AESP' }));
    const descriptor = HasPermission()(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('sem permissão', async () => {
    getLoggedUser.mockReturnValue(new Usuario({ username: '111', empregado: { cpf: '111', matricula: 111 } }));
    method.mockReturnValue('xyz');
    const descriptor = HasPermission(Operacao.ALOCAR)(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    getLoggedUser.mockReturnValue(
      new Usuario({ username: '111', empregado: { cpf: '111', matricula: 111 }, permissoes: [{ operacoes: [Operacao.ALOCAR] }] }),
    );
    method.mockReturnValue('xyz');
    const descriptor = HasPermission(Operacao.ALOCAR)(null, null, { value: method });
    const result = await descriptor.value('a1', 'a2', 'a3');
    expect(result).toStrictEqual('xyz');
    expect(method).toBeCalledTimes(1);
    expect(method).toBeCalledWith('a1', 'a2', 'a3');
  });
});
