import 'jest';

import { ForbiddenException } from '@nestjs/common';
import { HasRole } from '../../../../src/common/security/HasRoleDecorator';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { Perfil } from './../../../../src/modules/usuario/Perfil';

jest.mock('../../../../src/common/security/SecurityContext');

describe('unit/common/security/HasRoleDecoratorTest', () => {
  const getLoggedUser = jest.fn();
  const method = jest.fn();
  SecurityContext.getLoggedUser = getLoggedUser;

  beforeEach(() => {
    getLoggedUser.mockClear();
    method.mockClear();
  });

  it('não autenticado', async () => {
    getLoggedUser.mockReturnValue(null);
    const descriptor = HasRole()(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('usuário de serviço', async () => {
    getLoggedUser.mockReturnValue(new Usuario({ username: 'AESP' }));
    const descriptor = HasRole()(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('sem perfil', async () => {
    getLoggedUser.mockReturnValue(new Usuario({ username: '111', empregado: { cpf: '111', matricula: 111 } }));
    const descriptor = HasRole(Perfil.ADMINISTRADOR)(null, null, { value: method });
    await expect(descriptor.value()).rejects.toThrowError(ForbiddenException);
    expect(method).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    getLoggedUser.mockReturnValue(
      new Usuario({ username: '111', empregado: { cpf: '111', matricula: 111 }, perfis: [Perfil.ADMINISTRADOR] }),
    );
    method.mockReturnValue('xyz');
    const descriptor = HasRole(Perfil.ADMINISTRADOR)(null, null, { value: method });
    const result = await descriptor.value('a1', 'a2', 'a3');
    expect(result).toStrictEqual('xyz');
    expect(method).toBeCalledTimes(1);
    expect(method).toBeCalledWith('a1', 'a2', 'a3');
  });
});
