import 'jest';

import { ObjectUtils } from '../../../../src/common/utils/ObjectUtils';

describe('unit/common/utils/ObjectUtils', () => {
  it('removerProperties', () => {
    const obj = {
      id: 'abcdef',
      codigo: '0001',
      nome: 'Teste 1',
      gestorDominio: {
        matricula: 123,
        nome: 'Fulano',
        lotacao: 'DIDES/SUPDR/BLABLABLA',
      },
      gestorNegocio: {
        matricula: 456,
        nome: 'Cicrano',
        lotacao: 'DIRCL/SUNEF/BLABLABLA',
      },
      subdominios: [
        {
          codigo: '0001-003',
        },
        {
          codigo: '0001-001',
          sistemas: [
            {
              id: 'abc',
              nome: 'SICONV',
              servicos: [{ codigo: 123, principal: true }],
            },
          ],
        },
        {
          codigo: '0001-002',
          sistemas: [
            {
              id: 'def',
              nome: 'SIGEPE',
              servicos: [{ codigo: 456, principal: true }],
            },
          ],
        },
      ],
    };
    ObjectUtils.removeProperties(obj, ['codigo', 'gestorNegocio.nome', 'subdominios.sistemas.id']);
    expect(obj).toStrictEqual({
      codigo: '0001',
      gestorNegocio: { nome: 'Cicrano' },
      subdominios: [{}, { sistemas: [{ id: 'abc' }] }, { sistemas: [{ id: 'def' }] }],
    });
  });
});
