import 'jest';

import { AlocacaoAgrupadaFilter } from './../../../../src/modules/alocacao/AlocacaoAgrupadaFilter';

describe('unit/modules/alocacao/AlocacaoAgrupadaFilterTest', () => {
  it('lotacao', () => {
    const filter = new AlocacaoAgrupadaFilter({ lotacao: 'dides/supdr' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND emp.lotacao ILIKE $1');
    expect(filter.toSqlParams()).toStrictEqual(['dides/supdr%']);
  });

  it('dominio id', () => {
    const filter = new AlocacaoAgrupadaFilter({ dominio: 'aace596e-07c3-48fe-9160-cfbc942f4dae' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND dom.id = $1');
    expect(filter.toSqlParams()).toStrictEqual(['aace596e-07c3-48fe-9160-cfbc942f4dae']);
  });

  it('dominio cd', () => {
    const filter = new AlocacaoAgrupadaFilter({ dominio: '0023' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND dom.codigo = $1');
    expect(filter.toSqlParams()).toStrictEqual(['0023']);
  });

  it('subdominio id', () => {
    const filter = new AlocacaoAgrupadaFilter({ subdominio: 'aace596e-07c3-48fe-9160-cfbc942f4dae' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND sub.id = $1');
    expect(filter.toSqlParams()).toStrictEqual(['aace596e-07c3-48fe-9160-cfbc942f4dae']);
  });

  it('subdominio cd', () => {
    const filter = new AlocacaoAgrupadaFilter({ subdominio: '0023-001' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND sub.codigo = $1');
    expect(filter.toSqlParams()).toStrictEqual(['0023-001']);
  });

  it('sistema id', () => {
    const filter = new AlocacaoAgrupadaFilter({ sistema: 'aace596e-07c3-48fe-9160-cfbc942f4dae' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND sis.id = $1');
    expect(filter.toSqlParams()).toStrictEqual(['aace596e-07c3-48fe-9160-cfbc942f4dae']);
  });

  it('sistema nm', () => {
    const filter = new AlocacaoAgrupadaFilter({ sistema: 'SIGEPE' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND sis.identificador = $1');
    expect(filter.toSqlParams()).toStrictEqual(['SIGEPE']);
  });

  it('servico', () => {
    const filter = new AlocacaoAgrupadaFilter({ servico: '00084-92116-23117' });
    expect(filter.toSqlWhere()).toStrictEqual(' AND srv.servico = ANY(CAST($1 AS INTEGER[]))');
    expect(filter.toSqlParams()).toStrictEqual(['{84,92116,23117}']);
  });

  it('vazio', () => {
    const filter = new AlocacaoAgrupadaFilter();
    expect(filter.toSqlWhere()).toStrictEqual('');
    expect(filter.toSqlParams()).toStrictEqual([]);
  });
});
