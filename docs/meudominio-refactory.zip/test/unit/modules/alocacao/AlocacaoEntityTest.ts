import 'jest';

import { Alocacao } from '../../../../src/modules/alocacao/AlocacaoEntity';
import { CategoriaDominio } from './../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from './../../../../src/modules/sistema/LinhaNegocio';
import { Sistema } from './../../../../src/modules/sistema/SistemaEntity';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';

describe('unit/modules/alocacao/AlocacaoEntityTest', () => {
  const sistema = new Sistema({
    linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO,
    subdominio: { dominio: { id: 'xyz', categoria: CategoriaDominio.NEGOCIO } },
  });

  it('rateada', () => {
    expect(() => new Alocacao().rateada).toThrowError('[Alocacao].rateioID não carregado');
    expect(new Alocacao({ rateioID: null }).rateada).toStrictEqual(false);
    expect(new Alocacao({ rateioID: 'xyz' }).rateada).toStrictEqual(true);
  });

  it('dominio', () => {
    expect(() => new Alocacao().dominio).toThrowError('[Alocacao].sistema não carregado');
    expect(new Alocacao({ sistema }).dominio).toStrictEqual(new Dominio(sistema.subdominio.dominio));
  });

  it('dominioID', () => {
    expect(() => new Alocacao().dominio).toThrowError('[Alocacao].sistema não carregado');
    expect(new Alocacao({ sistema }).dominioID).toStrictEqual(sistema.subdominio.dominio.id);
  });

  it('possuiSistema', () => {
    expect(() => new Alocacao().possuiSistema).toThrowError('[Alocacao].sistema não carregado');
    expect(new Alocacao({ sistema: null }).possuiSistema).toStrictEqual(false);
    expect(new Alocacao({ sistema: { id: 'abc' } }).possuiSistema).toStrictEqual(true);
  });

  it('totalSubProcesso', () => {
    expect(new Alocacao({ construcao: 60, sustentacao: 40 }).totalSubProcesso).toStrictEqual(100);
    expect(new Alocacao({ produto: 100 }).totalSubProcesso).toStrictEqual(100);
    expect(new Alocacao({ suporte: 100 }).totalSubProcesso).toStrictEqual(100);
    expect(new Alocacao({ gestao: 100 }).totalSubProcesso).toStrictEqual(100);
    expect(new Alocacao({ administrativo: 100 }).totalSubProcesso).toStrictEqual(100);
  });

  it('build suporte', () => {
    const param = {
      id: null,
      empregado: new Empregado({ cpf: '111' }),
      sistema: null,
      percentual: 55,
      rateioID: null,
      construcao: 60,
      sustentacao: 40,
    };
    const alocacao = Alocacao.build(param);
    expect(alocacao.empregado).toStrictEqual(param.empregado);
    expect(alocacao.sistema).toStrictEqual(param.sistema);
    expect(alocacao.percentual).toStrictEqual(param.percentual);
    expect(alocacao.suporte).toStrictEqual(100);
    expect(alocacao.totalSubProcesso).toStrictEqual(100);
  });

  it('build produto independente', () => {
    const param = {
      id: null,
      empregado: new Empregado({ cpf: '111' }),
      sistema: new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_NUVEM, subdominio: { dominio: { categoria: CategoriaDominio.PRODUTO } } }),
      percentual: 90,
      rateioID: 'abc',
      construcao: 60,
      sustentacao: 40,
      produto: 10,
      suporte: 30,
    };
    const alocacao = Alocacao.build(param);
    expect(alocacao.empregado).toStrictEqual(param.empregado);
    expect(alocacao.sistema).toStrictEqual(param.sistema);
    expect(alocacao.produto).toStrictEqual(100);
    expect(alocacao.percentual).toStrictEqual(param.percentual);
    expect(alocacao.totalSubProcesso).toStrictEqual(100);
    expect(alocacao.rateioID).toStrictEqual(param.rateioID);
  });

  it('build produto dependente', () => {
    const param = {
      id: null,
      empregado: new Empregado({ cpf: '111' }),
      sistema: new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_NUVEM, subdominio: { dominio: { categoria: CategoriaDominio.NEGOCIO } } }),
      percentual: 90,
      rateioID: 'abc',
      construcao: 60,
      sustentacao: 40,
      produto: 10,
      suporte: 30,
    };
    const alocacao = Alocacao.build(param);
    expect(alocacao.sustentacao).toStrictEqual(100);
    expect(alocacao.totalSubProcesso).toStrictEqual(100);
  });

  it('build sob medida', () => {
    const param = {
      id: null,
      empregado: new Empregado({ cpf: '111' }),
      sistema: new Sistema({
        linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
        subdominio: { dominio: { categoria: CategoriaDominio.NEGOCIO } },
      }),
      percentual: 90,
      rateioID: 'abc',
      construcao: 65,
      produto: 10,
      suporte: 30,
    };
    const alocacao = Alocacao.build(param);
    expect(alocacao.construcao).toStrictEqual(param.construcao);
    expect(alocacao.sustentacao).toStrictEqual(35);
    expect(alocacao.totalSubProcesso).toStrictEqual(100);
  });
});
