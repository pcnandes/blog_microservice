import 'jest';

import { NotFoundException } from '@nestjs/common';
import { Alocacao } from '../../../../src/modules/alocacao/AlocacaoEntity';
import { AlocacaoRepository } from '../../../../src/modules/alocacao/AlocacaoRepository';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { AlocacaoPipeAlterar } from './../../../../src/modules/alocacao/AlocacaoPipeAlterar';
import { CategoriaDominio } from './../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from './../../../../src/modules/sistema/LinhaNegocio';

jest.mock('../../../../src/modules/alocacao/AlocacaoRepository');

describe('unit/modules/alocacao/AlocacaoPipeAlterarTest', () => {
  const repository = new AlocacaoRepository(null, null) as jest.Mocked<AlocacaoRepository>;
  const pipe = new AlocacaoPipeAlterar(repository);

  beforeEach(() => {
    repository.findManyByEmpregado.mockClear();
  });

  it('alocação sem id', async () => {
    await expect(pipe.transform({ empregado: { cpf: '111' } })).rejects.toThrow(NotFoundException);
    expect(repository.findManyByEmpregado).toBeCalledTimes(0);
  });

  it('alocação inexistente', async () => {
    repository.findManyByEmpregado.mockResolvedValue([new Alocacao({ id: 'aaa' })]);
    await expect(pipe.transform({ id: 'bbb', empregado: { cpf: '111' } })).rejects.toThrow(NotFoundException);
    expect(repository.findManyByEmpregado).toBeCalledTimes(1);
    expect(repository.findManyByEmpregado).toBeCalledWith(
      '111',
      'id-empregado.cpf-rateioID-sistema.(id-linhaNegocio-subdominio.dominio.(id-categoria))-percentual',
    );
  });

  it('alocação por rateio', async () => {
    repository.findManyByEmpregado.mockResolvedValue([new Alocacao({ id: 'aaa', rateioID: 'xxx' })]);
    await expect(pipe.transform({ id: 'aaa', empregado: { cpf: '111' } })).rejects.toHaveProperty(
      'message.message',
      'Alocações por rateio não podem ser alteradas',
    );
    expect(repository.findManyByEmpregado).toBeCalledTimes(1);
  });

  it('alocação total superior a 100%', async () => {
    repository.findManyByEmpregado.mockResolvedValue([
      new Alocacao({ id: 'aaa', percentual: 60, sistema: { id: 'xxx' } }),
      new Alocacao({ id: 'bbb', percentual: 40, sistema: null }),
    ]);
    await expect(pipe.transform({ id: 'bbb', percentual: 50, empregado: { cpf: '111' } })).rejects.toHaveProperty(
      'message.message',
      'O total alocado ultrapassa os 100%',
    );
    expect(repository.findManyByEmpregado).toBeCalledTimes(1);
  });

  it('sucesso', async () => {
    const sistema = new Sistema({
      id: 'abc',
      linhaNegocio: LinhaNegocio.SERVICO_NUVEM,
      subdominio: { dominio: { categoria: CategoriaDominio.INTERNO } },
    });
    repository.findManyByEmpregado.mockResolvedValue([
      new Alocacao({ id: 'aaa', percentual: 60, sistema: null }),
      new Alocacao({ id: 'bbb', percentual: 40, sistema }),
    ]);
    const alocacao = await pipe.transform({ id: 'bbb', percentual: 30, empregado: { cpf: '111' } });
    expect(repository.findManyByEmpregado).toBeCalledTimes(1);
    expect(alocacao.percentual).toStrictEqual(30);
    expect(alocacao.sustentacao).toStrictEqual(100);
    expect(alocacao.sistema).toStrictEqual(sistema);
  });
});
