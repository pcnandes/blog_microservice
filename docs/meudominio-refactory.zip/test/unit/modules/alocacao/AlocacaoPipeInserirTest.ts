import 'jest';

import { Alocacao } from '../../../../src/modules/alocacao/AlocacaoEntity';
import { AlocacaoRateio } from '../../../../src/modules/alocacao/AlocacaoRateioEntity';
import { AlocacaoRateioRepository } from '../../../../src/modules/alocacao/AlocacaoRateioRepository';
import { AlocacaoRepository } from '../../../../src/modules/alocacao/AlocacaoRepository';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { AlocacaoPipeInserir } from './../../../../src/modules/alocacao/AlocacaoPipeInserir';
import { CategoriaDominio } from './../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from './../../../../src/modules/sistema/LinhaNegocio';

jest.mock('../../../../src/modules/alocacao/AlocacaoRepository');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioRepository');
jest.mock('../../../../src/modules/empregado/EmpregadoRepository');
jest.mock('../../../../src/modules/sistema/SistemaRepository');

describe('unit/modules/alocacao/AlocacaoPipeInserirTest', () => {
  const repositoryAlocacao = new AlocacaoRepository(null, null) as jest.Mocked<AlocacaoRepository>;
  const repositoryRateio = new AlocacaoRateioRepository(null, null) as jest.Mocked<AlocacaoRateioRepository>;
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const empregado = new Empregado({ cpf: '111', lotacao: 'DIDES/SUPDR/DRAPA', funcaoConfianca: null, dataDesligamento: null });
  const sistema = new Sistema({
    id: 'yyy',
    identificador: 'SIGEPE',
    linhaNegocio: LinhaNegocio.SERVICO_NUVEM,
    subdominio: { dominio: { nome: 'Pessoas', categoria: CategoriaDominio.INTERNO } },
  });

  const pipe = new AlocacaoPipeInserir(repositoryAlocacao, repositoryRateio, repositoryEmpregado, repositorySistema);

  beforeEach(() => {
    repositoryAlocacao.findManyByEmpregado.mockClear();
    repositorySistema.findOneById.mockClear();
    repositoryRateio.findOneByEmpregado.mockClear();
    repositoryEmpregado.findOneByCPF.mockClear();
  });

  it('empregado não encontrado', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(null);
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf } })).rejects.toHaveProperty(
      'message.message',
      'Empregado não encontrado',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledWith(empregado.cpf, '*');
  });

  it('empregado não alocável', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(new Empregado({ ...empregado, dataDesligamento: new Date() }));
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf } })).rejects.toHaveProperty(
      'message.message',
      'Este empregado não pode ser alocado',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
  });

  it('empregado coadm', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(new Empregado({ ...empregado, lotacao: 'DIDES/COADM/ADSG1' }));
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf } })).rejects.toHaveProperty(
      'message.message',
      'Este empregado não pode ser alocado',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
  });

  it('existe rateio', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    repositoryRateio.findOneByEmpregado.mockResolvedValue(new AlocacaoRateio({ id: 'xyz' }));
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf } })).rejects.toHaveProperty(
      'message.message',
      'Não é permitido incluir alocação para empregado com rateio de alocação',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledWith(empregado.cpf, 'id');
  });

  it('sistema inexistente', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositorySistema.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf }, sistema: { id: sistema.id } })).rejects.toHaveProperty(
      'message.message',
      'Sistema não encontrado',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledWith(sistema.id, 'id-identificador-linhaNegocio-subdominio.dominio.(id-categoria)');
  });

  it('existe outra alocação para o mesmo empregado / sistema', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositorySistema.findOneById.mockResolvedValue(sistema);
    repositoryAlocacao.findManyByEmpregado.mockResolvedValue([new Alocacao({ id: '444', empregado, sistema })]);
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf }, sistema: { id: sistema.id } })).rejects.toHaveProperty(
      'message.message',
      `Já existe alocação para este empregado no sistema ${sistema.identificador}`,
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledTimes(1);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledWith(
      empregado.cpf,
      'id-empregado.cpf-rateioID-sistema.(id-linhaNegocio-subdominio.dominio.(id-categoria))-percentual',
    );
  });

  it('existe outra alocação para o mesmo empregado / suporte', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositoryAlocacao.findManyByEmpregado.mockResolvedValue([new Alocacao({ id: '444', empregado, sistema: null })]);
    await expect(pipe.transform({ empregado: { cpf: empregado.cpf } })).rejects.toHaveProperty(
      'message.message',
      'Já existe alocação para este empregado em suporte',
    );
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledTimes(0);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledTimes(1);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledWith(
      empregado.cpf,
      'id-empregado.cpf-rateioID-sistema.(id-linhaNegocio-subdominio.dominio.(id-categoria))-percentual',
    );
  });

  it('sucesso', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositoryAlocacao.findManyByEmpregado.mockResolvedValue([]);
    repositorySistema.findOneById.mockResolvedValue(sistema);
    const alocacao = await pipe.transform({
      empregado: { cpf: empregado.cpf },
      sistema: { id: sistema.id },
      percentual: 20,
      construcao: 10,
      sustentacao: 90,
    });
    expect(alocacao.id).toBeNull();
    expect(alocacao.rateioID).toBeNull();
    expect(alocacao.sustentacao).toStrictEqual(100);
    expect(alocacao.percentual).toStrictEqual(20);
    expect(alocacao.sistema).toStrictEqual(sistema);
    expect(alocacao.empregado).toStrictEqual(empregado);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledTimes(1);
    expect(repositoryAlocacao.findManyByEmpregado).toBeCalledWith(
      empregado.cpf,
      'id-empregado.cpf-rateioID-sistema.(id-linhaNegocio-subdominio.dominio.(id-categoria))-percentual',
    );
  });
});
