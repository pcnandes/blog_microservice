import 'jest';

import { AlocacaoRateio } from '../../../../src/modules/alocacao/AlocacaoRateioEntity';
import { AlocacaoRateioRepository } from '../../../../src/modules/alocacao/AlocacaoRateioRepository';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';
import { AlocacaoPipeRateio } from './../../../../src/modules/alocacao/AlocacaoPipeRateio';

jest.mock('../../../../src/modules/alocacao/AlocacaoRateioRepository');
jest.mock('../../../../src/modules/empregado/EmpregadoRepository');

describe('unit/modules/alocacao/AlocacaoPipeRateioTest', () => {
  const repositoryRateio = new AlocacaoRateioRepository(null, null) as jest.Mocked<AlocacaoRateioRepository>;
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const pipe = new AlocacaoPipeRateio(repositoryRateio, repositoryEmpregado);

  beforeEach(() => {
    repositoryRateio.findOneByEmpregado.mockClear();
    repositoryEmpregado.findOneByCPF.mockClear();
  });

  it('escopo vazio', async () => {
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositoryEmpregado.findOneByCPF.mockResolvedValue(
      new Empregado({ cpf: '111', lotacao: 'DIDES/SUPDR/DRAPA', dataDesligamento: null, funcaoConfianca: null }),
    );
    await expect(pipe.transform({ empregado: { cpf: '111' } })).rejects.toHaveProperty('message.message', 'O escopo do rateio está vazio');
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositoryRateio.findOneByEmpregado).toBeCalledWith('111', '*-empregado.cpf');
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledWith('111', '*');
  });

  it('empregado não encontrado', async () => {
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositoryEmpregado.findOneByCPF.mockResolvedValue(null);
    await expect(pipe.transform({ empregado: { cpf: '111' } })).rejects.toHaveProperty('message.message', 'Empregado não encontrado');
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
  });

  it('empregado não alocável', async () => {
    repositoryRateio.findOneByEmpregado.mockResolvedValue(null);
    repositoryEmpregado.findOneByCPF.mockResolvedValue(
      new Empregado({ cpf: '111', lotacao: 'DIDES/COADM', dataDesligamento: null, funcaoConfianca: null }),
    );
    await expect(pipe.transform({ empregado: { cpf: '111' } })).rejects.toHaveProperty(
      'message.message',
      'Este empregado não pode ser alocado',
    );
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(1);
  });

  it('sucesso', async () => {
    repositoryRateio.findOneByEmpregado.mockResolvedValue(new AlocacaoRateio({ id: 'xxx', empregado: { cpf: '111' } }));
    const rateio = await pipe.transform({ empregado: { cpf: '111' }, escopo: ['0001'] });
    expect(rateio.id).toStrictEqual('xxx');
    expect(repositoryRateio.findOneByEmpregado).toBeCalledTimes(1);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(0);
  });
});
