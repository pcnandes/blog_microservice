import 'jest';

import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { AlocacaoRateio } from './../../../../src/modules/alocacao/AlocacaoRateioEntity';

describe('unit/modules/alocacao/AlocacaoRateioEntityTest', () => {
  const rateio = new AlocacaoRateio({ escopo: ['SUPDG', '0020', '0015-001'] });

  it('incluiDominio', () => {
    expect(() => rateio.incluiDominio(new Dominio({}))).toThrowError('[Dominio].codigo não carregado');
    expect(() => rateio.incluiDominio(new Dominio({ codigo: '0005' }))).toThrowError('[Dominio].ugDominio não carregado');
    expect(rateio.incluiDominio(new Dominio({ codigo: '0015', ugDominio: 'SUPDR' }))).toStrictEqual(false);
    expect(rateio.incluiDominio(new Dominio({ codigo: '0015', ugDominio: 'SUPDG' }))).toStrictEqual(true);
    expect(rateio.incluiDominio(new Dominio({ codigo: '0020', ugDominio: 'SUPSE' }))).toStrictEqual(true);
  });

  it('incluiSubDominio', () => {
    expect(() => rateio.incluiSubDominio(new SubDominio({}))).toThrowError('[SubDominio].codigo não carregado');
    expect(
      rateio.incluiSubDominio(new SubDominio({ codigo: '0015-001', dominio: new Dominio({ codigo: '0001', ugDominio: 'SUPDR' }) })),
    ).toStrictEqual(true);
    expect(
      rateio.incluiSubDominio(new SubDominio({ codigo: '0015-002', dominio: new Dominio({ codigo: '0001', ugDominio: 'SUPDR' }) })),
    ).toStrictEqual(false);
    expect(
      rateio.incluiSubDominio(new SubDominio({ codigo: '0020-001', dominio: new Dominio({ codigo: '0020', ugDominio: 'SUPDR' }) })),
    ).toStrictEqual(true);
  });

  it('incluiSistema', () => {
    expect(() => rateio.incluiSistema(new Sistema({}))).toThrowError('[Sistema].subdominio não carregado');
    expect(
      rateio.incluiSistema(
        new Sistema({ subdominio: new SubDominio({ codigo: '0015-001', dominio: new Dominio({ codigo: '0001', ugDominio: 'SUPDR' }) }) }),
      ),
    ).toStrictEqual(true);
    expect(
      rateio.incluiSistema(
        new Sistema({ subdominio: new SubDominio({ codigo: '0015-002', dominio: new Dominio({ codigo: '0001', ugDominio: 'SUPDR' }) }) }),
      ),
    ).toStrictEqual(false);
    expect(
      rateio.incluiSistema(
        new Sistema({ subdominio: new SubDominio({ codigo: '0020-001', dominio: new Dominio({ codigo: '0020', ugDominio: 'SUPDR' }) }) }),
      ),
    ).toStrictEqual(true);
  });
});
