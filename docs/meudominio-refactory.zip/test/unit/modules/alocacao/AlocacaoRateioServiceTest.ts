import 'jest';

describe('unit/modules/alocacao/AlocacaoRateioServiceTest', () => {
  it('atualizar por escopo', async () => {
    expect(true).toStrictEqual(true);
  });

  describe('incluir', () => {
    it('sem permissão para remover alocações de suporte', async () => {
      expect(true).toStrictEqual(true);
    });

    it('sem permissão para remover alocações do domínio', async () => {
      expect(true).toStrictEqual(true);
    });

    it('sem permissão alocar no domínio do rateio', async () => {
      expect(true).toStrictEqual(true);
    });

    it('sucesso', async () => {
      expect(true).toStrictEqual(true);
    });
  });

  describe('alterar', () => {
    it('sem escopo', async () => {
      expect(true).toStrictEqual(true);
    });

    it('sucesso', async () => {
      expect(true).toStrictEqual(true);
    });
  });

  it('excluir', async () => {
    expect(true).toStrictEqual(true);
  });
});
