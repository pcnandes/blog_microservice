import 'jest';

describe('unit/modules/alocacao/AlocacaoServiceTest', () => {
  it('inserir sem permissão', async () => {
    expect(true).toStrictEqual(true);
  });

  it('inserir com sucesso', async () => {
    expect(true).toStrictEqual(true);
  });

  it('alterar sem permissão', async () => {
    expect(true).toStrictEqual(true);
  });

  it('alterar com sucesso', async () => {
    expect(true).toStrictEqual(true);
  });

  it('excluir sem permissão', async () => {
    expect(true).toStrictEqual(true);
  });

  it('excluir por id', async () => {
    expect(true).toStrictEqual(true);
  });

  it('excluir por sistema', async () => {
    expect(true).toStrictEqual(true);
  });

  it('excluir por empregado', async () => {
    expect(true).toStrictEqual(true);
  });

  it('atualizar subprocessos', async () => {
    expect(true).toStrictEqual(true);
  });
});
