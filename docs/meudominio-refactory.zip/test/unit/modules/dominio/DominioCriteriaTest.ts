import 'jest';

import { DominioCriteria } from '../../../../src/modules/dominio/DominioCriteria';

describe('unit/modules/dominio/DominioCriteriaTest', () => {
  it('gestor', () => {
    const criteria = new DominioCriteria({ gestor: 'Fulano' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['gestorDominio']);
    expect(where.toString()).toStrictEqual('(dominio_gestorDominio.nome ILIKE :gestor)');
    expect(where.getParameters()).toStrictEqual({ gestor: 'Fulano%' });
  });

  it('ug', () => {
    const criteria = new DominioCriteria({ ug: 'supdg' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['subdominios.sistemas.servicos.servico']);
    expect(where.toString()).toStrictEqual(
      '((dominio.ugDominio = :ug OR dominio.ugNegocio = :ug OR dominio_subdominios_sistemas_servicos_servico.ug = :ug))',
    );
    expect(where.getParameters()).toStrictEqual({ ug: 'SUPDG' });
  });

  it('sistema', () => {
    const criteria = new DominioCriteria({ sistema: 'SIGEPE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['subdominios.sistemas']);
    expect(where.toString()).toStrictEqual(
      '((dominio_subdominios_sistemas.identificador ILIKE :sistema' +
        ' OR dominio_subdominios_sistemas.sigla ILIKE :sistema' +
        ' OR dominio_subdominios_sistemas.nome ILIKE :sistema))',
    );
    expect(where.getParameters()).toStrictEqual({ sistema: '%SIGEPE%' });
  });

  it('servico texto', () => {
    const criteria = new DominioCriteria({ servico: 'SIGEPE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['subdominios.sistemas.servicos.servico']);
    expect(where.toString()).toStrictEqual(
      '((dominio_subdominios_sistemas_servicos_servico.mnemonico ILIKE :servico' +
        ' OR dominio_subdominios_sistemas_servicos_servico.titulo ILIKE :servico))',
    );
    expect(where.getParameters()).toStrictEqual({ servico: '%SIGEPE%' });
  });

  it('servico numero', () => {
    const criteria = new DominioCriteria({ servico: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['subdominios.sistemas.servicos.servico']);
    expect(where.toString()).toStrictEqual('(dominio_subdominios_sistemas_servicos_servico.codigo = :servico)');
    expect(where.getParameters()).toStrictEqual({ servico: 92116 });
  });

  it('subdominio', () => {
    const criteria = new DominioCriteria({ subdominio: 'pessoas' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['subdominios']);
    expect(where.toString()).toStrictEqual('(dominio_subdominios.nome ILIKE :subdominio)');
    expect(where.getParameters()).toStrictEqual({ subdominio: '%pessoas%' });
  });

  it('search texto', () => {
    const criteria = new DominioCriteria({ search: 'teste' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([
      'subdominios.sistemas.servicos.servico',
      'gestorDominio',
      'subdominios.sistemas',
      'subdominios',
      'subdominios.sistemas.servicos',
    ]);
  });

  it('search numero', () => {
    const criteria = new DominioCriteria({ search: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([
      'subdominios.sistemas.servicos.servico',
      'gestorDominio',
      'subdominios.sistemas',
      'subdominios',
      'subdominios.sistemas.servicos',
    ]);
  });
});
