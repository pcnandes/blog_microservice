import 'jest';

import { BadRequestException, NotFoundException } from '@nestjs/common';
import { CategoriaDominio } from '../../../../src/modules/dominio/CategoriaDominio';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { DominioPipeAlterar } from '../../../../src/modules/dominio/DominioPipeAlterar';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { SituacaoDominio } from '../../../../src/modules/dominio/SituacaoDominio';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';

jest.mock('../../../../src/modules/empregado/EmpregadoRepository');
jest.mock('../../../../src/modules/dominio/DominioRepository');

describe('unit/modules/dominio/DominioPipeAlterarTest', () => {
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const pipe = new DominioPipeAlterar(repositoryDominio, repositoryEmpregado);
  const antigo = new Dominio({
    id: 'abc',
    codigo: '0001',
    ugDominio: 'SUPSE',
    nome: 'Velho',
    situacao: SituacaoDominio.ATIVO,
    categoria: CategoriaDominio.NEGOCIO,
  });

  beforeEach(() => {
    repositoryDominio.findOneById.mockClear();
    repositoryEmpregado.findManyByCPF.mockClear();
  });

  it('domínio inexistente', async () => {
    repositoryDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(NotFoundException);
  });

  it('gestor não DIDES', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([
      new Empregado({ cpf: '11122233300', lotacao: 'DIRCL/SUNEF', dataDesligamento: null }),
    ]);
    const value = { id: 'abc', gestorDominio: { cpf: '11122233300' } };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('gestor desligado', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([
      new Empregado({ cpf: '11122233300', lotacao: 'DIDES/SUPDG', dataDesligamento: new Date() }),
    ]);
    const value = { id: 'abc', gestorDominio: { cpf: '11122233300' } };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('gestor inexistente', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([]);
    const value = { id: 'abc', nome: 'Teste', ugDominio: 'SUPDG', gestorDominio: { cpf: '11122233300' } };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('gestor nulo', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([]);
    const value = { id: 'abc', nome: 'Teste', ugDominio: 'SUPDG' };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('RUX não DIDES', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([
      new Empregado({ cpf: '11122233300', lotacao: 'DIDES/SUPDR', dataDesligamento: null }),
      new Empregado({ cpf: '22233344400', lotacao: 'DIRCL/SUNEF', dataDesligamento: null }),
    ]);
    const value = {
      id: 'abc',
      nome: 'Teste',
      ugDominio: 'SUPDG',
      gestorDominio: { cpf: '11122233300' },
      responsavelUX: { cpf: '22233344400' },
    };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('RUX desligado', async () => {
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([
      new Empregado({ cpf: '11122233300', lotacao: 'DIDES/SUPDR', dataDesligamento: null }),
      new Empregado({ cpf: '22233344400', lotacao: 'DIDES/SUPSE', dataDesligamento: new Date() }),
    ]);
    const value = {
      id: 'abc',
      nome: 'Teste',
      ugDominio: 'SUPDG',
      gestorDominio: { cpf: '11122233300' },
      responsavelUX: { cpf: '22233344400' },
    };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });

  it('substitui os atributos imutáveis', async () => {
    const gestorDominio = new Empregado({ cpf: '11122233300', lotacao: 'DIDES/SUPDR', dataDesligamento: null });
    const responsavelUX = new Empregado({ cpf: '22233344400', lotacao: 'DIDES/SUPSE', dataDesligamento: null });
    repositoryDominio.findOneById.mockResolvedValue(antigo);
    repositoryEmpregado.findManyByCPF.mockResolvedValue([gestorDominio, responsavelUX]);
    const value = {
      id: 'abc',
      nome: 'Teste',
      codigo: '0002',
      situacao: SituacaoDominio.INATIVO,
      categoria: CategoriaDominio.PRODUTO,
      ugDominio: 'SUPDG',
      gestorDominio: { cpf: '11122233300' },
      responsavelUX: { cpf: '22233344400' },
    };
    const dominio = await pipe.transform(value);
    expect(dominio.codigo).toStrictEqual(antigo.codigo);
    expect(dominio.situacao).toStrictEqual(antigo.situacao);
    expect(dominio.categoria).toStrictEqual(antigo.categoria);
    expect(dominio.nome).toStrictEqual(value.nome);
    expect(dominio.ugDominio).toStrictEqual(value.ugDominio);
    expect(dominio.gestorDominio).toStrictEqual(gestorDominio);
    expect(dominio.responsavelUX).toStrictEqual(responsavelUX);
  });
});
