import 'jest';

import { BadRequestException } from '@nestjs/common';
import { CategoriaDominio } from '../../../../src/modules/dominio/CategoriaDominio';
import { DominioPipeInserir } from '../../../../src/modules/dominio/DominioPipeInserir';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { SituacaoDominio } from '../../../../src/modules/dominio/SituacaoDominio';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';

jest.mock('../../../../src/modules/empregado/EmpregadoRepository');
jest.mock('../../../../src/modules/dominio/DominioRepository');

describe('unit/modules/dominio/DominioPipeInserirTest', () => {
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const pipe = new DominioPipeInserir(repositoryDominio, repositoryEmpregado);
  const gestorDominio = new Empregado({ cpf: '11122233300', lotacao: 'DIDES/SUPDR', dataDesligamento: null });
  const responsavelUX = new Empregado({ cpf: '22233344400', lotacao: 'DIDES/SUPSE', dataDesligamento: null });
  const value = {
    id: 'abc',
    codigo: '0001',
    ugDominio: 'SUPSE',
    nome: 'Novo',
    descricao: 'Descrição',
    gestorDominio: { cpf: gestorDominio.cpf },
    responsavelUX: { cpf: responsavelUX.cpf },
    situacao: SituacaoDominio.INATIVO,
    categoria: CategoriaDominio.NEGOCIO,
  };

  beforeEach(() => {
    repositoryEmpregado.findManyByCPF.mockClear();
    repositoryDominio.findNextCodigo.mockClear();
    repositoryEmpregado.findManyByCPF.mockResolvedValue([gestorDominio, responsavelUX]);
    repositoryDominio.findNextCodigo.mockResolvedValue('0030');
  });

  it('sem nome', async () => {
    const param = { ...value, nome: undefined };
    await expect(pipe.transform(param)).rejects.toThrow(BadRequestException);
  });

  it('sem categoria', async () => {
    const param = { ...value, categoria: undefined };
    await expect(pipe.transform(param)).rejects.toThrow(BadRequestException);
  });

  it('sem ug', async () => {
    const param = { ...value, ugDominio: undefined };
    await expect(pipe.transform(param)).rejects.toThrow(BadRequestException);
  });

  it('com sucesso', async () => {
    const dominio = await pipe.transform(value);
    expect(dominio.codigo).toStrictEqual('0030');
    expect(dominio.situacao).toStrictEqual(SituacaoDominio.ATIVO);
    expect(dominio.categoria).toStrictEqual(value.categoria);
    expect(dominio.nome).toStrictEqual(value.nome);
    expect(dominio.ugDominio).toStrictEqual(value.ugDominio);
    expect(dominio.gestorDominio).toStrictEqual(gestorDominio);
    expect(dominio.responsavelUX).toStrictEqual(responsavelUX);
  });
});
