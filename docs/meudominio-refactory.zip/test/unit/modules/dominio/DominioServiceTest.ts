import 'jest';

import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { CacheAdapterFactory } from '../../../../src/common/cache/CacheAdapterFactory';
import { CacheAdapter } from '../../../../src/common/cache/CacheAdapterRedis';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { AlocacaoRateioService } from '../../../../src/modules/alocacao/AlocacaoRateioService';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { Perfil } from '../../../../src/modules/usuario/Perfil';
import { Sort } from '../../../../src/common/query/Sort';
import { DominioCriteria } from '../../../../src/modules/dominio/DominioCriteria';
import { DominioService } from '../../../../src/modules/dominio/DominioService';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';

jest.mock('../../../../src/modules/dominio/DominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/common/cache/CacheAdapterRedis');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioService');

const cache = new CacheAdapter(null) as jest.Mocked<CacheAdapter>;
CacheAdapterFactory.prototype.getInstance = () => {
  return cache;
};

describe('unit/modules/dominio/DominioServiceTest', () => {
  const repository = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const alocacao = new AlocacaoRateioService(null, null, null, null, null) as jest.Mocked<AlocacaoRateioService>;
  const service = new DominioService(repository, security, cache, alocacao);
  const dominio = new Dominio({ codigo: '0001', nome: 'Teste', ugDominio: 'SUPSE', gestorDominio: new Empregado({ cpf: '11122233300' }) });

  beforeEach(() => {
    cache.hdel.mockClear();
    repository.insert.mockClear();
    repository.update.mockClear();
    repository.findOneById.mockClear();
    repository.findOneByCodigo.mockClear();
    repository.findAll.mockClear();
    alocacao.atualizarPorEscopo.mockClear();
  });

  describe('inserir', () => {
    it('usuário sem permissão', async () => {
      const usuario = new Usuario({ perfis: [Perfil.GESTOR_ALOCACAO], gestorDominio: ['abc'] });
      security.getRequestUser.mockReturnValue(usuario);
      await expect(service.inserir(dominio)).rejects.toThrow(ForbiddenException);
    });

    it('usuário administrador', async () => {
      const usuario = new Usuario({ perfis: [Perfil.ADMINISTRADOR], gestorDominio: ['abc'] });
      security.getRequestUser.mockReturnValue(usuario);
      repository.insert.mockResolvedValue('abcdef');
      const id = await service.inserir(dominio);
      expect(id).toStrictEqual('abcdef');
      expect(repository.insert).toBeCalledTimes(1);
      expect(repository.insert).toBeCalledWith(dominio);
      expect(cache.hdel).toBeCalledWith('USUARIO', dominio.gestorDominio.cpf);
    });

    it('usuário cadastrador', async () => {
      const usuario = new Usuario({ perfis: [Perfil.CADASTRADOR_DOMINIO], gestorDominio: ['abc'] });
      security.getRequestUser.mockReturnValue(usuario);
      repository.insert.mockResolvedValue('abcdef');
      await service.inserir(dominio);
      expect(true).toStrictEqual(true);
    });
  });

  describe('alterar', () => {
    it('sem permissão', async () => {
      const usuario = new Usuario();
      security.getRequestUser.mockReturnValue(usuario);
      await expect(service.alterar(dominio)).rejects.toThrow(ForbiddenException);
    });

    it('inexistente', async () => {
      const usuario = new Usuario({ perfis: [Perfil.ADMINISTRADOR] });
      security.getRequestUser.mockReturnValue(usuario);
      repository.findOneById.mockResolvedValue(null);
      await expect(service.alterar(dominio)).rejects.toThrow(NotFoundException);
    });

    it('sem alteração do gestor', async () => {
      const usuario = new Usuario({ perfis: [Perfil.ADMINISTRADOR] });
      security.getRequestUser.mockReturnValue(usuario);
      repository.findOneById.mockResolvedValue(new Dominio({ ugDominio: 'SUPDR', gestorDominio: dominio.gestorDominio }));
      await service.alterar(dominio);
      expect(repository.update).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledTimes(0);
      expect(alocacao.atualizarPorEscopo).toBeCalledTimes(1);
      expect(alocacao.atualizarPorEscopo).toBeCalledWith('SUPDR', 'SUPSE');
    });

    it('com alteração do gestor', async () => {
      const usuario = new Usuario({ perfis: [Perfil.ADMINISTRADOR] });
      security.getRequestUser.mockReturnValue(usuario);
      repository.findOneById.mockResolvedValue(
        new Dominio({ ugDominio: dominio.ugDominio, gestorDominio: new Empregado({ cpf: '22233344400' }) }),
      );
      await service.alterar(dominio);
      expect(repository.update).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledWith('USUARIO', '22233344400', dominio.gestorDominio.cpf);
      expect(alocacao.atualizarPorEscopo).toBeCalledTimes(0);
    });
  });

  describe('findOneByCodigo', () => {
    it('inexistente', async () => {
      repository.findOneByCodigo.mockResolvedValue(null);
      await expect(service.findOneByCodigo('0001')).rejects.toThrow(NotFoundException);
    });

    it('sucesso', async () => {
      repository.findOneByCodigo.mockResolvedValue(dominio);
      const result = await service.findOneByCodigo('0001', 'id-codigo-nome-categoria-ugDominio');
      expect(result).toStrictEqual(dominio);
      expect(repository.findOneByCodigo).toBeCalledTimes(1);
      expect(repository.findOneByCodigo).toBeCalledWith('0001', 'id-codigo-nome-categoria-ugDominio');
    });
  });

  it('findMany', async () => {
    const dominios = [dominio];
    const criteria = new DominioCriteria({ servico: '23117' });
    const sort = Sort.by('dominio.nome');
    repository.findAll.mockResolvedValue(dominios);
    const result = await service.findMany('*-subdominios.(*.sistemas.*)', criteria, sort);
    expect(repository.findAll).toBeCalledTimes(1);
    expect(repository.findAll).toBeCalledWith('*-subdominios.(*.sistemas.*)', criteria, sort);
    expect(result).toStrictEqual(dominios);
  });
});
