import 'jest';

import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';

describe('unit/modules/empregado/EmpregadoEntityTest', () => {
  it('isChefe', async () => {
    expect(() => new Empregado({}).isChefe).toThrowError('[Empregado].funcaoConfianca não carregado');
    expect(new Empregado({ funcaoConfianca: null }).isChefe).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'CHEFE DE SETOR' }).isChefe).toStrictEqual(true);
  });

  it('isDIDES', async () => {
    expect(() => new Empregado().isDIDES).toThrowError('[Empregado].lotacao não carregado');
    expect(new Empregado({ lotacao: 'DIDES/SUPDR' }).isDIDES).toStrictEqual(true);
    expect(new Empregado({ lotacao: 'DIRCL/SUNEF' }).isDIDES).toStrictEqual(false);
  });

  it('isCOADM', async () => {
    expect(() => new Empregado().isCOADM).toThrowError('[Empregado].lotacao não carregado');
    expect(new Empregado({ lotacao: 'DIDES/SUPDR' }).isCOADM).toStrictEqual(false);
    expect(new Empregado({ lotacao: 'DIRCL/SUNEF' }).isCOADM).toStrictEqual(false);
    expect(new Empregado({ lotacao: 'DIDES/COADM/ADSGE' }).isCOADM).toStrictEqual(true);
  });

  it('isSuperintendente', async () => {
    expect(new Empregado({ funcaoConfianca: null }).isSuperintendente).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'CHEFE DE SETOR' }).isSuperintendente).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'SUPERINTENDENTE' }).isSuperintendente).toStrictEqual(true);
  });

  it('isAssessorDiretoria', async () => {
    expect(new Empregado({ funcaoConfianca: null }).isAssessorDiretoria).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'SUPERINTENDENTE' }).isAssessorDiretoria).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'ASSESSOR DIRETORIA II' }).isAssessorDiretoria).toStrictEqual(true);
  });

  it('isDiretor', async () => {
    expect(new Empregado({ funcaoConfianca: null }).isDiretor).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'SUPERINTENDENTE' }).isDiretor).toStrictEqual(false);
    expect(new Empregado({ funcaoConfianca: 'DIRETOR' }).isDiretor).toStrictEqual(true);
  });

  it('isAlocavel', async () => {
    expect(() => new Empregado({ dataDesligamento: null }).isAlocavel).toThrowError('[Empregado].lotacao não carregado');
    expect(new Empregado({ lotacao: 'DIRCL/SUNEF/EFGCE', dataDesligamento: null, funcaoConfianca: null }).isAlocavel).toStrictEqual(false);
    expect(new Empregado({ lotacao: 'DIDES/SUPDR/DRAPA', dataDesligamento: null, funcaoConfianca: null }).isAlocavel).toStrictEqual(true);
    expect(new Empregado({ lotacao: 'DIDES/SUPDR/DRAPA', dataDesligamento: new Date(), funcaoConfianca: null }).isAlocavel).toStrictEqual(
      false,
    );
    expect(
      new Empregado({ funcaoConfianca: 'CHEFE DE SETOR', lotacao: 'DIRCL/SUNEF/EFGCE', dataDesligamento: null }).isAlocavel,
    ).toStrictEqual(false);
    expect(
      new Empregado({ funcaoConfianca: 'CHEFE DE SETOR', lotacao: 'DIDES/SUPDR/DRAPA', dataDesligamento: null }).isAlocavel,
    ).toStrictEqual(true);
    expect(new Empregado({ funcaoConfianca: 'SUPERINTENDENTE', lotacao: 'DIDES/SUPDR', dataDesligamento: null }).isAlocavel).toStrictEqual(
      false,
    );
    expect(new Empregado({ funcaoConfianca: 'ASSESSOR DIRETORIA II', lotacao: 'DIDES', dataDesligamento: null }).isAlocavel).toStrictEqual(
      false,
    );
    expect(new Empregado({ funcaoConfianca: 'DIRETOR', lotacao: 'DIDES', dataDesligamento: null }).isAlocavel).toStrictEqual(false);
  });
});
