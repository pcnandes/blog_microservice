import 'jest';

import { GrupoGoviCriteria } from '../../../../src/modules/grupogovi/GrupoGoviCriteria';

describe('unit/modules/grupogovi/GrupoGoviCriteriaTest', () => {
  it('sigla', () => {
    const criteria = new GrupoGoviCriteria({ sigla: 'GSDE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual('(grupogovi.sigla ILIKE :sigla)');
    expect(where.getParameters()).toStrictEqual({ sigla: 'GSDE%' });
  });

  it('ativo', () => {
    const criteria = new GrupoGoviCriteria({ ativo: '' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual(`(COALESCE(grupogovi.situacao,'ATIVO') = 'ATIVO')`);
    expect(where.getParameters()).toStrictEqual({});
  });

  it('dides', () => {
    const criteria = new GrupoGoviCriteria({ dides: true });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual(
      `((grupogovi.ug in ('SUPDE', 'SUPDA', 'SUPST', 'SUPSS', 'SUPSD', 'SUPDR', 'SUPDG', 'SUPAI', 'SUPSE')` +
        ` OR grupogovi.sigla ilike 'GSDE%'` +
        ` OR grupogovi.sigla ilike 'GSDA%'` +
        ` OR grupogovi.sigla ilike 'GSSS%'` +
        ` OR grupogovi.sigla ilike 'GSSD%'))`,
    );
    expect(where.getParameters()).toStrictEqual({});
  });

  it('ug', () => {
    const criteria = new GrupoGoviCriteria({ ug: 'supde' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual('(grupogovi.ug = :ug)');
    expect(where.getParameters()).toStrictEqual({ ug: 'SUPDE' });
  });
});
