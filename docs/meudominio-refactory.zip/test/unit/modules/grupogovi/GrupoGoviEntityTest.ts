import 'jest';

import { GrupoGovi } from '../../../../src/modules/grupogovi/GrupoGoviEntity';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';

describe('unit/modules/grupogovi/GrupoGoviEntityTest', () => {
  it('isDIDES', () => {
    expect(new GrupoGovi({ sigla: 'GSDE', ug: null }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: 'GSSDABC', ug: null }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: 'GSDA', ug: null }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: 'GSSSXPTO', ug: null }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: 'GMRJ', ug: null }).isDIDES).toStrictEqual(false);
    expect(new GrupoGovi({ sigla: '12345', ug: null }).isDIDES).toStrictEqual(false);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPDE' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPDA' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPST' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPSD' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPSS' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPSE' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPDR' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPDG' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUPAI' }).isDIDES).toStrictEqual(true);
    expect(new GrupoGovi({ sigla: '12345', ug: 'SUNEF' }).isDIDES).toStrictEqual(false);
    expect(() => new GrupoGovi().isDIDES).toThrowError('[GrupoGovi].sigla não carregado');
    expect(() => new GrupoGovi({ sigla: 'GSDAXXX' }).isDIDES).toThrowError('[GrupoGovi].ug não carregado');
    const grupogovi = new GrupoGovi({
      sigla: 'GSDAXXX',
      recorrencia1: { cpf: '11122233300' },
      recorrencia2: { cpf: '22233344400' },
      recorrencia3: { cpf: '33344455500' },
      recorrencia4: { cpf: '44455566600' },
    });
    expect(grupogovi.recorrencia1).toBeInstanceOf(Empregado);
    expect(grupogovi.recorrencia2).toBeInstanceOf(Empregado);
    expect(grupogovi.recorrencia3).toBeInstanceOf(Empregado);
    expect(grupogovi.recorrencia4).toBeInstanceOf(Empregado);
  });

  it('ativo', () => {
    expect(new GrupoGovi({ situacao: null }).ativo).toStrictEqual(true);
    expect(new GrupoGovi({ situacao: 'ATIVO' }).ativo).toStrictEqual(true);
    expect(new GrupoGovi({ situacao: 'INATIVO' }).ativo).toStrictEqual(false);
    expect(() => new GrupoGovi().ativo).toThrowError('[GrupoGovi].situacao não carregado');
  });
});
