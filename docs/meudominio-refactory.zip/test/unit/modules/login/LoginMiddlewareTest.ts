import 'jest';

import { LoginMiddleware } from '../../../../src/modules/login/LoginMiddleware';
import { UsuarioService } from '../../../../src/modules/usuario/UsuarioService';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { CacheAdapter } from '../../../../src/common/cache/CacheAdapterRedis';
import { CacheAdapterFactory } from '../../../../src/common/cache/CacheAdapterFactory';
import { mock } from 'jest-mock-extended';
import { set } from 'lodash';
import { Request, Response } from 'express';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { Perfil } from '../../../../src/modules/usuario/Perfil';
import { NotFoundException } from '@nestjs/common';

jest.mock('../../../../src/modules/usuario/UsuarioService');
jest.mock('../../../../src/common/cache/CacheAdapterRedis');

const cache = new CacheAdapter(null) as jest.Mocked<CacheAdapter>;
CacheAdapterFactory.prototype.getInstance = () => {
  return cache;
};

describe('unit/modules/login/LoginMiddlewareTest', () => {
  const serviceUsuario = new UsuarioService(null, null, null, null, null) as jest.Mocked<UsuarioService>;
  const middleware = new LoginMiddleware(serviceUsuario);
  const security = new SecurityContext();
  const request = mock<Request>();
  const response = mock<Response>();

  beforeEach(() => {
    serviceUsuario.buscarPorUsername.mockClear();
    cache.hget.mockClear();
    cache.hget.mockResolvedValue(null);
  });

  it('sem token', async () => {
    set(request, 'kauth', null);
    const promise = new Promise((resolve, reject) => {
      middleware.use(request, response, () => {
        resolve(security.getRequestUser());
      });
    });
    await expect(promise).resolves.toStrictEqual(null);
    expect(serviceUsuario.buscarPorUsername).toBeCalledTimes(0);
  });

  it('usuário de serviço', async () => {
    const usuario = new Usuario({ username: 'AESP' });
    serviceUsuario.buscarPorUsername.mockResolvedValue(usuario);
    set(request, 'kauth.grant.access_token.content.username', usuario.username);
    const promise = new Promise((resolve, reject) => {
      middleware.use(request, response, () => {
        resolve(security.getRequestUser());
      });
    });
    await expect(promise).resolves.toStrictEqual(usuario);
    expect(serviceUsuario.buscarPorUsername).toBeCalledTimes(1);
  });

  it('empregado não encontrado', async () => {
    serviceUsuario.buscarPorUsername.mockRejectedValue(new NotFoundException());
    set(request, 'kauth.grant.access_token.content.username', '22233344400');
    const promise = new Promise((resolve, reject) => {
      middleware.use(request, response, () => {
        resolve(security.getRequestUser());
      });
    });
    await expect(promise).resolves.toStrictEqual(null);
    expect(serviceUsuario.buscarPorUsername).toBeCalledTimes(1);
  });

  it('sucesso', async () => {
    const usuario = new Usuario({
      username: '11122233300',
      empregado: new Empregado({ cpf: '11122233300' }),
      perfis: [Perfil.ADMINISTRADOR],
    });
    serviceUsuario.buscarPorUsername.mockResolvedValue(usuario);
    set(request, 'kauth.grant.access_token.content.username', usuario.username);
    const promise = new Promise((resolve, reject) => {
      middleware.use(request, response, () => {
        resolve(security.getRequestUser());
      });
    });
    await expect(promise).resolves.toStrictEqual(usuario);
    expect(serviceUsuario.buscarPorUsername).toBeCalledTimes(1);
  });
});
