import 'jest';

import { BadRequestException } from '@nestjs/common';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Permissao } from '../../../../src/modules/permissao/PermissaoEntity';
import { PermissaoPipe } from '../../../../src/modules/permissao/PermissaoPipe';

jest.mock('../../../../src/modules/empregado/EmpregadoRepository');
jest.mock('../../../../src/modules/dominio/DominioRepository');

describe('unit/modules/permissao/PermissaoPipeTest', () => {
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const pipe = new PermissaoPipe(repositoryDominio, repositoryEmpregado);

  beforeEach(() => {
    repositoryDominio.findManyById.mockClear();
    repositoryEmpregado.findManyByCPF.mockClear();
  });

  it('inválidas', async () => {
    await expect(
      pipe.transform(
        [{ empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d' }, { empregado: { cpf: '456' } }],
        null,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(repositoryDominio.findManyById).toBeCalledTimes(0);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledTimes(0);
  });

  it('ambíguas', async () => {
    await expect(
      pipe.transform(
        [
          { empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.EDITAR] },
          { empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.ALOCAR] },
        ],
        null,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(repositoryDominio.findManyById).toBeCalledTimes(0);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledTimes(0);
  });

  it('empregado inexistente', async () => {
    repositoryEmpregado.findManyByCPF.mockResolvedValue([new Empregado({ cpf: '123' })]);
    await expect(
      pipe.transform(
        [
          { empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.EDITAR] },
          { empregado: { cpf: '123' }, dominioID: '647484b9-d595-4378-914b-443b3533658d', operacoes: [Operacao.EDITAR] },
          { empregado: { cpf: '456' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.ALOCAR] },
        ],
        null,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledTimes(1);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledWith(['123', '456'], 'cpf');
    expect(repositoryDominio.findManyById).toBeCalledTimes(0);
  });

  it('domínio inexistente', async () => {
    repositoryEmpregado.findManyByCPF.mockResolvedValue([new Empregado({ cpf: '123' }), new Empregado({ cpf: '456' })]);
    repositoryDominio.findManyById.mockResolvedValue([new Dominio({ id: 'c8cf4280-82d3-4a44-96eb-80786abaa37d' })]);
    await expect(
      pipe.transform(
        [
          { empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.EDITAR] },
          { empregado: { cpf: '123' }, dominioID: '647484b9-d595-4378-914b-443b3533658d', operacoes: [Operacao.EDITAR] },
          { empregado: { cpf: '456' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.ALOCAR] },
        ],
        null,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledTimes(1);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledWith(['123', '456'], 'cpf');
    expect(repositoryDominio.findManyById).toBeCalledTimes(1);
    expect(repositoryDominio.findManyById).toBeCalledWith(
      ['c8cf4280-82d3-4a44-96eb-80786abaa37d', '647484b9-d595-4378-914b-443b3533658d'],
      'id',
    );
  });

  it('sucesso', async () => {
    repositoryEmpregado.findManyByCPF.mockResolvedValue([new Empregado({ cpf: '123' }), new Empregado({ cpf: '456' })]);
    repositoryDominio.findManyById.mockResolvedValue([
      new Dominio({ id: 'c8cf4280-82d3-4a44-96eb-80786abaa37d' }),
      new Dominio({ id: '647484b9-d595-4378-914b-443b3533658d' }),
    ]);
    const p1 = { empregado: { cpf: '123' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.EDITAR] };
    const p2 = { empregado: { cpf: '123' }, dominioID: '647484b9-d595-4378-914b-443b3533658d', operacoes: [Operacao.EDITAR] };
    const p3 = { empregado: { cpf: '456' }, dominioID: 'c8cf4280-82d3-4a44-96eb-80786abaa37d', operacoes: [Operacao.ALOCAR] };
    await expect(pipe.transform([p1, p2, p3], null)).resolves.toStrictEqual([new Permissao(p1), new Permissao(p2), new Permissao(p3)]);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledTimes(1);
    expect(repositoryEmpregado.findManyByCPF).toBeCalledWith(['123', '456'], 'cpf');
    expect(repositoryDominio.findManyById).toBeCalledTimes(1);
    expect(repositoryDominio.findManyById).toBeCalledWith(
      ['c8cf4280-82d3-4a44-96eb-80786abaa37d', '647484b9-d595-4378-914b-443b3533658d'],
      'id',
    );
  });
});
