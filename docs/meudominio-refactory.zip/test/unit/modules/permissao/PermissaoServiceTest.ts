import 'jest';

import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { CacheAdapter } from '../../../../src/common/cache/CacheAdapterRedis';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Permissao } from '../../../../src/modules/permissao/PermissaoEntity';
import { PermissaoRepository } from '../../../../src/modules/permissao/PermissaoRepository';
import { PermissaoService } from '../../../../src/modules/permissao/PermissaoService';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';

jest.mock('../../../../src/modules/permissao/PermissaoRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');
jest.mock('../../../../src/common/cache/CacheAdapterRedis');

describe('unit/modules/permissao/PermissaoServiceTest', () => {
  const cache = new CacheAdapter(null) as jest.Mocked<CacheAdapter>;
  const repository = new PermissaoRepository(null, null) as jest.Mocked<PermissaoRepository>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const service = new PermissaoService(repository, security, cache);
  const usuario = new Usuario() as jest.Mocked<Usuario>;

  beforeEach(() => {
    cache.hdel.mockClear();
    repository.insertAll.mockClear();
    repository.updateAll.mockClear();
    repository.deleteAll.mockClear();
    repository.findManyByDominio.mockClear();
    repository.findManyByEmpregado.mockClear();
    security.getRequestUser.mockReturnValue(usuario);
    usuario.podeAlterarDominio.mockClear();
  });

  describe('alterarPermissoesPorEmpregado', () => {
    it('empregados diferentes', async () => {
      await expect(service.alterarPermissoesPorEmpregado('123', new Permissao({ empregado: { cpf: '456' } }))).rejects.toThrow(
        BadRequestException,
      );
      expect(repository.findManyByEmpregado).toBeCalledTimes(0);
      expect(usuario.podeAlterarDominio).toBeCalledTimes(0);
      expect(cache.hdel).toBeCalledTimes(0);
      expect(repository.insertAll).toBeCalledTimes(0);
      expect(repository.updateAll).toBeCalledTimes(0);
      expect(repository.deleteAll).toBeCalledTimes(0);
    });

    it('sem permissão', async () => {
      usuario.podeAlterarDominio.mockReturnValue(false);
      repository.findManyByEmpregado.mockResolvedValue([new Permissao({ empregado: { cpf: '123' }, dominioID: 'xyz' })]);
      await expect(service.alterarPermissoesPorEmpregado('123')).rejects.toThrow(ForbiddenException);
      expect(usuario.podeAlterarDominio).toBeCalledTimes(1);
      expect(usuario.podeAlterarDominio).toBeCalledWith('xyz');
      expect(repository.findManyByEmpregado).toBeCalledTimes(1);
      expect(repository.findManyByEmpregado).toBeCalledWith('123');
      expect(cache.hdel).toBeCalledTimes(0);
      expect(repository.insertAll).toBeCalledTimes(0);
      expect(repository.updateAll).toBeCalledTimes(0);
      expect(repository.deleteAll).toBeCalledTimes(0);
    });

    it('com sucesso', async () => {
      usuario.podeAlterarDominio.mockReturnValue(true);
      repository.findManyByEmpregado.mockResolvedValue([
        new Permissao({ pk: '444', empregado: { cpf: '123' }, dominioID: 'abc', operacoes: [Operacao.CUSTOS] }),
        new Permissao({ pk: '555', empregado: { cpf: '123' }, dominioID: 'ghi', operacoes: [Operacao.CUSTOS] }),
        new Permissao({ pk: '666', empregado: { cpf: '123' }, dominioID: 'xyz', operacoes: [Operacao.CUSTOS] }),
      ]);
      await service.alterarPermissoesPorEmpregado(
        '123',
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'abc' }),
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'def', operacoes: [Operacao.ALOCAR, Operacao.EDITAR] }),
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'ghi', operacoes: [Operacao.EDITAR] }),
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'jkl' }),
      );
      expect(usuario.podeAlterarDominio).toBeCalledTimes(5);
      expect(cache.hdel).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledWith('USUARIO', '123');
      expect(repository.insertAll).toBeCalledTimes(1);
      expect(repository.updateAll).toBeCalledTimes(1);
      expect(repository.deleteAll).toBeCalledTimes(1);
      expect(repository.insertAll).toBeCalledWith(
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'def', operacoes: [Operacao.ALOCAR, Operacao.EDITAR] }),
      );
      expect(repository.updateAll).toBeCalledWith(
        new Permissao({ pk: '555', empregado: { cpf: '123' }, dominioID: 'ghi', operacoes: [Operacao.EDITAR] }),
      );
      expect(repository.deleteAll).toBeCalledWith('666', '444');
    });
  });

  describe('alterarPermissoesPorDominio', () => {
    it('domínios diferentes', async () => {
      await expect(service.alterarPermissoesPorDominio('abc', new Permissao({ dominioID: 'xyz' }))).rejects.toThrow(BadRequestException);
      expect(repository.findManyByEmpregado).toBeCalledTimes(0);
      expect(usuario.podeAlterarDominio).toBeCalledTimes(0);
      expect(cache.hdel).toBeCalledTimes(0);
      expect(repository.insertAll).toBeCalledTimes(0);
      expect(repository.updateAll).toBeCalledTimes(0);
      expect(repository.deleteAll).toBeCalledTimes(0);
    });

    it('com sucesso', async () => {
      usuario.podeAlterarDominio.mockReturnValue(true);
      repository.findManyByDominio.mockResolvedValue([
        new Permissao({ pk: '444', empregado: { cpf: '123' }, dominioID: 'abc', operacoes: [Operacao.CUSTOS] }),
        new Permissao({ pk: '555', empregado: { cpf: '456' }, dominioID: 'abc', operacoes: [Operacao.CUSTOS] }),
        new Permissao({ pk: '666', empregado: { cpf: '654' }, dominioID: 'abc', operacoes: [Operacao.CUSTOS] }),
      ]);
      await service.alterarPermissoesPorDominio(
        'abc',
        new Permissao({ empregado: { cpf: '123' }, dominioID: 'abc' }),
        new Permissao({ empregado: { cpf: '456' }, dominioID: 'abc', operacoes: [Operacao.ALOCAR, Operacao.EDITAR] }),
        new Permissao({ empregado: { cpf: '789' }, dominioID: 'abc', operacoes: [Operacao.EDITAR] }),
        new Permissao({ empregado: { cpf: '321' }, dominioID: 'abc' }),
      );
      expect(usuario.podeAlterarDominio).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledTimes(1);
      expect(cache.hdel).toBeCalledWith('USUARIO', '123', '456', '654', '789', '321');
      expect(repository.insertAll).toBeCalledTimes(1);
      expect(repository.updateAll).toBeCalledTimes(1);
      expect(repository.deleteAll).toBeCalledTimes(1);
      expect(repository.insertAll).toBeCalledWith(
        new Permissao({ empregado: { cpf: '789' }, dominioID: 'abc', operacoes: [Operacao.EDITAR] }),
      );
      expect(repository.updateAll).toBeCalledWith(
        new Permissao({ pk: '555', empregado: { cpf: '456' }, dominioID: 'abc', operacoes: [Operacao.ALOCAR, Operacao.EDITAR] }),
      );
      expect(repository.deleteAll).toBeCalledWith('666', '444');
    });
  });

  it('findManyByEmpregado', async () => {
    const permissoes = [new Permissao({ dominioID: 'abc', empregado: { cpf: '123' }, operacoes: [Operacao.EDITAR] })];
    const param = '123';
    repository.findManyByEmpregado.mockResolvedValue(permissoes);
    await expect(service.findManyByEmpregado(param)).resolves.toStrictEqual(permissoes);
    expect(repository.findManyByEmpregado).toBeCalledTimes(1);
    expect(repository.findManyByEmpregado).toBeCalledWith(param);
  });

  it('findManyByDominio', async () => {
    const permissoes = [new Permissao({ dominioID: 'abc', empregado: { cpf: '123' }, operacoes: [Operacao.EDITAR] })];
    const param = 'abc';
    repository.findManyByDominio.mockResolvedValue(permissoes);
    await expect(service.findManyByDominio(param)).resolves.toStrictEqual(permissoes);
    expect(repository.findManyByDominio).toBeCalledTimes(1);
    expect(repository.findManyByDominio).toBeCalledWith(param);
  });
});
