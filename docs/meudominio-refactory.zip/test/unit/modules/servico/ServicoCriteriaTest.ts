import 'jest';

import { ServicoCriteria } from '../../../../src/modules/servico/ServicoCriteria';

describe('unit/modules/sistema/SistemaCriteriaTest', () => {
  it('ug', () => {
    const criteria = new ServicoCriteria({ ug: 'supdg' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual('(servico.ug = :ug)');
    expect(where.getParameters()).toStrictEqual({ ug: 'SUPDG' });
  });

  it('codigo', () => {
    const criteria = new ServicoCriteria({ codigo: '123-456-789' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual(`(servico.codigo IN (:...codigo))`);
    expect(where.getParameters()).toStrictEqual({ codigo: [123, 456, 789] });
  });

  it('ativo', () => {
    const criteria = new ServicoCriteria({ ativo: '' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual('(servico.dataDesativacao IS NULL)');
    expect(where.getParameters()).toStrictEqual({});
  });

  it('padrao', () => {
    const criteria = new ServicoCriteria({ padrao: true });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual('(servico.padrao = true)');
    expect(where.getParameters()).toStrictEqual({});
  });

  it('titulo', () => {
    const criteria = new ServicoCriteria({ titulo: 'teste' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual(`((COALESCE(servico.mnemonico,'') ILIKE :titulo OR COALESCE(servico.titulo,'') ILIKE :titulo))`);
    expect(where.getParameters()).toStrictEqual({ titulo: '%teste%' });
  });

  it('cliente', () => {
    const criteria = new ServicoCriteria({ cliente: 'teste' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual([]);
    expect(where.toString()).toStrictEqual(`(servico.cliente ILIKE :cliente)`);
    expect(where.getParameters()).toStrictEqual({ cliente: '%teste%' });
  });
});
