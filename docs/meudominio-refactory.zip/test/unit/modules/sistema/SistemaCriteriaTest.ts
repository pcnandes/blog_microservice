import 'jest';

import { SistemaCriteria } from '../../../../src/modules/sistema/SistemaCriteria';

describe('unit/modules/sistema/SistemaCriteriaTest', () => {
  it('ug', () => {
    const criteria = new SistemaCriteria({ ug: 'supdg' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['servicos.servico', 'subdominio.dominio']);
    expect(where.toString()).toStrictEqual(
      '((sistema_subdominio_dominio.ugDominio = :ug OR sistema_subdominio_dominio.ugNegocio = :ug OR sistema_servicos_servico.ug = :ug))',
    );
    expect(where.getParameters()).toStrictEqual({ ug: 'SUPDG' });
  });

  it('servico texto', () => {
    const criteria = new SistemaCriteria({ servico: 'SIGEPE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['servicos.servico']);
    expect(where.toString()).toStrictEqual(
      '((sistema_servicos_servico.mnemonico ILIKE :servico' + ' OR sistema_servicos_servico.titulo ILIKE :servico))',
    );
    expect(where.getParameters()).toStrictEqual({ servico: '%SIGEPE%' });
  });

  it('servico numero', () => {
    const criteria = new SistemaCriteria({ servico: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['servicos.servico']);
    expect(where.toString()).toStrictEqual('(sistema_servicos_servico.codigo = :servico)');
    expect(where.getParameters()).toStrictEqual({ servico: 92116 });
  });

  it('search texto', () => {
    const criteria = new SistemaCriteria({ search: 'teste' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['servicos.servico', 'subdominio.dominio', 'servicos']);
  });

  it('search numero', () => {
    const criteria = new SistemaCriteria({ search: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['servicos.servico', 'subdominio.dominio', 'servicos']);
  });
});
