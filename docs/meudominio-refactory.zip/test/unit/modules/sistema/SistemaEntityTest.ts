import 'jest';

import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { CategoriaDominio } from '../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from '../../../../src/modules/sistema/LinhaNegocio';

describe('unit/modules/sistema/SistemaEntityTest', () => {
  it('isProduto', () => {
    expect(() => new Sistema().isProduto).toThrowError('[Sistema].linhaNegocio não carregado');
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO }).isProduto).toStrictEqual(true);
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_NUVEM }).isProduto).toStrictEqual(true);
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA }).isProduto).toStrictEqual(false);
  });

  it('isProdutoDependente', () => {
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA }).isProdutoDependente).toStrictEqual(false);
    expect(() => new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO }).isProdutoDependente).toThrowError(
      '[Sistema].subdominio.dominio.categoria não carregado',
    );
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.PRODUTO } } })
        .isProdutoDependente,
    ).toStrictEqual(false);
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.NEGOCIO } } })
        .isProdutoDependente,
    ).toStrictEqual(true);
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.INTERNO } } })
        .isProdutoDependente,
    ).toStrictEqual(true);
  });

  it('isProdutoIndependente', () => {
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA }).isProdutoIndependente).toStrictEqual(false);
    expect(() => new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO }).isProdutoIndependente).toThrowError(
      '[Sistema].subdominio.dominio.categoria não carregado',
    );
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.PRODUTO } } })
        .isProdutoIndependente,
    ).toStrictEqual(true);
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.NEGOCIO } } })
        .isProdutoIndependente,
    ).toStrictEqual(false);
    expect(
      new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO, subdominio: { dominio: { categoria: CategoriaDominio.INTERNO } } })
        .isProdutoIndependente,
    ).toStrictEqual(false);
  });

  it('isSobMedida', () => {
    expect(() => new Sistema().isSobMedida).toThrowError('[Sistema].linhaNegocio não carregado');
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO }).isSobMedida).toStrictEqual(false);
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_NUVEM }).isSobMedida).toStrictEqual(false);
    expect(new Sistema({ linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA }).isSobMedida).toStrictEqual(true);
  });

  it('codigoServicoPrincipal', () => {
    expect(() => new Sistema().codigoServicoPrincipal).toThrowError('[Sistema].servicos não carregado');
    expect(() => new Sistema({ servicos: [{ principal: true }] }).codigoServicoPrincipal).toThrowError(
      '[SistemaServico].servico.codigo não carregado',
    );
    expect(() => new Sistema({ servicos: [{ principal: true, servico: { mnemonico: 'ABC' } }] }).codigoServicoPrincipal).toThrowError(
      '[SistemaServico].servico.codigo não carregado',
    );
    expect(new Sistema({ servicos: [{ principal: true, servico: { codigo: 92116 } }] }).codigoServicoPrincipal).toStrictEqual(92116);
  });

  it('codigoServicoAdicional', () => {
    expect(() => new Sistema().codigoServicoAdicional).toThrowError('[Sistema].servicos não carregado');
    expect(() => new Sistema({ servicos: [{ percentual: 100 }] }).codigoServicoAdicional).toThrowError(
      '[SistemaServico].servico.codigo não carregado',
    );
    expect(() => new Sistema({ servicos: [{ servico: { mnemonico: 'ABC' } }] }).codigoServicoAdicional).toThrowError(
      '[SistemaServico].servico.codigo não carregado',
    );
    expect(
      new Sistema({ servicos: [{ servico: { codigo: 92116 } }, { servico: { codigo: 23117 } }] }).codigoServicoAdicional,
    ).toStrictEqual([92116, 23117]);
  });

  it('toJSON', () => {
    expect(new Sistema({ identificador: 'SIGEPE' }).toJSON()).toStrictEqual({ identificador: 'SIGEPE' });
    let example;
    example = { identificador: 'SIGEPE', servicos: [{ servico: { mnemonico: 'SIGEPE' }, principal: true, percentual: 100 }] };
    expect(JSON.stringify(new Sistema(example))).toStrictEqual(JSON.stringify(example));
    example = {
      nome: 'Sistema de Gestão de Pessoal',
      identificador: 'SIGEPE',
      linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
      sigla: 'SIG',
      subdominio: { codigo: '0001-001', dominio: { codigo: '0001' } },
      servicos: [{ servico: { codigo: 92116 }, principal: true }, { servico: { codigo: 23117 } }, { servico: { codigo: 84 } }],
    };
    expect(JSON.stringify(new Sistema(example))).toStrictEqual(
      JSON.stringify({
        ...example,
        codigoServicoPrincipal: 92116,
        codigoServicoAdicional: [23117, 84],
      }),
    );
  });
});
