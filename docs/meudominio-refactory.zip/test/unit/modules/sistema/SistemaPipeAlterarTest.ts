import 'jest';

import { BadRequestException, NotFoundException } from '@nestjs/common';
import { LinhaNegocio } from '../../../../src/modules/sistema/LinhaNegocio';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaPipeAlterar } from '../../../../src/modules/sistema/SistemaPipeAlterar';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { SituacaoSistema } from '../../../../src/modules/sistema/SituacaoSistema';

jest.mock('../../../../src/modules/sistema/SistemaRepository');

describe('unit/modules/sistema/SistemaPipeAlterarTest', () => {
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const pipe = new SistemaPipeAlterar(repositorySistema);
  const uuid = '08925b11-c8fd-441a-a574-fbb8496b2e58';

  beforeEach(() => {
    repositorySistema.findOneById.mockClear();
    repositorySistema.findOneByIdentificador.mockClear();
  });

  it('inexistente', async () => {
    repositorySistema.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ id: uuid })).rejects.toThrow(NotFoundException);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledWith(uuid, 'identificador-situacao-subdominio.id');
  });

  it('id inválido', async () => {
    await expect(pipe.transform({ id: 'abc' }, null)).rejects.toHaveProperty('message.message', 'ID do sistema não informado');
    expect(repositorySistema.findOneById).toBeCalledTimes(0);
  });

  it('atributos obrigatórios ausentes', async () => {
    repositorySistema.findOneById.mockResolvedValue(
      new Sistema({ identificador: 'SIGEPE', situacao: SituacaoSistema.ATIVO, subdominio: { id: 'abc' } }),
    );
    await expect(pipe.transform({ id: uuid, descricao: 'BlaBlaBla' })).rejects.toThrow(BadRequestException);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledWith(uuid, 'identificador-situacao-subdominio.id');
  });

  it('identificador repetido', async () => {
    const antigo = new Sistema({ identificador: 'SIGEPE', situacao: SituacaoSistema.ATIVO, subdominio: { id: 'abc' } });
    repositorySistema.findOneByIdentificador.mockResolvedValue(new Sistema({ id: 'xyz' }));
    repositorySistema.findOneById.mockResolvedValue(antigo);
    const param = {
      id: uuid,
      identificador: 'BLABLABLA',
      sigla: 'SIGEPE',
      nome: 'Sistema de Gestão',
      linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
      subdominio: { id: 'xyz' },
      situacao: SituacaoSistema.INATIVO,
      servicos: [{ servico: { codigo: 92116 }, principal: true }],
    };
    await expect(pipe.transform(param)).rejects.toHaveProperty('message.message', 'Existe outro sistema com o mesmo identificador');
  });

  it('atributos imutáveis', async () => {
    const antigo = new Sistema({ identificador: 'SIGEPE', situacao: SituacaoSistema.ATIVO, subdominio: { id: 'abc' } });
    repositorySistema.findOneByIdentificador.mockResolvedValue(null);
    repositorySistema.findOneById.mockResolvedValue(antigo);
    const param = {
      id: uuid,
      identificador: 'BLABLABLA',
      sigla: 'SIGEPE',
      nome: 'Sistema de Gestão',
      linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
      subdominio: { id: 'xyz' },
      situacao: SituacaoSistema.INATIVO,
      servicos: [{ servico: { codigo: 92116 }, principal: true }],
    };
    const sistema = await pipe.transform(param);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledWith(uuid, 'identificador-situacao-subdominio.id');
    expect(repositorySistema.findOneByIdentificador).toBeCalledTimes(1);
    expect(repositorySistema.findOneByIdentificador).toBeCalledWith('SIGEPE', 'id');
    expect(sistema.identificador).toStrictEqual(antigo.identificador);
    expect(sistema.subdominio.id).toStrictEqual(antigo.subdominio.id);
    expect(sistema.situacao).toStrictEqual(antigo.situacao);
    expect(sistema.nome).toStrictEqual(param.nome);
    expect(sistema.linhaNegocio).toStrictEqual(param.linhaNegocio);
    expect(sistema.sigla).toStrictEqual(param.sigla);
    expect(sistema.servicos.length).toStrictEqual(1);
    expect(sistema.servicos[0].servico.codigo).toStrictEqual(92116);
    expect(sistema.servicos[0].principal).toStrictEqual(true);
  });
});
