import 'jest';

import { GrupoGovi } from '../../../../src/modules/grupogovi/GrupoGoviEntity';
import { GrupoGoviRepository } from '../../../../src/modules/grupogovi/GrupoGoviRepository';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';
import { SistemaServicoRepository } from '../../../../src/modules/sistema/SistemaServicoRepository';
import { SistemaPipeGrupoGovi } from '../../../../src/modules/sistema/SistemaPipeGrupoGovi';

jest.mock('../../../../src/modules/sistema/SistemaServicoRepository');
jest.mock('../../../../src/modules/grupogovi/GrupoGoviRepository');

describe('unit/modules/sistema/SistemaPipeGrupoGoviTest', () => {
  const repositoryGrupoGovi = new GrupoGoviRepository(null) as jest.Mocked<GrupoGoviRepository>;
  const repositorySisServ = new SistemaServicoRepository(null, null) as jest.Mocked<SistemaServicoRepository>;
  const pipe = new SistemaPipeGrupoGovi(repositorySisServ, repositoryGrupoGovi);

  beforeEach(() => {
    repositoryGrupoGovi.findManyBySigla.mockClear();
    repositorySisServ.findManyByGrupoGovi.mockClear();
  });

  it('grupo inexistente', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([]);
    await expect(pipe.transform(new Sistema({ servicos: [{ grupoGovi: ['GSDEAAAA'] }] }))).rejects.toHaveProperty(
      'message.message',
      'Grupo Govi GSDEAAAA não encontrado',
    );
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['GSDEAAAA'], 'sigla-ug-situacao');
  });

  it('grupo não dides', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([new GrupoGovi({ sigla: '123456', ug: null, situacao: 'ATIVO' })]);
    await expect(pipe.transform(new Sistema({ servicos: [{ grupoGovi: ['123456'] }] }))).rejects.toHaveProperty(
      'message.message',
      '123456 não é um grupo DIDES ativo',
    );
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['123456'], 'sigla-ug-situacao');
  });

  it('grupo inativo', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([new GrupoGovi({ sigla: '123456', ug: 'SUPDE', situacao: 'INATIVO' })]);
    await expect(pipe.transform(new Sistema({ servicos: [{ grupoGovi: ['123456'] }] }))).rejects.toHaveProperty(
      'message.message',
      '123456 não é um grupo DIDES ativo',
    );
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['123456'], 'sigla-ug-situacao');
  });

  it('grupo duplicado no mesmo serviço', async () => {
    await expect(
      pipe.transform(new Sistema({ servicos: [{ servico: { codigo: 92116 }, grupoGovi: ['GSDEAAA', 'GSDEBBB', 'GSDEAAA'] }] })),
    ).rejects.toHaveProperty('message.message', 'Grupo Govi GSDEAAA aparece repetido no cód. serv. 92116');
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledTimes(0);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(0);
  });

  it('grupo duplicado em outro serviço', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([new GrupoGovi({ sigla: 'GSDEAAA', ug: null, situacao: null })]);
    repositorySisServ.findManyByGrupoGovi.mockResolvedValue([]);
    await expect(
      pipe.transform(
        new Sistema({
          servicos: [
            { servico: { codigo: 92116 }, grupoGovi: ['GSDEAAA'] },
            { servico: { codigo: 23117 }, grupoGovi: ['GSDEAAA'] },
          ],
        }),
      ),
    ).rejects.toHaveProperty('message.message', 'Grupo Govi GSDEAAA está sendo usado em mais de um cód. serv. (92116, 23117)');
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['GSDEAAA'], 'sigla-ug-situacao');
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledWith(['GSDEAAA'], 'grupogovi-sistema.(id-identificador)-servico.codigo');
  });

  it('grupo duplicado em outro sistema', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([new GrupoGovi({ sigla: 'GSDEAAA', ug: null, situacao: null })]);
    repositorySisServ.findManyByGrupoGovi.mockResolvedValue([
      new SistemaServico({ sistema: { id: 'xyz', identificador: 'OUTRO' }, servico: { codigo: 92116 }, grupoGovi: ['GSDEAAA'] }),
    ]);
    await expect(
      pipe.transform(new Sistema({ servicos: [{ servico: { codigo: 92116 }, grupoGovi: ['GSDEAAA'] }] })),
    ).rejects.toHaveProperty('message.message', 'Grupo Govi GSDEAAA está sendo usado em outro sistema (OUTRO)');
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['GSDEAAA'], 'sigla-ug-situacao');
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledWith(['GSDEAAA'], 'grupogovi-sistema.(id-identificador)-servico.codigo');
  });

  it('sucesso', async () => {
    repositoryGrupoGovi.findManyBySigla.mockResolvedValue([new GrupoGovi({ sigla: 'GSDEAAA', ug: null, situacao: null })]);
    repositorySisServ.findManyByGrupoGovi.mockResolvedValue([
      new SistemaServico({ sistema: { id: 'abc', identificador: 'OUTRO' }, servico: { codigo: 23117 }, grupoGovi: ['GSDEAAA'] }),
    ]);
    await pipe.transform(new Sistema({ id: 'abc', servicos: [{ servico: { codigo: 92116 }, grupoGovi: ['GSDEAAA'] }] }));
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledTimes(1);
    expect(repositoryGrupoGovi.findManyBySigla).toBeCalledWith(['GSDEAAA'], 'sigla-ug-situacao');
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByGrupoGovi).toBeCalledWith(['GSDEAAA'], 'grupogovi-sistema.(id-identificador)-servico.codigo');
  });
});
