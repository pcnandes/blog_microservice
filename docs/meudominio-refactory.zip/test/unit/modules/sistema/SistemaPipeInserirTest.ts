import 'jest';

import { BadRequestException } from '@nestjs/common';
import { LinhaNegocio } from '../../../../src/modules/sistema/LinhaNegocio';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaPipeInserir } from '../../../../src/modules/sistema/SistemaPipeInserir';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { SituacaoSistema } from '../../../../src/modules/sistema/SituacaoSistema';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

jest.mock('../../../../src/modules/sistema/SistemaRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');

describe('unit/modules/sistema/SistemaPipeInserirTest', () => {
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const pipe = new SistemaPipeInserir(repositorySistema, repositorySubDominio);
  const value = {
    identificador: 'ABC',
    sigla: 'ABC',
    nome: 'ABC',
    situacao: SituacaoSistema.INATIVO,
    linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
    servicos: [{ servico: { codigo: 92116 }, principal: true }],
    subdominio: { id: 'xyz' },
  };

  beforeEach(() => {
    repositorySistema.findOneByIdentificador.mockClear();
    repositorySubDominio.findOneById.mockClear();
  });

  it('subdomínio não informado', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ ...value, subdominio: undefined })).rejects.toThrow(BadRequestException);
    expect(repositorySistema.findOneByIdentificador).toBeCalledTimes(0);
    expect(repositorySubDominio.findOneById).toBeCalledTimes(0);
  });

  it('subdomínio não encontrado', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
    expect(repositorySistema.findOneByIdentificador).toBeCalledTimes(1);
    expect(repositorySistema.findOneByIdentificador).toBeCalledWith(value.identificador, 'id');
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith(value.subdominio.id, 'id');
  });

  it('identificador existente', async () => {
    repositorySistema.findOneByIdentificador.mockResolvedValue(new Sistema({ id: 'def' }));
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
    expect(repositorySistema.findOneByIdentificador).toBeCalledTimes(1);
    expect(repositorySistema.findOneByIdentificador).toBeCalledWith(value.identificador, 'id');
    expect(repositorySubDominio.findOneById).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(new SubDominio({ id: 'xyz' }));
    repositorySistema.findOneByIdentificador.mockResolvedValue(null);
    const sistema = await pipe.transform(value);
    expect(repositorySistema.findOneByIdentificador).toBeCalledTimes(1);
    expect(repositorySistema.findOneByIdentificador).toBeCalledWith(value.identificador, 'id');
    expect(sistema.situacao).toStrictEqual(SituacaoSistema.ATIVO);
    expect(sistema.servicos.length).toStrictEqual(1);
    expect(sistema.servicos[0]).toBeInstanceOf(SistemaServico);
    expect(sistema.subdominio).toBeInstanceOf(SubDominio);
  });
});
