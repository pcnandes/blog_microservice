import 'jest';

import { Servico } from '../../../../src/modules/servico/ServicoEntity';
import { ServicoRepository } from '../../../../src/modules/servico/ServicoRepository';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaServicoRepository } from '../../../../src/modules/sistema/SistemaServicoRepository';
import { SistemaPipeServico } from '../../../../src/modules/sistema/SistemaPipeServico';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

jest.mock('../../../../src/modules/sistema/SistemaServicoRepository');
jest.mock('../../../../src/modules/servico/ServicoRepository');

describe('unit/modules/sistema/SistemaPipeServicoTest', () => {
  const repositoryServico = new ServicoRepository(null) as jest.Mocked<ServicoRepository>;
  const repositorySisServ = new SistemaServicoRepository(null, null) as jest.Mocked<SistemaServicoRepository>;
  const pipe = new SistemaPipeServico(repositorySisServ, repositoryServico);

  beforeEach(() => {
    repositoryServico.findManyById.mockClear();
    repositorySisServ.findManyByServico.mockClear();
  });

  it('código de serviço não informado', async () => {
    repositoryServico.findManyById.mockResolvedValue([]);
    repositorySisServ.findManyByServico.mockResolvedValue([]);
    await expect(pipe.transform(new Sistema({ servicos: [{ principal: true }] }), null)).rejects.toHaveProperty(
      'message.message',
      'Cód. Serv. não informado',
    );
    expect(repositoryServico.findManyById).toBeCalledTimes(1);
    expect(repositoryServico.findManyById).toBeCalledWith([], 'codigo-compartilhado-dataDesativacao');
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByServico).toBeCalledWith([], 'sistema.(id-identificador)-servico.codigo-percentual');
  });

  it('código de serviço inexistente', async () => {
    repositorySisServ.findManyByServico.mockResolvedValue([]);
    repositoryServico.findManyById.mockResolvedValue([new Servico({ codigo: 92116, compartilhado: false, dataDesativacao: null })]);
    await expect(
      pipe.transform(
        new Sistema({
          servicos: [{ servico: { codigo: 92116 }, principal: true }, { servico: { codigo: 23117 } }],
        }),
      ),
    ).rejects.toHaveProperty('message.message', 'Cód. Serv. 23117 não encontrado');
    expect(repositoryServico.findManyById).toBeCalledTimes(1);
    expect(repositoryServico.findManyById).toBeCalledWith([92116, 23117], 'codigo-compartilhado-dataDesativacao');
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByServico).toBeCalledWith([92116, 23117], 'sistema.(id-identificador)-servico.codigo-percentual');
  });

  it('código de serviço principal inativo', async () => {
    repositorySisServ.findManyByServico.mockResolvedValue([]);
    repositoryServico.findManyById.mockResolvedValue([new Servico({ codigo: 92116, compartilhado: false, dataDesativacao: new Date() })]);
    await expect(pipe.transform(new Sistema({ servicos: [{ servico: { codigo: 92116 }, principal: true }] }), null)).rejects.toHaveProperty(
      'message.message',
      'Cód. Serv. 92116 está inativo',
    );
    expect(repositoryServico.findManyById).toBeCalledTimes(1);
    expect(repositoryServico.findManyById).toBeCalledWith([92116], 'codigo-compartilhado-dataDesativacao');
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByServico).toBeCalledWith([92116], 'sistema.(id-identificador)-servico.codigo-percentual');
  });

  it('código de serviço duplicado', async () => {
    await expect(
      pipe.transform(
        new Sistema({
          servicos: [{ servico: { codigo: 92116 }, principal: true }, { servico: { codigo: 92116 } }],
        }),
      ),
    ).rejects.toHaveProperty('message.message', 'Cód. Serv. 92116 aparece mais de uma vez');
    expect(repositoryServico.findManyById).toBeCalledTimes(0);
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(0);
  });

  it('código de serviço em outro sistema', async () => {
    repositorySisServ.findManyByServico.mockResolvedValue([
      new SistemaServico({ sistema: { id: 'xyz', identificador: 'ABROBA' }, servico: { codigo: 92116 } }),
    ]);
    repositoryServico.findManyById.mockResolvedValue([new Servico({ codigo: 92116, compartilhado: false, dataDesativacao: new Date() })]);
    await expect(pipe.transform(new Sistema({ servicos: [{ servico: { codigo: 92116 }, principal: true }] }))).rejects.toHaveProperty(
      'message.message',
      'O Cód. Serv. 92116 está vinculado a outro sistema (ABROBA)',
    );
    expect(repositoryServico.findManyById).toBeCalledTimes(1);
    expect(repositoryServico.findManyById).toBeCalledWith([92116], 'codigo-compartilhado-dataDesativacao');
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByServico).toBeCalledWith([92116], 'sistema.(id-identificador)-servico.codigo-percentual');
  });

  it('nenhum código principal', async () => {
    await expect(
      pipe.transform(
        new Sistema({
          servicos: [{ servico: { codigo: 92116 } }, { servico: { codigo: 23117 } }],
        }),
        null,
      ),
    ).rejects.toHaveProperty('message.message', 'Nenhum cód. serv. principal informado');
    expect(repositoryServico.findManyById).toBeCalledTimes(0);
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(0);
  });

  it('multiplos códigos principais', async () => {
    await expect(
      pipe.transform(
        new Sistema({
          servicos: [
            { servico: { codigo: 92116 }, principal: true },
            { servico: { codigo: 23117 }, principal: true },
          ],
        }),
      ),
    ).rejects.toHaveProperty('message.message', 'Mais de um cód. serv. principal informado');
    expect(repositoryServico.findManyById).toBeCalledTimes(0);
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    repositorySisServ.findManyByServico.mockResolvedValue([
      new SistemaServico({
        sistema: { id: 'abc', identificador: 'EUMESMO' },
        servico: { codigo: 92116 },
        percentual: 80,
      }),
      new SistemaServico({
        sistema: { id: 'xyz', identificador: 'ABROBA' },
        servico: { codigo: 92116 },
        percentual: 20,
      }),
      new SistemaServico({
        sistema: { id: 'abc', identificador: 'ABROBA' },
        servico: { codigo: 23117 },
      }),
    ]);
    repositoryServico.findManyById.mockResolvedValue([
      new Servico({ codigo: 92116, compartilhado: true, dataDesativacao: null }),
      new Servico({ codigo: 23117, compartilhado: false, dataDesativacao: null }),
      new Servico({ codigo: 84, compartilhado: true, dataDesativacao: null }),
    ]);
    const sistema = await pipe.transform(
      new Sistema({
        id: 'abc',
        servicos: [
          { servico: { codigo: 92116 }, percentual: 45, principal: true },
          { servico: { codigo: 23117 }, percentual: 10 },
          { servico: { codigo: 84 }, percentual: 10 },
        ],
      }),
    );
    expect(repositoryServico.findManyById).toBeCalledTimes(1);
    expect(repositoryServico.findManyById).toBeCalledWith([92116, 23117, 84], 'codigo-compartilhado-dataDesativacao');
    expect(repositorySisServ.findManyByServico).toBeCalledTimes(1);
    expect(repositorySisServ.findManyByServico).toBeCalledWith([92116, 23117, 84], 'sistema.(id-identificador)-servico.codigo-percentual');
    expect(sistema.servicos[0].percentual).toStrictEqual(80);
    expect(sistema.servicos[1].percentual).toStrictEqual(100);
    expect(sistema.servicos[2].percentual).toStrictEqual(0);
  });
});
