import 'jest';

import { ForbiddenException } from '@nestjs/common';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { AlocacaoRateioService } from '../../../../src/modules/alocacao/AlocacaoRateioService';
import { AlocacaoService } from '../../../../src/modules/alocacao/AlocacaoService';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { SistemaServicoService } from '../../../../src/modules/sistema/SistemaServicoService';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { CategoriaDominio } from '../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from '../../../../src/modules/sistema/LinhaNegocio';
import { SistemaService } from '../../../../src/modules/sistema/SistemaService';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

jest.mock('../../../../src/modules/sistema/SistemaRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioService');
jest.mock('../../../../src/modules/alocacao/AlocacaoService');
jest.mock('../../../../src/modules/sistema/SistemaServicoService');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');

describe('unit/modules/sistema/SistemaServiceAlterarTest', () => {
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const serviceServico = new SistemaServicoService(null, null) as jest.Mocked<SistemaServicoService>;
  const serviceAlocacao = new AlocacaoService(null, null, null) as jest.Mocked<AlocacaoService>;
  const serviceRateio = new AlocacaoRateioService(null, null, null, null, null) as jest.Mocked<AlocacaoRateioService>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const usuario = new Usuario() as jest.Mocked<Usuario>;
  const service = new SistemaService(repositorySistema, repositorySubDominio, serviceServico, security, serviceAlocacao, serviceRateio);

  beforeEach(() => {
    security.getRequestUser.mockReturnValue(usuario);
    repositorySubDominio.findOneById.mockClear();
    repositorySistema.findManyById.mockClear();
    repositorySistema.update.mockClear();
    usuario.podeAlterarDominio.mockClear();
    repositorySistema.findOneById.mockClear();
    serviceAlocacao.atualizarSubProcessos.mockClear();
    serviceServico.atualizarPorSistema.mockClear();
    serviceRateio.atualizarPorEscopo.mockClear();
  });

  it('sem permissão', async () => {
    repositorySistema.findOneById.mockResolvedValue(new Sistema({ subdominio: { dominio: { id: 'abc' } } }));
    usuario.podeAlterarDominio.mockReturnValue(false);
    await expect(service.alterar(new Sistema({ id: 'def', subdominio: { id: 'xyz' } }))).rejects.toThrow(ForbiddenException);
    expect(repositorySistema.findOneById).toBeCalledTimes(1);
    expect(repositorySistema.findOneById).toBeCalledWith('def', 'id-linhaNegocio-subdominio.(id-dominio.(id-categoria))');
    expect(repositorySubDominio.findOneById).toBeCalledTimes(0);
    expect(repositorySistema.update).toBeCalledTimes(0);
    expect(usuario.podeAlterarDominio).toBeCalledTimes(1);
    expect(usuario.podeAlterarDominio).toBeCalledWith('abc');
    expect(serviceServico.atualizarPorSistema).toBeCalledTimes(0);
    expect(serviceAlocacao.atualizarSubProcessos).toBeCalledTimes(0);
    expect(serviceRateio.atualizarPorEscopo).toBeCalledTimes(0);
  });

  it('com alteração da linha de negócio', async () => {
    const antigo = new Sistema({
      linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA,
      subdominio: { dominio: { id: 'abc', categoria: CategoriaDominio.NEGOCIO } },
    });
    repositorySistema.findOneById.mockResolvedValue(antigo);
    usuario.podeAlterarDominio.mockReturnValue(true);
    const servicos = [
      { servico: { codigo: 92116 }, principal: true },
      { servico: { codigo: 23117 }, principal: false },
    ];
    const sistema = new Sistema({
      id: 'def',
      linhaNegocio: LinhaNegocio.SERVICO_NUVEM,
      subdominio: { id: 'xyz' },
      servicos,
    });
    await service.alterar(sistema);
    expect(repositorySistema.update).toBeCalledTimes(1);
    expect(repositorySistema.update).toBeCalledWith(sistema);
    expect(serviceServico.atualizarPorSistema).toBeCalledTimes(1);
    expect(serviceServico.atualizarPorSistema).toBeCalledWith(sistema.id, ...servicos.map(srv => new SistemaServico(srv)));
    expect(serviceAlocacao.atualizarSubProcessos).toBeCalledTimes(1);
    expect(serviceAlocacao.atualizarSubProcessos).toBeCalledWith(new Sistema({ ...sistema, subdominio: antigo.subdominio }));
  });
});
