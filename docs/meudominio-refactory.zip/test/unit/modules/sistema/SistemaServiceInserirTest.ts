import 'jest';

import { ForbiddenException } from '@nestjs/common';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { AlocacaoRateioService } from '../../../../src/modules/alocacao/AlocacaoRateioService';
import { AlocacaoService } from '../../../../src/modules/alocacao/AlocacaoService';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { SistemaServicoService } from '../../../../src/modules/sistema/SistemaServicoService';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { SistemaService } from '../../../../src/modules/sistema/SistemaService';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

jest.mock('../../../../src/modules/sistema/SistemaRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioService');
jest.mock('../../../../src/modules/alocacao/AlocacaoService');
jest.mock('../../../../src/modules/sistema/SistemaServicoService');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');

describe('unit/modules/sistema/SistemaServiceInserirTest', () => {
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const serviceServico = new SistemaServicoService(null, null) as jest.Mocked<SistemaServicoService>;
  const serviceAlocacao = new AlocacaoService(null, null, null) as jest.Mocked<AlocacaoService>;
  const serviceRateio = new AlocacaoRateioService(null, null, null, null, null) as jest.Mocked<AlocacaoRateioService>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const usuario = new Usuario() as jest.Mocked<Usuario>;
  const service = new SistemaService(repositorySistema, repositorySubDominio, serviceServico, security, serviceAlocacao, serviceRateio);

  beforeEach(() => {
    security.getRequestUser.mockReturnValue(usuario);
    repositorySubDominio.findOneById.mockClear();
    repositorySistema.findManyById.mockClear();
    repositorySistema.insert.mockClear();
    serviceServico.atualizarPorSistema.mockClear();
    serviceRateio.atualizarPorEscopo.mockClear();
    usuario.podeAlterarDominio.mockClear();
  });

  it('sem permissão', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(new SubDominio({ dominio: { id: 'abc' } }));
    usuario.podeAlterarDominio.mockReturnValue(false);
    await expect(service.inserir(new Sistema({ subdominio: { id: 'xyz' } }))).rejects.toThrow(ForbiddenException);
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith('xyz', 'codigo-dominio.(id-codigo-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledTimes(1);
    expect(usuario.podeAlterarDominio).toBeCalledWith('abc');
    expect(serviceServico.atualizarPorSistema).toBeCalledTimes(0);
    expect(repositorySistema.insert).toBeCalledTimes(0);
    expect(serviceRateio.atualizarPorEscopo).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    const subdominio = new SubDominio({ codigo: '0001-001', dominio: { id: 'abc', codigo: '0001', ugDominio: 'SUPDG' } });
    repositorySubDominio.findOneById.mockResolvedValue(subdominio);
    usuario.podeAlterarDominio.mockReturnValue(true);
    repositorySistema.insert.mockResolvedValue('123456');
    const servicos = [
      { servico: { codigo: 92116 }, principal: true },
      { servico: { codigo: 23117 }, principal: false },
    ];
    const sistema = new Sistema({ subdominio: { id: 'xyz' }, servicos });
    const id = await service.inserir(sistema);
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith('xyz', 'codigo-dominio.(id-codigo-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledTimes(1);
    expect(usuario.podeAlterarDominio).toBeCalledWith('abc');
    expect(serviceServico.atualizarPorSistema).toBeCalledTimes(1);
    expect(serviceServico.atualizarPorSistema).toBeCalledWith('123456', ...servicos.map(srv => new SistemaServico(srv)));
    expect(serviceRateio.atualizarPorEscopo).toBeCalledTimes(1);
    expect(serviceRateio.atualizarPorEscopo).toBeCalledWith(subdominio.codigo, subdominio.dominioCD, subdominio.dominioUG);
    expect(repositorySistema.insert).toBeCalledTimes(1);
    expect(repositorySistema.insert).toBeCalledWith(sistema);
    expect(id).toStrictEqual('123456');
  });
});
