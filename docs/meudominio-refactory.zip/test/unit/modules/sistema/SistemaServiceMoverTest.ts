import 'jest';

import { ForbiddenException } from '@nestjs/common';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { AlocacaoRateioService } from '../../../../src/modules/alocacao/AlocacaoRateioService';
import { AlocacaoService } from '../../../../src/modules/alocacao/AlocacaoService';
import { Sistema } from '../../../../src/modules/sistema/SistemaEntity';
import { SistemaRepository } from '../../../../src/modules/sistema/SistemaRepository';
import { SistemaServicoService } from '../../../../src/modules/sistema/SistemaServicoService';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { CategoriaDominio } from '../../../../src/modules/dominio/CategoriaDominio';
import { LinhaNegocio } from '../../../../src/modules/sistema/LinhaNegocio';
import { SistemaService } from '../../../../src/modules/sistema/SistemaService';
import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

jest.mock('../../../../src/modules/sistema/SistemaRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioService');
jest.mock('../../../../src/modules/alocacao/AlocacaoService');
jest.mock('../../../../src/modules/sistema/SistemaServicoService');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');

describe('unit/modules/sistema/SistemaServiceTest', () => {
  const repositorySistema = new SistemaRepository(null, null) as jest.Mocked<SistemaRepository>;
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const serviceServico = new SistemaServicoService(null, null) as jest.Mocked<SistemaServicoService>;
  const serviceAlocacao = new AlocacaoService(null, null, null) as jest.Mocked<AlocacaoService>;
  const serviceRateio = new AlocacaoRateioService(null, null, null, null, null) as jest.Mocked<AlocacaoRateioService>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const usuario = new Usuario() as jest.Mocked<Usuario>;
  const service = new SistemaService(repositorySistema, repositorySubDominio, serviceServico, security, serviceAlocacao, serviceRateio);
  const sistemas = [
    new Sistema({
      id: 'abc',
      linhaNegocio: LinhaNegocio.SERVICO_INFORMACAO,
      subdominio: {
        codigo: '0023-005',
        dominio: { id: 'xyz', codigo: '0023', ugDominio: 'SUPDR', categoria: CategoriaDominio.NEGOCIO },
      },
    }),
    new Sistema({
      id: 'def',
      linhaNegocio: LinhaNegocio.SERVICO_NUVEM,
      subdominio: {
        codigo: '0023-006',
        dominio: { id: 'xyz', codigo: '0023', ugDominio: 'SUPDR', categoria: CategoriaDominio.NEGOCIO },
      },
    }),
  ];
  const subdominio = new SubDominio({
    id: 'xxx',
    codigo: '0005-001',
    dominio: { id: 'yyy', codigo: '0005', ugDominio: 'SUPDR', categoria: CategoriaDominio.PRODUTO },
  });

  beforeEach(() => {
    security.getRequestUser.mockReturnValue(usuario);
    repositorySubDominio.findOneById.mockClear();
    serviceServico.atualizarPorSistema.mockClear();
    serviceRateio.atualizarPorEscopo.mockClear();
    repositorySistema.findManyById.mockClear();
    repositorySistema.updateAll.mockClear();
    usuario.podeAlterarDominio.mockClear();
    repositorySistema.findOneById.mockClear();
    serviceServico.deleteAll.mockClear();
    serviceAlocacao.excluirPorSistema.mockClear();
    serviceAlocacao.atualizarSubProcessos.mockClear();
  });

  it('sem permissão', async () => {
    repositorySistema.findManyById.mockResolvedValue(sistemas);
    repositorySubDominio.findOneById.mockResolvedValue(subdominio);
    usuario.podeAlterarDominio.mockReturnValue(false);
    await expect(
      service.mover(
        sistemas.map(s => s.id),
        subdominio.id,
      ),
    ).rejects.toThrow(ForbiddenException);
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith(subdominio.id, 'id-codigo-dominio.(codigo-categoria-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledWith(sistemas[0].dominioID);
    expect(repositorySistema.findManyById).toBeCalledTimes(1);
    expect(repositorySistema.findManyById).toBeCalledWith(
      sistemas.map(s => s.id),
      '*-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))',
    );
  });

  it('subdomínio diferentes', async () => {
    repositorySistema.findManyById.mockResolvedValue([sistemas[0], new Sistema({ ...sistemas[1], subdominio: { id: 'blablabla' } })]);
    repositorySubDominio.findOneById.mockResolvedValue(subdominio);
    await expect(
      service.mover(
        sistemas.map(s => s.id),
        subdominio.id,
      ),
    ).rejects.toHaveProperty('message.message', 'Há sistemas de subdomínios diferentes');
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith(subdominio.id, 'id-codigo-dominio.(codigo-categoria-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledTimes(0);
    expect(repositorySistema.findManyById).toBeCalledTimes(1);
    expect(repositorySistema.findManyById).toBeCalledWith(
      sistemas.map(s => s.id),
      '*-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))',
    );
  });

  it('sob medida em domínio do tipo produto', async () => {
    repositorySistema.findManyById.mockResolvedValue([
      sistemas[0],
      new Sistema({ ...sistemas[1], linhaNegocio: LinhaNegocio.SERVICO_SOB_MEDIDA }),
    ]);
    repositorySubDominio.findOneById.mockResolvedValue(subdominio);
    await expect(
      service.mover(
        sistemas.map(s => s.id),
        subdominio.id,
      ),
    ).rejects.toHaveProperty('message.message', 'Não é permitido mover sistema sob medida para domínio do tipo produto');
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith(subdominio.id, 'id-codigo-dominio.(codigo-categoria-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledTimes(0);
    expect(repositorySistema.findManyById).toBeCalledWith(
      sistemas.map(s => s.id),
      '*-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))',
    );
  });

  it('sucesso', async () => {
    repositorySistema.findManyById.mockResolvedValue(sistemas);
    repositorySubDominio.findOneById.mockResolvedValue(subdominio);
    usuario.podeAlterarDominio.mockReturnValue(true);
    await service.mover(
      sistemas.map(s => s.id),
      subdominio.id,
    );
    const updates = sistemas.map(sis => new Sistema({ ...sis, subdominio }));
    expect(repositorySubDominio.findOneById).toBeCalledTimes(1);
    expect(repositorySubDominio.findOneById).toBeCalledWith(subdominio.id, 'id-codigo-dominio.(codigo-categoria-ugDominio)');
    expect(usuario.podeAlterarDominio).toBeCalledTimes(2);
    expect(repositorySistema.findManyById).toBeCalledTimes(1);
    expect(repositorySistema.findManyById).toBeCalledWith(
      sistemas.map(s => s.id),
      '*-subdominio.(codigo-dominio.(codigo-categoria-ugDominio))',
    );
    expect(repositorySistema.updateAll).toBeCalledTimes(1);
    expect(repositorySistema.updateAll).toBeCalledWith(...updates);
    expect(serviceRateio.atualizarPorEscopo).toBeCalledTimes(1);
    expect(serviceRateio.atualizarPorEscopo).toBeCalledWith(
      subdominio.codigo,
      subdominio.dominioCD,
      subdominio.dominioUG,
      sistemas[0].subdominio.codigo,
      sistemas[0].subdominio.dominioCD,
    );
    expect(serviceAlocacao.atualizarSubProcessos).toBeCalledTimes(1);
    expect(serviceAlocacao.atualizarSubProcessos).toBeCalledWith(...updates);
  });
});
