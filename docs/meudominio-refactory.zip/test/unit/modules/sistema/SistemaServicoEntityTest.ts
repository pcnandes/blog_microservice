import 'jest';

import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';

describe('unit/modules/sistema/SistemaServicoEntityTest', () => {
  it('ativo', () => {
    expect(() => new SistemaServico().ativo).toThrowError('[SistemaServico].servico.dataDesativacao não carregado');
    expect(new SistemaServico({ servico: { dataDesativacao: null } }).ativo).toStrictEqual(true);
    expect(new SistemaServico({ servico: { dataDesativacao: new Date() } }).ativo).toStrictEqual(false);
  });

  it('codigo', () => {
    expect(() => new SistemaServico().codigo).toThrowError('[SistemaServico].servico.codigo não carregado');
    expect(() => new SistemaServico({ servico: { ug: 'SUNEF' } }).codigo).toThrowError('[SistemaServico].servico.codigo não carregado');
    expect(new SistemaServico({ servico: { codigo: 92116 } }).codigo).toStrictEqual(92116);
  });
});
