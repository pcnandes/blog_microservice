import 'jest';

import { SistemaServico } from '../../../../src/modules/sistema/SistemaServicoEntity';
import { SistemaServicoService } from '../../../../src/modules/sistema/SistemaServicoService';
import { ServicoRepository } from '../../../../src/modules/servico/ServicoRepository';
import { SistemaServicoRepository } from '../../../../src/modules/sistema/SistemaServicoRepository';

jest.mock('../../../../src/modules/sistema/SistemaRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/alocacao/AlocacaoRateioService');
jest.mock('../../../../src/modules/alocacao/AlocacaoService');
jest.mock('../../../../src/modules/sistema/SistemaServicoRepository');
jest.mock('../../../../src/modules/servico/ServicoRepository');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');

describe('unit/modules/sistema/SistemaServiceTest', () => {
  const repositorySisServ = new SistemaServicoRepository(null, null) as jest.Mocked<SistemaServicoRepository>;
  const repositoryServico = new ServicoRepository(null) as jest.Mocked<ServicoRepository>;
  const service = new SistemaServicoService(repositorySisServ, repositoryServico);

  beforeEach(() => {
    repositorySisServ.insertAll.mockClear();
    repositorySisServ.updateAll.mockClear();
    repositorySisServ.deleteAll.mockClear();
    repositorySisServ.findManyBySistema.mockClear();
  });

  it('atualizarPorSistema', async () => {
    const sistemaID = 'abc';
    const existentes = [
      new SistemaServico({ id: '111', servico: { codigo: 92116 }, sistema: { id: sistemaID } }),
      new SistemaServico({ id: '222', servico: { codigo: 23117 }, sistema: { id: sistemaID } }),
      new SistemaServico({ id: '333', servico: { codigo: 12345 }, sistema: { id: sistemaID } }),
    ];
    const incluidos = [new SistemaServico({ servico: { codigo: 54321 } })];
    const alterados = [new SistemaServico({ servico: { codigo: 92116 }, principal: true })];
    const excluidos = ['222', '333'];
    repositorySisServ.findManyBySistema.mockResolvedValue(existentes);
    await service.atualizarPorSistema(sistemaID, ...incluidos.concat(alterados));
    expect(repositorySisServ.findManyBySistema).toBeCalledTimes(1);
    expect(repositorySisServ.findManyBySistema).toBeCalledWith(sistemaID, '*-sistema.id-servico.codigo');
    expect(repositorySisServ.insertAll).toBeCalledTimes(1);
    expect(repositorySisServ.insertAll).toBeCalledWith(...incluidos.map(srv => new SistemaServico({ ...srv, sistema: { id: sistemaID } })));
    expect(repositorySisServ.updateAll).toBeCalledTimes(1);
    expect(repositorySisServ.updateAll).toBeCalledWith(
      new SistemaServico({ ...alterados[0], sistema: { id: sistemaID }, id: existentes[0].id }),
    );
    expect(repositorySisServ.deleteAll).toBeCalledTimes(1);
    expect(repositorySisServ.deleteAll).toBeCalledWith(...excluidos);
  });
});
