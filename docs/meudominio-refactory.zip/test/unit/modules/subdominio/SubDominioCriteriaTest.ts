import 'jest';

import { SubDominioCriteria } from '../../../../src/modules/subdominio/SubDominioCriteria';

describe('unit/modules/subdominio/SubDominioCriteriaTest', () => {
  it('sistema', async () => {
    const criteria = new SubDominioCriteria({ sistema: 'SIGEPE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['sistemas']);
    expect(where.toString()).toStrictEqual(
      '((subdominio_sistemas.identificador ILIKE :sistema' +
        ' OR subdominio_sistemas.sigla ILIKE :sistema' +
        ' OR subdominio_sistemas.nome ILIKE :sistema))',
    );
    expect(where.getParameters()).toStrictEqual({ sistema: '%SIGEPE%' });
  });

  it('servico texto', async () => {
    const criteria = new SubDominioCriteria({ servico: 'SIGEPE' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['sistemas.servicos.servico']);
    expect(where.toString()).toStrictEqual(
      '((subdominio_sistemas_servicos_servico.mnemonico ILIKE :servico' +
        ' OR subdominio_sistemas_servicos_servico.titulo ILIKE :servico))',
    );
    expect(where.getParameters()).toStrictEqual({ servico: '%SIGEPE%' });
  });

  it('servico numero', async () => {
    const criteria = new SubDominioCriteria({ servico: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['sistemas.servicos.servico']);
    expect(where.toString()).toStrictEqual('(subdominio_sistemas_servicos_servico.codigo = :servico)');
    expect(where.getParameters()).toStrictEqual({ servico: 92116 });
  });

  it('dominio uuid', async () => {
    const param = 'fbe87f06-c436-4c71-95f3-30a242f23e8b';
    const criteria = new SubDominioCriteria({ dominio: param });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['dominio']);
    expect(where.toString()).toStrictEqual('(subdominio_dominio.id = :dominio)');
    expect(where.getParameters()).toStrictEqual({ dominio: param });
  });

  it('dominio codigo', async () => {
    const param = '0030';
    const criteria = new SubDominioCriteria({ dominio: param });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['dominio']);
    expect(where.toString()).toStrictEqual('(subdominio_dominio.codigo = :dominio)');
    expect(where.getParameters()).toStrictEqual({ dominio: param });
  });

  it('search texto', async () => {
    const criteria = new SubDominioCriteria({ search: 'teste' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['sistemas', 'sistemas.servicos.servico', 'sistemas.servicos']);
  });

  it('search numero', async () => {
    const criteria = new SubDominioCriteria({ search: '92116' });
    const where = criteria.toWhere();
    expect(where.getJoins()).toStrictEqual(['sistemas', 'sistemas.servicos.servico', 'sistemas.servicos']);
  });
});
