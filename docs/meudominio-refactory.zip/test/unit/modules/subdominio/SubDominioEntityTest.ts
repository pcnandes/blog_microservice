import 'jest';

import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SituacaoDominio } from '../../../../src/modules/dominio/SituacaoDominio';

describe('unit/modules/subdominio/SubDominioEntityTest', () => {
  it('isAtivo', () => {
    expect(() => new SubDominio().isAtivo).toThrowError('[SubDominio].situacao não carregado');
    expect(() => new SubDominio({ situacao: SituacaoDominio.ATIVO }).isAtivo).toThrowError('[SubDominio].dominio não carregado');
    expect(() => new SubDominio({ situacao: SituacaoDominio.ATIVO, dominio: { id: 'abc' } }).isAtivo).toThrowError(
      '[Dominio].situacao não carregado',
    );
    expect(
      new SubDominio({ situacao: SituacaoDominio.ATIVO, dominio: { id: 'abc', situacao: SituacaoDominio.ATIVO } }).isAtivo,
    ).toStrictEqual(true);
    expect(
      new SubDominio({ situacao: SituacaoDominio.ATIVO, dominio: { id: 'abc', situacao: SituacaoDominio.INATIVO } }).isAtivo,
    ).toStrictEqual(false);
    expect(new SubDominio({ situacao: SituacaoDominio.INATIVO }).isAtivo).toStrictEqual(false);
  });

  it('dominioID', () => {
    expect(() => new SubDominio().dominioID).toThrowError('[SubDominio].dominio.id não carregado');
    expect(() => new SubDominio({ dominio: { nome: 'BlaBlaBla' } }).dominioID).toThrowError('[SubDominio].dominio.id não carregado');
    expect(new SubDominio({ dominio: { id: 'xyz' } }).dominioID).toStrictEqual('xyz');
  });

  it('dominioCD', () => {
    expect(() => new SubDominio().dominioCD).toThrowError('[SubDominio].dominio.codigo não carregado');
    expect(() => new SubDominio({ dominio: { nome: 'BlaBlaBla' } }).dominioCD).toThrowError('[SubDominio].dominio.codigo não carregado');
    expect(new SubDominio({ dominio: { codigo: '0002' } }).dominioCD).toStrictEqual('0002');
  });

  it('dominioUG', () => {
    expect(() => new SubDominio().dominioUG).toThrowError('[SubDominio].dominio.ugDominio não carregado');
    expect(() => new SubDominio({ dominio: { nome: 'BlaBlaBla' } }).dominioUG).toThrowError('[SubDominio].dominio.ugDominio não carregado');
    expect(new SubDominio({ dominio: { ugDominio: 'SUPDR' } }).dominioUG).toStrictEqual('SUPDR');
  });
});
