import 'jest';

import { BadRequestException, NotFoundException } from '@nestjs/common';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SubDominioPipeAlterar } from '../../../../src/modules/subdominio/SubDominioPipeAlterar';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { SituacaoDominio } from '../../../../src/modules/dominio/SituacaoDominio';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';

jest.mock('../../../../src/modules/dominio/DominioRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');

describe('unit/modules/subdominio/SubDominioPipeAlterarTest', () => {
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const pipe = new SubDominioPipeAlterar(repositorySubDominio, repositoryDominio);
  const antigo = new SubDominio({
    id: 'abc',
    codigo: '0020-004',
    nome: 'Velho',
    situacao: SituacaoDominio.ATIVO,
    dominio: { id: 'xyz' },
  });

  beforeEach(() => {
    repositorySubDominio.findOneById.mockClear();
    repositoryDominio.findOneById.mockClear();
  });

  it('subdomínio inexistente', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(NotFoundException);
  });

  it('domínio inexistente', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(antigo);
    repositoryDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(BadRequestException);
  });

  it('domínio inativo', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(antigo);
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ ...antigo.dominio, codigo: '0020', situacao: SituacaoDominio.INATIVO }));
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(BadRequestException);
  });

  it('substitui os atributos imutáveis', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(antigo);
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ ...antigo.dominio, codigo: '0020', situacao: SituacaoDominio.ATIVO }));
    const value = {
      id: 'abc',
      nome: 'Teste',
      codigo: '9999-999',
      situacao: SituacaoDominio.INATIVO,
      dominio: { id: 'zyx' },
    };
    const subdominio = await pipe.transform(value);
    expect(subdominio.codigo).toStrictEqual(antigo.codigo);
    expect(subdominio.situacao).toStrictEqual(antigo.situacao);
    expect(subdominio.nome).toStrictEqual(value.nome);
    expect(subdominio.dominio).toStrictEqual(antigo.dominio);
  });

  it('sem nome', async () => {
    repositorySubDominio.findOneById.mockResolvedValue(antigo);
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ ...antigo.dominio, codigo: '0020', situacao: SituacaoDominio.ATIVO }));
    const value = {
      id: 'abc',
      codigo: '9999-999',
      situacao: SituacaoDominio.INATIVO,
      dominio: { id: 'zyx' },
    };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });
});
