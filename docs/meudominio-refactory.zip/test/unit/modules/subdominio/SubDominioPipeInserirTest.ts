import 'jest';

import { BadRequestException } from '@nestjs/common';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { SituacaoDominio } from '../../../../src/modules/dominio/SituacaoDominio';
import { SubDominioPipeInserir } from '../../../../src/modules/subdominio/SubDominioPipeInserir';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';

jest.mock('../../../../src/modules/dominio/DominioRepository');
jest.mock('../../../../src/modules/subdominio/SubDominioRepository');

describe('unit/modules/subdominio/SubDominioPipeInserirTest', () => {
  const repositorySubDominio = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const pipe = new SubDominioPipeInserir(repositorySubDominio, repositoryDominio);
  const dominioID = 'fbe87f06-c436-4c71-95f3-30a242f23e8b';

  beforeEach(() => {
    repositorySubDominio.findNextCodigo.mockClear();
    repositoryDominio.findOneById.mockClear();
    repositorySubDominio.findNextCodigo.mockResolvedValue('0020-004');
  });

  it('domínio inexistente', async () => {
    repositoryDominio.findOneById.mockResolvedValue(null);
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(BadRequestException);
  });

  it('domínio inativo', async () => {
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ id: dominioID, codigo: '0020', situacao: SituacaoDominio.INATIVO }));
    await expect(pipe.transform({ id: 'abc' })).rejects.toThrow(BadRequestException);
  });

  it('preenche atributos', async () => {
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ id: dominioID, codigo: '0020', situacao: SituacaoDominio.ATIVO }));
    const value = {
      id: 'abc',
      nome: 'Teste',
      codigo: '9999-999',
      situacao: SituacaoDominio.INATIVO,
      dominio: { id: dominioID },
    };
    const subdominio = await pipe.transform(value);
    expect(subdominio.codigo).toStrictEqual('0020-004');
    expect(subdominio.situacao).toStrictEqual(SituacaoDominio.ATIVO);
    expect(subdominio.nome).toStrictEqual(value.nome);
    expect(subdominio.dominio).toStrictEqual(new Dominio({ id: dominioID }));
    expect(repositorySubDominio.findNextCodigo).toBeCalledTimes(1);
    expect(repositorySubDominio.findNextCodigo).toBeCalledWith(dominioID);
  });

  it('sem nome', async () => {
    repositoryDominio.findOneById.mockResolvedValue(new Dominio({ id: dominioID, codigo: '0020', situacao: SituacaoDominio.ATIVO }));
    const value = {
      id: 'abc',
      codigo: '9999-999',
      situacao: SituacaoDominio.INATIVO,
      dominio: { id: 'zyx' },
    };
    await expect(pipe.transform(value)).rejects.toThrow(BadRequestException);
  });
});
