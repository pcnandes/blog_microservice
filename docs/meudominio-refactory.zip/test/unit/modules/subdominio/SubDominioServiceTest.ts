import 'jest';

import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { SubDominio } from '../../../../src/modules/subdominio/SubDominioEntity';
import { SubDominioRepository } from '../../../../src/modules/subdominio/SubDominioRepository';
import { Sort } from '../../../../src/common/query/Sort';
import { SubDominioCriteria } from '../../../../src/modules/subdominio/SubDominioCriteria';
import { SubDominioService } from '../../../../src/modules/subdominio/SubDominioService';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';

jest.mock('../../../../src/modules/subdominio/SubDominioRepository');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/modules/usuario/UsuarioEntity');

describe('unit/modules/subdominio/SubDominioServiceTest', () => {
  const repository = new SubDominioRepository(null, null) as jest.Mocked<SubDominioRepository>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const service = new SubDominioService(repository, security);
  const subdominio = new SubDominio({ nome: 'Teste', dominio: { id: 'xyz' } });
  const usuario = new Usuario() as jest.Mocked<Usuario>;

  beforeEach(() => {
    repository.insert.mockClear();
    repository.update.mockClear();
    repository.findOneById.mockClear();
    repository.findOneByCodigo.mockClear();
    repository.findAll.mockClear();
    security.getRequestUser.mockReturnValue(usuario);
    usuario.podeAlterarDominio.mockClear();
  });

  describe('inserir', () => {
    it('usuário sem permissão', async () => {
      usuario.podeAlterarDominio.mockReturnValue(false);
      await expect(service.inserir(subdominio)).rejects.toThrow(ForbiddenException);
      expect(usuario.podeAlterarDominio).toBeCalledWith(subdominio.dominio.id);
    });

    it('com sucesso', async () => {
      usuario.podeAlterarDominio.mockReturnValue(true);
      repository.insert.mockResolvedValue('abc');
      const id = await service.inserir(subdominio);
      expect(usuario.podeAlterarDominio).toBeCalledWith(subdominio.dominio.id);
      expect(id).toStrictEqual('abc');
    });
  });

  describe('alterar', () => {
    it('usuário sem permissão', async () => {
      usuario.podeAlterarDominio.mockReturnValue(false);
      await expect(service.alterar(subdominio)).rejects.toThrow(ForbiddenException);
      expect(usuario.podeAlterarDominio).toBeCalledWith(subdominio.dominio.id);
    });

    it('com sucesso', async () => {
      usuario.podeAlterarDominio.mockReturnValue(true);
      await service.alterar(subdominio);
      expect(repository.update).toBeCalledWith(subdominio);
    });
  });

  describe('findOneByCodigo', () => {
    it('inexistente', async () => {
      repository.findOneByCodigo.mockResolvedValue(null);
      await expect(service.findOneByCodigo('0001-001')).rejects.toThrow(NotFoundException);
    });

    it('sucesso', async () => {
      repository.findOneByCodigo.mockResolvedValue(subdominio);
      const result = await service.findOneByCodigo('0001-001', 'id-codigo-nome');
      expect(result).toStrictEqual(subdominio);
      expect(repository.findOneByCodigo).toBeCalledTimes(1);
      expect(repository.findOneByCodigo).toBeCalledWith('0001-001', 'id-codigo-nome');
    });
  });

  describe('findOneByID', () => {
    it('inexistente', async () => {
      repository.findOneById.mockResolvedValue(null);
      await expect(service.findOneByID('xxx')).rejects.toThrow(NotFoundException);
    });

    it('sucesso', async () => {
      repository.findOneById.mockResolvedValue(subdominio);
      const result = await service.findOneByID('xxx', 'id-codigo-nome');
      expect(result).toStrictEqual(subdominio);
      expect(repository.findOneById).toBeCalledTimes(1);
      expect(repository.findOneById).toBeCalledWith('xxx', 'id-codigo-nome');
    });
  });

  it('findMany', async () => {
    const subdominios = [subdominio];
    const criteria = new SubDominioCriteria({ servico: '23117' });
    const sort = Sort.by('subdominio.nome');
    repository.findAll.mockResolvedValue(subdominios);
    const result = await service.findMany('*-sistemas.*', criteria, sort);
    expect(repository.findAll).toBeCalledTimes(1);
    expect(repository.findAll).toBeCalledWith('*-sistemas.*', criteria, sort);
    expect(result).toStrictEqual(subdominios);
  });
});
