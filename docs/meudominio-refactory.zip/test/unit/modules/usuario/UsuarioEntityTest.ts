import 'jest';

import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Permissao } from '../../../../src/modules/permissao/PermissaoEntity';
import { Perfil } from '../../../../src/modules/usuario/Perfil';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';

describe('unit/modules/usuario/UsuarioEntityTest', () => {
  it('possuiPerfil', () => {
    const usuario = new Usuario({
      perfis: [Perfil.ADMINISTRADOR, Perfil.GESTOR_EXECUTIVO],
    });
    expect(usuario.possuiPerfil(Perfil.ADMINISTRADOR)).toStrictEqual(true);
    expect(usuario.possuiPerfil(Perfil.CADASTRADOR_DOMINIO)).toStrictEqual(false);
    expect(usuario.possuiPerfil(Perfil.CADASTRADOR_DOMINIO, Perfil.GESTOR_EXECUTIVO)).toStrictEqual(true);
  });

  it('possuiPermissao', () => {
    const usuario = new Usuario({
      permissoes: [
        new Permissao({ dominioID: 'abc', operacoes: [Operacao.EDITAR, Operacao.CUSTOS] }),
        new Permissao({ dominioID: 'def', operacoes: [Operacao.ALOCAR] }),
      ],
    });
    expect(usuario.possuiPermissao(null, Operacao.EDITAR)).toStrictEqual(true);
    expect(usuario.possuiPermissao(null, Operacao.CUSTOS)).toStrictEqual(true);
    expect(usuario.possuiPermissao('abc', Operacao.EDITAR)).toStrictEqual(true);
    expect(usuario.possuiPermissao('abc', Operacao.ALOCAR)).toStrictEqual(false);
    expect(usuario.possuiPermissao('abc', Operacao.CUSTOS, Operacao.ALOCAR)).toStrictEqual(true);
    expect(usuario.possuiPermissao('def', Operacao.EDITAR, Operacao.CUSTOS)).toStrictEqual(false);
  });

  it('podeAlterarDominio', () => {
    expect(new Usuario({ perfis: [Perfil.ADMINISTRADOR] }).podeAlterarDominio('abc')).toStrictEqual(true);
    expect(new Usuario({ perfis: [Perfil.CADASTRADOR_DOMINIO] }).podeAlterarDominio('abc')).toStrictEqual(true);
    expect(new Usuario({ perfis: [Perfil.GESTOR_EXECUTIVO] }).podeAlterarDominio('abc')).toStrictEqual(false);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'abc', operacoes: [Operacao.ALOCAR] })],
      }).podeAlterarDominio('abc'),
    ).toStrictEqual(false);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'abc', operacoes: [Operacao.CUSTOS, Operacao.EDITAR] })],
      }).podeAlterarDominio('abc'),
    ).toStrictEqual(true);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'def', operacoes: [Operacao.ALOCAR] })],
      }).podeAlterarDominio('abc'),
    ).toStrictEqual(false);
    expect(new Usuario({ gestorDominio: ['abc'] }).podeAlterarDominio('abc')).toStrictEqual(true);
    expect(new Usuario({ gestorDominio: ['def', 'ghi'] }).podeAlterarDominio('abc')).toStrictEqual(false);
  });

  it('podeAlocarDominio', () => {
    expect(new Usuario({ perfis: [Perfil.ADMINISTRADOR] }).podeAlocarDominio('abc')).toStrictEqual(true);
    expect(new Usuario({ perfis: [Perfil.CADASTRADOR_DOMINIO] }).podeAlocarDominio('abc')).toStrictEqual(false);
    expect(new Usuario({ perfis: [Perfil.GESTOR_ALOCACAO] }).podeAlocarDominio('abc')).toStrictEqual(true);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'abc', operacoes: [Operacao.ALOCAR] })],
      }).podeAlocarDominio('abc'),
    ).toStrictEqual(true);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'abc', operacoes: [Operacao.CUSTOS, Operacao.EDITAR] })],
      }).podeAlocarDominio('abc'),
    ).toStrictEqual(false);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'def', operacoes: [Operacao.ALOCAR] })],
      }).podeAlocarDominio('abc'),
    ).toStrictEqual(false);
    expect(new Usuario({ gestorDominio: ['abc'] }).podeAlocarDominio('abc')).toStrictEqual(true);
    expect(new Usuario({ gestorDominio: ['def', 'ghi'] }).podeAlocarDominio('abc')).toStrictEqual(false);
  });

  it('podeAlocarSuporte', () => {
    expect(new Usuario({ perfis: [Perfil.ADMINISTRADOR] }).podeAlocarSuporte()).toStrictEqual(true);
    expect(new Usuario({ perfis: [Perfil.CADASTRADOR_DOMINIO] }).podeAlocarSuporte()).toStrictEqual(false);
    expect(new Usuario({ perfis: [Perfil.GESTOR_ALOCACAO] }).podeAlocarSuporte()).toStrictEqual(true);
    expect(
      new Usuario({
        permissoes: [new Permissao({ dominioID: 'abc', operacoes: [Operacao.ALOCAR] })],
      }).podeAlocarSuporte(),
    ).toStrictEqual(false);
    expect(new Usuario({ gestorDominio: ['abc'] }).podeAlocarSuporte()).toStrictEqual(true);
    expect(
      new Usuario({
        empregado: new Empregado({
          funcaoConfianca: 'GERENTE',
          lotacao: 'DIDES/SUPDG/DGFAN',
        }),
      }).podeAlocarSuporte(),
    ).toStrictEqual(true);
    expect(
      new Usuario({
        empregado: new Empregado({
          funcaoConfianca: 'GERENTE',
          lotacao: 'DIRCL/SUNEF',
        }),
      }).podeAlocarSuporte(),
    ).toStrictEqual(false);
  });
});
