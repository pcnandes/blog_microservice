import 'jest';

import { BadRequestException, NotFoundException } from '@nestjs/common';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Permissao } from '../../../../src/modules/permissao/PermissaoEntity';
import { Perfil } from '../../../../src/modules/usuario/Perfil';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { UsuarioPipe } from '../../../../src/modules/usuario/UsuarioPipe';

jest.mock('../../../../src/modules/empregado/EmpregadoRepository');

describe('unit/modules/usuario/UsuarioPipeTest', () => {
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const pipe = new UsuarioPipe(repositoryEmpregado);

  beforeEach(() => {
    repositoryEmpregado.findOneByCPF.mockClear();
  });

  it('empregado inexistente', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(null);
    await expect(pipe.transform({ username: '12345678900' })).rejects.toThrow(NotFoundException);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledWith('12345678900', 'cpf-dataDesligamento');
  });

  it('empregado desligado', async () => {
    repositoryEmpregado.findOneByCPF.mockResolvedValue(new Empregado({ dataDesligamento: new Date() }));
    await expect(pipe.transform({ username: '12345678900' })).rejects.toThrow(NotFoundException);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledWith('12345678900', 'cpf-dataDesligamento');
  });

  it('usuário de serviço', async () => {
    await expect(pipe.transform({ username: 'AESP' })).rejects.toThrow(BadRequestException);
    expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(0);
  });

  it('sucesso', async () => {
    const empregado = new Empregado({ cpf: '12345678900', dataDesligamento: null });
    repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
    await expect(
      pipe.transform({
        username: '12345678900',
        perfis: [Perfil.GESTOR_ALOCACAO, Perfil.GESTOR_EXECUTIVO],
        versao: 2,
        id: 'abc',
        gestorDominio: ['def', 'ghi'],
        permissoes: [{ dominioID: 'jkl', operacoes: [Operacao.EDITAR, Operacao.ALOCAR] }],
      }),
    ).resolves.toStrictEqual(
      new Usuario({
        id: 'abc',
        username: '12345678900',
        empregado,
        perfis: [Perfil.GESTOR_ALOCACAO, Perfil.GESTOR_EXECUTIVO],
        versao: 2,
        permissoes: [new Permissao({ dominioID: 'jkl', operacoes: [Operacao.EDITAR, Operacao.ALOCAR], empregado })],
      }),
    );
  });
});
