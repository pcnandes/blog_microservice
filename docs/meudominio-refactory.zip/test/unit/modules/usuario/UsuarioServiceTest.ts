import 'jest';

import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { CacheAdapterFactory } from '../../../../src/common/cache/CacheAdapterFactory';
import { CacheAdapter } from '../../../../src/common/cache/CacheAdapterRedis';
import { SecurityContext } from '../../../../src/common/security/SecurityContext';
import { Dominio } from '../../../../src/modules/dominio/DominioEntity';
import { DominioRepository } from '../../../../src/modules/dominio/DominioRepository';
import { Empregado } from '../../../../src/modules/empregado/EmpregadoEntity';
import { EmpregadoRepository } from '../../../../src/modules/empregado/EmpregadoRepository';
import { Operacao } from '../../../../src/modules/permissao/Operacao';
import { Permissao } from '../../../../src/modules/permissao/PermissaoEntity';
import { Perfil } from '../../../../src/modules/usuario/Perfil';
import { PermissaoService } from '../../../../src/modules/permissao/PermissaoService';
import { UsuarioDTO } from '../../../../src/modules/usuario/UsuarioDTO';
import { Usuario } from '../../../../src/modules/usuario/UsuarioEntity';
import { UsuarioRepository } from '../../../../src/modules/usuario/UsuarioRepository';
import { UsuarioService } from '../../../../src/modules/usuario/UsuarioService';

jest.mock('../../../../src/modules/empregado/EmpregadoRepository');
jest.mock('../../../../src/modules/dominio/DominioRepository');
jest.mock('../../../../src/modules/usuario/UsuarioRepository');
jest.mock('../../../../src/modules/permissao/PermissaoService');
jest.mock('../../../../src/common/security/SecurityContext');
jest.mock('../../../../src/common/cache/CacheAdapterRedis');

const cache = new CacheAdapter(null) as jest.Mocked<CacheAdapter>;

CacheAdapterFactory.prototype.getInstance = () => {
  return cache;
};

describe('unit/modules/usuario/UsuarioServiceTest', () => {
  const repositoryEmpregado = new EmpregadoRepository(null) as jest.Mocked<EmpregadoRepository>;
  const repositoryUsuario = new UsuarioRepository(null, null) as jest.Mocked<UsuarioRepository>;
  const repositoryDominio = new DominioRepository(null, null) as jest.Mocked<DominioRepository>;
  const servicePermissao = new PermissaoService(null, null, null) as jest.Mocked<PermissaoService>;
  const security = new SecurityContext() as jest.Mocked<SecurityContext>;
  const service = new UsuarioService(repositoryUsuario, repositoryEmpregado, repositoryDominio, servicePermissao, security);

  describe('buscarPorUsername', () => {
    beforeEach(() => {
      repositoryEmpregado.findOneByCPF.mockClear();
      servicePermissao.findManyByEmpregado.mockClear();
      repositoryDominio.findManyByGestor.mockClear();
      repositoryUsuario.findOneByUsername.mockClear();
      security.getRequestUser.mockClear();
      cache.hget.mockResolvedValue(null);
    });

    it('empregado inexistente', async () => {
      repositoryUsuario.findOneByUsername.mockResolvedValue(null);
      repositoryEmpregado.findOneByCPF.mockResolvedValue(null);
      await expect(service.buscarPorUsername('12345678900')).rejects.toThrow(NotFoundException);
      expect(servicePermissao.findManyByEmpregado).toBeCalledTimes(0);
      expect(repositoryDominio.findManyByGestor).toBeCalledTimes(0);
    });

    it('empregado desligado', async () => {
      repositoryUsuario.findOneByUsername.mockResolvedValue(new Usuario({ empregado: new Empregado({ dataDesligamento: new Date() }) }));
      await expect(service.buscarPorUsername('12345678900')).rejects.toThrow(NotFoundException);
      expect(servicePermissao.findManyByEmpregado).toBeCalledTimes(0);
      expect(repositoryDominio.findManyByGestor).toBeCalledTimes(0);
      expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(0);
    });

    it('usuario inexistente', async () => {
      const empregado = new Empregado({ cpf: '12345678900', dataDesligamento: null });
      const permissoes = [new Permissao({ operacoes: [Operacao.EDITAR], dominioID: 'def', empregado })];
      const dominios = [new Dominio({ id: 'abc' })];
      servicePermissao.findManyByEmpregado.mockResolvedValue(permissoes);
      repositoryDominio.findManyByGestor.mockResolvedValue(dominios);
      repositoryUsuario.findOneByUsername.mockResolvedValue(null);
      repositoryEmpregado.findOneByCPF.mockResolvedValue(empregado);
      const usuario = new Usuario({ username: empregado.cpf, empregado, gestorDominio: dominios.map(d => d.id), permissoes });
      await expect(service.buscarPorUsername('12345678900')).resolves.toStrictEqual(usuario);
      expect(servicePermissao.findManyByEmpregado).toBeCalledTimes(1);
      expect(repositoryDominio.findManyByGestor).toBeCalledTimes(1);
      expect(servicePermissao.findManyByEmpregado).toBeCalledWith(empregado.cpf);
      expect(repositoryDominio.findManyByGestor).toBeCalledWith(empregado.cpf, 'id');
    });

    it('usuario existente', async () => {
      const empregado = new Empregado({ cpf: '12345678900', dataDesligamento: null });
      const permissoes = [new Permissao({ operacoes: [Operacao.EDITAR], dominioID: 'def', empregado })];
      const dominios = [new Dominio({ id: 'abc' })];
      const usuario = new Usuario({ username: empregado.cpf, empregado, gestorDominio: dominios.map(d => d.id), permissoes });
      servicePermissao.findManyByEmpregado.mockResolvedValue(permissoes);
      repositoryDominio.findManyByGestor.mockResolvedValue(dominios);
      repositoryUsuario.findOneByUsername.mockResolvedValue(usuario);
      await expect(service.buscarPorUsername('12345678900')).resolves.toStrictEqual(usuario);
      expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(0);
      expect(servicePermissao.findManyByEmpregado).toBeCalledTimes(1);
      expect(repositoryDominio.findManyByGestor).toBeCalledTimes(1);
      expect(servicePermissao.findManyByEmpregado).toBeCalledWith(empregado.cpf);
      expect(repositoryDominio.findManyByGestor).toBeCalledWith(empregado.cpf, 'id');
    });

    it('usuario de serviço', async () => {
      const usuario = new Usuario({ username: 'AESP' });
      await expect(service.buscarPorUsername(usuario.username)).resolves.toStrictEqual(usuario);
      expect(repositoryEmpregado.findOneByCPF).toBeCalledTimes(0);
      expect(servicePermissao.findManyByEmpregado).toBeCalledTimes(0);
      expect(repositoryDominio.findManyByGestor).toBeCalledTimes(0);
    });
  });

  it('listar', async () => {
    const usuarios = [
      new Usuario({
        username: '11122233300',
        empregado: new Empregado({ cpf: '11122233300', nome: 'Fulano' }),
        perfis: [Perfil.ADMINISTRADOR],
      }),
      new Usuario({
        username: '22233344400',
        empregado: new Empregado({ cpf: '22233344400', nome: 'Cicrano' }),
        perfis: [Perfil.CADASTRADOR_DOMINIO, Perfil.GESTOR_ALOCACAO],
      }),
      new Usuario({
        username: '33344455500',
        empregado: new Empregado({ cpf: '33344455500', nome: 'Beltrano' }),
        perfis: [Perfil.GESTOR_EXECUTIVO],
      }),
    ];
    repositoryUsuario.findAll.mockResolvedValue(usuarios);
    await expect(service.listar()).resolves.toStrictEqual(usuarios.map(u => UsuarioDTO.of(u)));
    expect(repositoryUsuario.findAll).toBeCalledWith('*');
  });

  describe('alterar', () => {
    beforeEach(() => {
      repositoryEmpregado.findOneByCPF.mockClear();
      servicePermissao.findManyByEmpregado.mockClear();
      servicePermissao.alterarPermissoesPorEmpregado.mockClear();
      repositoryDominio.findManyByGestor.mockClear();
      repositoryUsuario.findOneByUsername.mockClear();
      repositoryUsuario.insert.mockClear();
      repositoryUsuario.update.mockClear();
      repositoryUsuario.delete.mockClear();
      security.getRequestUser.mockClear();
      cache.hget.mockResolvedValue(null);
    });

    it('sem permissão', async () => {
      repositoryUsuario.findOneByUsername.mockResolvedValue(new Usuario({ id: 'def' }));

      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc' }));
      await expect(service.alterar(new Usuario({ id: 'def', username: '11122233300' }))).rejects.toThrow(ForbiddenException);

      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc', perfis: [Perfil.CADASTRADOR_DOMINIO] }));
      await expect(service.alterar(new Usuario({ id: 'def', username: '11122233300', perfis: [Perfil.ADMINISTRADOR] }))).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('registro desatualizado', async () => {
      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc', perfis: [Perfil.ADMINISTRADOR] }));
      repositoryUsuario.findOneByUsername.mockResolvedValue(new Usuario({ id: 'def', empregado: { dataDesligamento: null } }));
      await expect(service.alterar(new Usuario({ id: 'abc', username: '11122233300' }))).rejects.toThrow(BadRequestException);
    });

    it('usuário novo', async () => {
      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc', perfis: [Perfil.ADMINISTRADOR] }));
      repositoryUsuario.findOneByUsername.mockResolvedValue(null);
      servicePermissao.findManyByEmpregado.mockResolvedValue([]);
      repositoryDominio.findManyByGestor.mockResolvedValue([]);
      repositoryEmpregado.findOneByCPF.mockResolvedValue(new Empregado({ cpf: '11122233300', dataDesligamento: null }));
      const usuario = new Usuario({
        username: '11122233300',
        perfis: [Perfil.GESTOR_ALOCACAO],
        empregado: new Empregado({ cpf: '11122233300' }),
        permissoes: [new Permissao({ dominioID: 'xyz', operacoes: [Operacao.EDITAR] })],
      });
      await service.alterar(usuario);
      expect(repositoryUsuario.insert).toBeCalledTimes(1);
      expect(repositoryUsuario.update).toBeCalledTimes(0);
      expect(repositoryUsuario.delete).toBeCalledTimes(0);
      expect(repositoryUsuario.insert).toBeCalledWith(usuario);
      const permissoes = usuario.permissoes.map(p => new Permissao({ ...p, empregado: new Empregado({ cpf: '11122233300' }) }));
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledWith(usuario.username, ...permissoes);
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledTimes(1);
    });

    it('usuário alterado', async () => {
      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc', perfis: [Perfil.ADMINISTRADOR] }));
      repositoryUsuario.findOneByUsername.mockResolvedValue(
        new Usuario({ id: 'def', empregado: new Empregado({ cpf: '11122233300', dataDesligamento: null }) }),
      );
      servicePermissao.findManyByEmpregado.mockResolvedValue([]);
      repositoryDominio.findManyByGestor.mockResolvedValue([]);
      const usuario = new Usuario({
        id: 'def',
        username: '11122233300',
        perfis: [Perfil.GESTOR_ALOCACAO],
        empregado: new Empregado({ cpf: '11122233300' }),
        permissoes: [],
      });
      await service.alterar(usuario);
      expect(repositoryUsuario.insert).toBeCalledTimes(0);
      expect(repositoryUsuario.update).toBeCalledTimes(1);
      expect(repositoryUsuario.delete).toBeCalledTimes(0);
      expect(repositoryUsuario.update).toBeCalledWith(usuario);
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledWith(usuario.username);
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledTimes(1);
    });

    it('usuário excluído', async () => {
      security.getRequestUser.mockReturnValue(new Usuario({ id: 'abc', perfis: [Perfil.ADMINISTRADOR] }));
      repositoryUsuario.findOneByUsername.mockResolvedValue(
        new Usuario({ id: 'def', empregado: new Empregado({ cpf: '11122233300', dataDesligamento: null }) }),
      );
      servicePermissao.findManyByEmpregado.mockResolvedValue([]);
      repositoryDominio.findManyByGestor.mockResolvedValue([]);
      const usuario = new Usuario({
        id: 'def',
        username: '11122233300',
        perfis: [],
        empregado: new Empregado({ cpf: '11122233300' }),
        permissoes: [new Permissao({ dominioID: 'xyz', operacoes: [Operacao.EDITAR] })],
      });
      await service.alterar(usuario);
      expect(repositoryUsuario.insert).toBeCalledTimes(0);
      expect(repositoryUsuario.update).toBeCalledTimes(0);
      expect(repositoryUsuario.delete).toBeCalledTimes(1);
      expect(repositoryUsuario.delete).toBeCalledWith(usuario.id);
      const permissoes = usuario.permissoes.map(p => new Permissao({ ...p, empregado: new Empregado({ cpf: '11122233300' }) }));
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledWith(usuario.username, ...permissoes);
      expect(servicePermissao.alterarPermissoesPorEmpregado).toBeCalledTimes(1);
    });
  });
});
