import 'jest';

process.env.AMBIENTE = 'TESTE';

jest.mock('typeorm-transactional-cls-hooked', () => ({
  Transactional: () => () => ({}),
  BaseRepository: class {},
}));
